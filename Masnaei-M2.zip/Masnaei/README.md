# Masnaei Machine Intelligence V1

Read-only monitoring platform for EPS machines (Omron CP1H). No real PLC is contacted and nothing in the code can write to a PLC.

## Layout (modular monolith)
- `src/Masnaei.Acquisition.Contracts` - tag model, scaling, validation, read-only `IPlcAdapter`.
- `src/Masnaei.Acquisition.Simulation` - deterministic simulated PLCs (two profiles with different tag mappings).
- `src/Masnaei.SharedKernel` - auth constants and API key hashing.
- `src/Masnaei.Modules.Registry` - factories, gateways, machines, PLCs, connection configs, tags.
- `src/Masnaei.Modules.Telemetry` - sensor readings, gateway health, ingest batches.
- `src/Masnaei.Modules.Production` - cycle events, motor events.
- `src/Masnaei.Persistence` - EF Core `MasnaeiDbContext` and migrations (modules never reference it).
- `src/Masnaei.Api` - ASP.NET Core host: auth, ingest orchestration, Swagger.
- `tests/Masnaei.Acquisition.Tests`, `tests/Masnaei.Api.Tests` - xUnit unit and SQL Server integration tests.

Modules own their schema (`registry`, `telemetry`, `production`) and never read each other's tables; they talk through small interfaces such as `IRegistryDirectory`.

## Working from GitHub only
- `.github/workflows/ci.yml` - restore, build (Release), test with a SQL Server service container, upload results, fail on any failure or skipped test.
- `.github/workflows/maintenance.yml` - manual helpers: `import-zip` (unpack an uploaded zip into the repo) and `generate-migration` (create an EF Core migration with the real tool and commit it).

See `docs/API.md` for the API and `STATUS.md` for what has been verified.
