using System.Net;

namespace Masnaei.Api.Tests;

/// <summary>Tests that never touch the database, so they run everywhere (including without SQL Server).</summary>
public class ApiSurfaceTests : IClassFixture<ApiFixture>
{
    private readonly ApiFixture _fixture;

    public ApiSurfaceTests(ApiFixture fixture) => _fixture = fixture;

    [Fact]
    public async Task Health_endpoint_is_public()
    {
        var response = await _fixture.CreateClient(null).GetAsync("/health");
        await TestWorld.ExpectAsync(HttpStatusCode.OK, response);
    }

    [Fact]
    public async Task Swagger_document_describes_the_api_and_its_key_security()
    {
        var response = await _fixture.CreateClient(null).GetAsync("/swagger/v1/swagger.json");
        await TestWorld.ExpectAsync(HttpStatusCode.OK, response);
        var json = await response.Content.ReadAsStringAsync();

        Assert.Contains("/api/v1/ingest/batches", json);
        Assert.Contains("/api/v1/machines/{machineId}/readings", json);
        Assert.Contains("X-Api-Key", json);
    }

    [Theory]
    [InlineData("GET", "/api/v1/machines")]
    [InlineData("POST", "/api/v1/factories")]
    [InlineData("POST", "/api/v1/ingest/batches")]
    [InlineData("GET", "/api/v1/gateway/config")]
    public async Task Protected_endpoints_reject_requests_without_a_key(string method, string url)
    {
        var request = new HttpRequestMessage(new HttpMethod(method), url);
        if (method == "POST") request.Content = JsonContent.Create(new { });

        var response = await _fixture.CreateClient(null).SendAsync(request);
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task The_reader_key_cannot_use_admin_endpoints()
    {
        var response = await _fixture.CreateClient(ApiFixture.ReaderKey)
            .PostAsJsonAsync("/api/v1/factories", new { name = "x" });
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task The_reader_key_cannot_ingest()
    {
        var response = await _fixture.CreateClient(ApiFixture.ReaderKey)
            .PostAsJsonAsync("/api/v1/ingest/batches", new { });
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }
}
