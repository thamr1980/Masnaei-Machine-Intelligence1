using System.Net;
using Masnaei.Acquisition.Contracts;
using Masnaei.Api.Ingestion;
using Masnaei.Modules.Production;
using Masnaei.Modules.Production.Domain;
using Masnaei.Modules.Registry;
using Masnaei.Modules.Registry.Domain;
using Masnaei.Modules.Telemetry;
using Masnaei.Modules.Telemetry.Domain;
using Microsoft.EntityFrameworkCore;

namespace Masnaei.Api.Tests;

public class DatabaseTests : IClassFixture<ApiFixture>
{
    private readonly ApiFixture _fixture;
    public DatabaseTests(ApiFixture fixture) => _fixture = fixture;

    [SqlServerFact]
    public async Task Migrations_are_applied_and_all_module_tables_exist()
    {
        var db = _fixture.CreateDbContext(out var scope);
        using (scope)
        {
            Assert.NotEmpty(await db.Database.GetAppliedMigrationsAsync());
            Assert.Empty(await db.Database.GetPendingMigrationsAsync());

            var tables = await db.Database.SqlQueryRaw<string>(
                "SELECT s.name + '.' + t.name AS [Value] FROM sys.tables t JOIN sys.schemas s ON s.schema_id = t.schema_id").ToListAsync();

            foreach (var expected in new[]
            {
                "registry.Factories", "registry.Gateways", "registry.GatewayCredentials", "registry.Machines",
                "registry.PlcDevices", "registry.PlcConnectionConfigs", "registry.Tags",
                "telemetry.SensorReadings", "telemetry.GatewayHealth", "telemetry.PlcConnectionHealth", "telemetry.IngestBatches",
                "production.CycleEvents", "production.MotorEvents"
            })
            {
                Assert.Contains(expected, tables);
            }
        }
    }

    [SqlServerFact]
    public async Task Gateway_api_keys_are_stored_only_as_hashes()
    {
        var world = await TestWorld.CreateAsync(_fixture);
        var db = _fixture.CreateDbContext(out var scope);
        using (scope)
        {
            var credential = await db.Set<GatewayCredential>().AsNoTracking().SingleAsync(c => c.GatewayId == world.GatewayId);
            Assert.NotEqual(world.GatewayKey, credential.KeyHash);
            Assert.Equal(Masnaei.SharedKernel.ApiKeys.Hash(world.GatewayKey), credential.KeyHash);
            Assert.Equal(world.GatewayKey[..8], credential.KeyPrefix);
        }
    }
}

public class RegistryApiTests : IClassFixture<ApiFixture>
{
    private readonly ApiFixture _fixture;
    public RegistryApiTests(ApiFixture fixture) => _fixture = fixture;

    [SqlServerFact]
    public async Task Two_PLCs_keep_independent_tag_mappings()
    {
        var world = await TestWorld.CreateAsync(_fixture);

        var tagsA = await TestWorld.Ok<List<TagDto>>(await world.Reader.GetAsync($"/api/v1/plcs/{world.PlcAId}/tags"));
        var tagsB = await TestWorld.Ok<List<TagDto>>(await world.Reader.GetAsync($"/api/v1/plcs/{world.PlcBId}/tags"));

        Assert.Equal(world.ProfileA.Tags.Count, tagsA.Count);
        Assert.Equal(world.ProfileB.Tags.Count, tagsB.Count);
        Assert.Empty(tagsA.Select(t => t.Key).Intersect(tagsB.Select(t => t.Key)));
        Assert.Equal(TagDataType.UInt16, tagsA.Single(t => t.Role == TagRole.CycleCounter).DataType);
        Assert.Equal(TagDataType.UInt32, tagsB.Single(t => t.Role == TagRole.CycleCounter).DataType);
    }

    [SqlServerFact]
    public async Task Machines_are_listed_with_their_PLCs()
    {
        var world = await TestWorld.CreateAsync(_fixture);

        var machines = await TestWorld.Ok<List<MachineDto>>(await world.Reader.GetAsync("/api/v1/machines"));
        var a = machines.Single(m => m.Id == world.MachineAId);

        Assert.Equal("ماكينة أ", a.NameAr);
        var plc = Assert.Single(a.Plcs);
        Assert.Equal(PlcDeviceStatus.Active, plc.Status);
        Assert.True(plc.IsSimulated);
        Assert.Equal("CP1W-CIF41", plc.EthernetModuleModel);
    }

    [SqlServerFact]
    public async Task Gateway_receives_only_its_own_active_PLC_configuration()
    {
        var world = await TestWorld.CreateAsync(_fixture);

        var config = await TestWorld.Ok<GatewayConfigDto>(await world.Gateway.GetAsync("/api/v1/gateway/config"));

        Assert.Equal(world.GatewayId, config.GatewayId);
        Assert.Equal(2, config.Plcs.Count);
        Assert.Equal(world.ProfileA.Tags.Count, config.Plcs.Single(p => p.PlcDeviceId == world.PlcAId).Tags.Count);
        Assert.Equal(world.ProfileB.Tags.Count, config.Plcs.Single(p => p.PlcDeviceId == world.PlcBId).Tags.Count);
        Assert.All(config.Plcs, p => Assert.Null(p.Connection));   // simulated PLCs carry no IP address
    }

    [SqlServerFact]
    public async Task Activation_requires_tags_and_a_connection_for_real_PLCs()
    {
        var world = await TestWorld.CreateAsync(_fixture, activate: false);
        var machine = await TestWorld.Ok<MachineDto>(await world.Admin.PostAsJsonAsync("/api/v1/machines",
            new CreateMachineRequest(world.FactoryId, "C-" + Guid.NewGuid().ToString("N")[..8], "Machine C", null), ApiFixture.Json));

        // Simulated PLC with no tags cannot be activated.
        var empty = await TestWorld.Ok<PlcSummaryDto>(await world.Admin.PostAsJsonAsync($"/api/v1/machines/{machine.Id}/plcs",
            new CreatePlcRequest(world.GatewayId, "Omron", "CP1H", "CP1W-CIF41", true), ApiFixture.Json));
        await TestWorld.ExpectAsync(HttpStatusCode.BadRequest, await world.Admin.PostAsync($"/api/v1/plcs/{empty.Id}/activate", null));

        // A real PLC with tags but no connection configuration cannot be activated either.
        var machine2 = await TestWorld.Ok<MachineDto>(await world.Admin.PostAsJsonAsync("/api/v1/machines",
            new CreateMachineRequest(world.FactoryId, "D-" + Guid.NewGuid().ToString("N")[..8], "Machine D", null), ApiFixture.Json));
        var real = await TestWorld.Ok<PlcSummaryDto>(await world.Admin.PostAsJsonAsync($"/api/v1/machines/{machine2.Id}/plcs",
            new CreatePlcRequest(world.GatewayId, "Omron", "CP1H", "CP1W-CIF41", false), ApiFixture.Json));
        await TestWorld.Ok<List<TagDto>>(await world.Admin.PutAsJsonAsync($"/api/v1/plcs/{real.Id}/tags",
            TestWorld.ToTagRequest(world.ProfileB), ApiFixture.Json));
        await TestWorld.ExpectAsync(HttpStatusCode.BadRequest, await world.Admin.PostAsync($"/api/v1/plcs/{real.Id}/activate", null));
    }

    [SqlServerFact]
    public async Task Connection_config_is_versioned_validated_and_ip_unique_per_gateway()
    {
        var world = await TestWorld.CreateAsync(_fixture, activate: false);

        // 192.0.2.x and 198.51.100.x are documentation-only addresses (RFC 5737): clearly not real PLC addresses.
        var first = await TestWorld.Ok<ConnectionConfigDto>(await world.Admin.PutAsJsonAsync($"/api/v1/plcs/{world.PlcAId}/connection-config",
            new ConnectionConfigRequest("192.0.2.10", 1000, 1, 2, 3, 2000, 1000), ApiFixture.Json));
        var second = await TestWorld.Ok<ConnectionConfigDto>(await world.Admin.PutAsJsonAsync($"/api/v1/plcs/{world.PlcAId}/connection-config",
            new ConnectionConfigRequest("192.0.2.11", 1000, 1, 2, 3, 2000, 1000), ApiFixture.Json));
        Assert.Equal(1, first.Version);
        Assert.Equal(2, second.Version);

        // Same IP on another PLC of the same gateway is refused.
        await TestWorld.ExpectAsync(HttpStatusCode.Conflict, await world.Admin.PutAsJsonAsync(
            $"/api/v1/plcs/{world.PlcBId}/connection-config",
            new ConnectionConfigRequest("192.0.2.11", 1000, 1, 2, 4, 2000, 1000), ApiFixture.Json));

        // The previous address is free again because version 1 is no longer current.
        await TestWorld.Ok<ConnectionConfigDto>(await world.Admin.PutAsJsonAsync($"/api/v1/plcs/{world.PlcBId}/connection-config",
            new ConnectionConfigRequest("192.0.2.10", 1000, 1, 2, 4, 2000, 1000), ApiFixture.Json));

        foreach (var bad in new[]
        {
            new ConnectionConfigRequest("999.1.1.1", 1000, null, null, null, 2000, 1000),
            new ConnectionConfigRequest("10.1", 1000, null, null, null, 2000, 1000),
            new ConnectionConfigRequest("198.51.100.5", 70000, null, null, null, 2000, 1000),
            new ConnectionConfigRequest("198.51.100.5", 1000, null, null, null, 5, 1000),
            new ConnectionConfigRequest("198.51.100.5", 1000, 300, null, null, 2000, 1000)
        })
        {
            await TestWorld.ExpectAsync(HttpStatusCode.BadRequest,
                await world.Admin.PutAsJsonAsync($"/api/v1/plcs/{world.PlcAId}/connection-config", bad, ApiFixture.Json));
        }
    }

    [SqlServerFact]
    public async Task Invalid_tag_sets_and_duplicate_machine_codes_are_rejected()
    {
        var world = await TestWorld.CreateAsync(_fixture, activate: false);

        var dupTags = new SetTagsRequest(new List<TagRequest>
        {
            new("dup", TagDataType.Int16), new("dup", TagDataType.Int16)
        });
        await TestWorld.ExpectAsync(HttpStatusCode.BadRequest,
            await world.Admin.PutAsJsonAsync($"/api/v1/plcs/{world.PlcAId}/tags", dupTags, ApiFixture.Json));

        var zeroScale = new SetTagsRequest(new List<TagRequest> { new("z", TagDataType.Int16, Scale: 0) });
        await TestWorld.ExpectAsync(HttpStatusCode.BadRequest,
            await world.Admin.PutAsJsonAsync($"/api/v1/plcs/{world.PlcAId}/tags", zeroScale, ApiFixture.Json));

        var machines = await TestWorld.Ok<List<MachineDto>>(await world.Reader.GetAsync("/api/v1/machines"));
        var code = machines.Single(m => m.Id == world.MachineAId).Code;
        await TestWorld.ExpectAsync(HttpStatusCode.Conflict, await world.Admin.PostAsJsonAsync("/api/v1/machines",
            new CreateMachineRequest(world.FactoryId, code, "Duplicate", null), ApiFixture.Json));
    }

    [SqlServerFact]
    public async Task Tags_missing_from_an_update_are_deactivated_not_deleted()
    {
        var world = await TestWorld.CreateAsync(_fixture, activate: false);
        var keep = world.ProfileB.Tags.First();
        var request = new SetTagsRequest(new List<TagRequest>
        {
            new(keep.Key, keep.DataType, keep.DisplayName, keep.Address, keep.Scale, keep.Offset, keep.Unit,
                keep.MinValid, keep.MaxValid, keep.PollGroup, keep.Role, keep.MotorId, true)
        });

        await TestWorld.Ok<List<TagDto>>(await world.Admin.PutAsJsonAsync($"/api/v1/plcs/{world.PlcBId}/tags", request, ApiFixture.Json));

        var active = await TestWorld.Ok<List<TagDto>>(await world.Reader.GetAsync($"/api/v1/plcs/{world.PlcBId}/tags"));
        var all = await TestWorld.Ok<List<TagDto>>(await world.Reader.GetAsync($"/api/v1/plcs/{world.PlcBId}/tags?includeInactive=true"));
        Assert.Single(active);
        Assert.Equal(world.ProfileB.Tags.Count, all.Count);
        Assert.Equal(world.ProfileB.Tags.Count - 1, all.Count(t => !t.IsActive));
    }
}

public class IngestApiTests : IClassFixture<ApiFixture>
{
    private readonly ApiFixture _fixture;
    public IngestApiTests(ApiFixture fixture) => _fixture = fixture;

    private static async Task<(List<IngestReading> A, List<IngestReading> B)> SimulatedAsync(TestWorld w) =>
        (await TestWorld.SimulatedReadingsAsync(w.ProfileA, w.PlcAId, 0, 60, 1),
         await TestWorld.SimulatedReadingsAsync(w.ProfileB, w.PlcBId, 0, 60, 1));

    [SqlServerFact]
    public async Task Simulated_readings_from_two_PLCs_are_stored_per_machine_with_utc_quality_and_source()
    {
        var world = await TestWorld.CreateAsync(_fixture);
        var (a, b) = await SimulatedAsync(world);

        var response = await world.Gateway.PostAsJsonAsync("/api/v1/ingest/batches", TestWorld.Batch(a.Concat(b)), ApiFixture.Json);
        await TestWorld.ExpectAsync(HttpStatusCode.Accepted, response);
        var result = await response.Content.ReadFromJsonAsync<IngestResult>(ApiFixture.Json);
        Assert.False(result!.Duplicate);
        Assert.Equal(a.Count + b.Count, result.Readings);

        var seriesA = await TestWorld.Ok<ReadingsResponse>(await world.Reader.GetAsync(world.ReadingsUrl(world.MachineAId, "steam.fixed.pressure", 0, 60)));
        Assert.Equal(61, seriesA.Items.Count);
        Assert.All(seriesA.Items, i =>
        {
            Assert.Equal(DataOrigin.Simulated, i.Origin);
            Assert.Equal(SampleQuality.Good, i.Quality);
            Assert.Equal(world.PlcAId, i.PlcDeviceId);
            Assert.Equal(DateTimeKind.Utc, i.TimestampUtc.Kind);
        });
        var peak = seriesA.Items.Single(i => i.TimestampUtc == TestWorld.SimStart.AddSeconds(35).UtcDateTime);
        Assert.Equal(1.2, peak.Value!.Value, 1);   // machine A is at its steam peak 35 s into the run

        var seriesB = await TestWorld.Ok<ReadingsResponse>(await world.Reader.GetAsync(world.ReadingsUrl(world.MachineBId, "SteamP_Fix", 0, 60)));
        Assert.Equal(61, seriesB.Items.Count);
        Assert.All(seriesB.Items, i => Assert.Equal(world.PlcBId, i.PlcDeviceId));
        Assert.Equal(1.2, seriesB.Items.Single(i => i.TimestampUtc == TestWorld.SimStart.AddSeconds(35).UtcDateTime).Value!.Value, 1);

        // Machine B has no tag called steam.fixed.pressure: mappings are per PLC.
        await TestWorld.ExpectAsync(HttpStatusCode.NotFound,
            await world.Reader.GetAsync(world.ReadingsUrl(world.MachineBId, "steam.fixed.pressure", 0, 60)));

        // The database holds exactly what was sent, tagged with the right machine and PLC.
        var db = _fixture.CreateDbContext(out var scope);
        using (scope)
        {
            var rows = await db.Set<SensorReading>().AsNoTracking()
                .Where(r => r.PlcDeviceId == world.PlcAId || r.PlcDeviceId == world.PlcBId).ToListAsync();
            Assert.Equal(a.Count + b.Count, rows.Count);
            Assert.All(rows.Where(r => r.PlcDeviceId == world.PlcAId), r => Assert.Equal(world.MachineAId, r.MachineId));
            Assert.All(rows.Where(r => r.PlcDeviceId == world.PlcBId), r => Assert.Equal(world.MachineBId, r.MachineId));
            Assert.All(rows, r => Assert.Equal(DataOrigin.Simulated, r.Origin));
        }
    }

    [SqlServerFact]
    public async Task Sending_the_same_batch_twice_stores_it_once()
    {
        var world = await TestWorld.CreateAsync(_fixture);
        var readings = await TestWorld.SimulatedReadingsAsync(world.ProfileA, world.PlcAId, 0, 10, 1);
        var batch = TestWorld.Batch(readings);

        await TestWorld.ExpectAsync(HttpStatusCode.Accepted, await world.Gateway.PostAsJsonAsync("/api/v1/ingest/batches", batch, ApiFixture.Json));
        var second = await world.Gateway.PostAsJsonAsync("/api/v1/ingest/batches", batch, ApiFixture.Json);
        await TestWorld.ExpectAsync(HttpStatusCode.OK, second);
        Assert.True((await second.Content.ReadFromJsonAsync<IngestResult>(ApiFixture.Json))!.Duplicate);

        var series = await TestWorld.Ok<ReadingsResponse>(await world.Reader.GetAsync(world.ReadingsUrl(world.MachineAId, "steam.fixed.pressure", 0, 60)));
        Assert.Equal(11, series.Items.Count);
    }

    [SqlServerFact]
    public async Task The_same_readings_in_a_different_batch_are_refused_and_nothing_is_saved()
    {
        var world = await TestWorld.CreateAsync(_fixture);
        var readings = await TestWorld.SimulatedReadingsAsync(world.ProfileA, world.PlcAId, 0, 5, 1);
        await TestWorld.ExpectAsync(HttpStatusCode.Accepted,
            await world.Gateway.PostAsJsonAsync("/api/v1/ingest/batches", TestWorld.Batch(readings), ApiFixture.Json));

        var overlapping = readings.Concat(await TestWorld.SimulatedReadingsAsync(world.ProfileA, world.PlcAId, 6, 8, 1));
        await TestWorld.ExpectAsync(HttpStatusCode.Conflict,
            await world.Gateway.PostAsJsonAsync("/api/v1/ingest/batches", TestWorld.Batch(overlapping), ApiFixture.Json));

        var series = await TestWorld.Ok<ReadingsResponse>(await world.Reader.GetAsync(world.ReadingsUrl(world.MachineAId, "steam.fixed.pressure", 0, 60)));
        Assert.Equal(6, series.Items.Count);   // the new readings at 6..8 s were rolled back with the rest of the batch
    }

    [SqlServerFact]
    public async Task Invalid_batches_are_rejected_without_storing_anything()
    {
        var world = await TestWorld.CreateAsync(_fixture);
        var good = await TestWorld.SimulatedReadingsAsync(world.ProfileA, world.PlcAId, 0, 2, 1);
        var template = good.First();

        // Unknown tag key.
        await ExpectRejected(world, good.Append(template with { TagKey = "no.such.tag" }), "no.such.tag");

        // Reading for a PLC that belongs to nobody.
        await ExpectRejected(world, good.Append(template with { PlcDeviceId = 999_999 }), "does not exist");

        // Live data from a simulated PLC.
        await ExpectRejected(world, good.Append(template with { TagKey = "steam.moving.pressure", Origin = DataOrigin.Live }), "origin");

        // Timestamp from the future.
        await ExpectRejected(world, good.Append(template with { TimestampUtc = DateTimeOffset.UtcNow.AddHours(1) }), "timestampUtc");

        // The same reading twice in one batch.
        await ExpectRejected(world, good.Append(good.First()), "duplicate");

        var series = await TestWorld.Ok<ReadingsResponse>(await world.Reader.GetAsync(world.ReadingsUrl(world.MachineAId, "steam.fixed.pressure", 0, 60)));
        Assert.Empty(series.Items);
    }

    [SqlServerFact]
    public async Task Unconfirmed_tags_never_become_data()
    {
        var world = await TestWorld.CreateAsync(_fixture);
        var tags = TestWorld.ToTagRequest(world.ProfileA);
        tags.Tags.Add(new TagRequest("unverified.signal", TagDataType.Int16, IsConfirmed: false));
        await TestWorld.Ok<List<TagDto>>(await world.Admin.PutAsJsonAsync($"/api/v1/plcs/{world.PlcAId}/tags", tags, ApiFixture.Json));

        var reading = new IngestReading(world.PlcAId, "unverified.signal", TestWorld.SimStart, 5.0, 5, SampleQuality.Good, DataOrigin.Simulated);
        await ExpectRejected(world, new[] { reading }, "not confirmed");
    }

    [SqlServerFact]
    public async Task A_gateway_cannot_send_data_for_another_gateways_PLC()
    {
        var world = await TestWorld.CreateAsync(_fixture);
        var other = await TestWorld.Ok<GatewayCreatedDto>(await world.Admin.PostAsJsonAsync("/api/v1/gateways",
            new CreateGatewayRequest(world.FactoryId, "Other gateway"), ApiFixture.Json));
        var otherClient = _fixture.CreateClient(other.ApiKey);
        var readings = await TestWorld.SimulatedReadingsAsync(world.ProfileA, world.PlcAId, 0, 1, 1);

        var response = await otherClient.PostAsJsonAsync("/api/v1/ingest/batches", TestWorld.Batch(readings), ApiFixture.Json);

        await TestWorld.ExpectAsync(HttpStatusCode.BadRequest, response);
        Assert.Contains("not assigned to this gateway", await response.Content.ReadAsStringAsync());
    }

    [SqlServerFact]
    public async Task Gateway_keys_cannot_use_admin_or_reader_endpoints_and_unknown_keys_are_refused()
    {
        var world = await TestWorld.CreateAsync(_fixture);

        await TestWorld.ExpectAsync(HttpStatusCode.Forbidden, await world.Gateway.GetAsync("/api/v1/machines"));
        await TestWorld.ExpectAsync(HttpStatusCode.Forbidden,
            await world.Gateway.PostAsJsonAsync("/api/v1/factories", new CreateFactoryRequest("nope", null), ApiFixture.Json));
        await TestWorld.ExpectAsync(HttpStatusCode.Unauthorized,
            await _fixture.CreateClient("mgk_this-key-was-never-issued-0123456789").GetAsync("/api/v1/gateway/config"));
    }

    [SqlServerFact]
    public async Task History_queries_page_through_results_and_enforce_limits()
    {
        var world = await TestWorld.CreateAsync(_fixture);
        var readings = await TestWorld.SimulatedReadingsAsync(world.ProfileA, world.PlcAId, 0, 29, 1);
        await TestWorld.ExpectAsync(HttpStatusCode.Accepted,
            await world.Gateway.PostAsJsonAsync("/api/v1/ingest/batches", TestWorld.Batch(readings), ApiFixture.Json));

        var page1 = await TestWorld.Ok<ReadingsResponse>(await world.Reader.GetAsync(world.ReadingsUrl(world.MachineAId, "temp.fixed", 0, 100, limit: 10)));
        Assert.Equal(10, page1.Items.Count);
        Assert.NotNull(page1.NextFromUtc);

        var next = TestWorld.Utc(new DateTimeOffset(page1.NextFromUtc!.Value, TimeSpan.Zero));
        var page2 = await TestWorld.Ok<ReadingsResponse>(await world.Reader.GetAsync(
            $"/api/v1/machines/{world.MachineAId}/readings?tagKey=temp.fixed&fromUtc={next}&toUtc={TestWorld.Utc(TestWorld.SimStart.AddSeconds(100))}&limit=10"));
        Assert.Equal(page1.NextFromUtc, page2.Items[0].TimestampUtc);
        Assert.True(page2.Items.Zip(page2.Items.Skip(1), (x, y) => x.TimestampUtc < y.TimestampUtc).All(ok => ok));

        await TestWorld.ExpectAsync(HttpStatusCode.BadRequest, await world.Reader.GetAsync(world.ReadingsUrl(world.MachineAId, "temp.fixed", 0, 100, limit: 0)));
        await TestWorld.ExpectAsync(HttpStatusCode.BadRequest, await world.Reader.GetAsync(
            $"/api/v1/machines/{world.MachineAId}/readings?tagKey=temp.fixed&fromUtc={TestWorld.Utc(TestWorld.SimStart)}&toUtc={TestWorld.Utc(TestWorld.SimStart.AddDays(40))}"));
        await TestWorld.ExpectAsync(HttpStatusCode.NotFound, await world.Reader.GetAsync(world.ReadingsUrl(987_654, "temp.fixed", 0, 10)));
    }

    [SqlServerFact]
    public async Task Cycles_and_motor_events_are_stored_and_queryable_and_cycles_are_not_duplicated()
    {
        var world = await TestWorld.CreateAsync(_fixture);
        var start = TestWorld.SimStart.AddSeconds(5);
        var cycleId = Guid.NewGuid();
        var cycles = new List<IngestCycle>
        {
            new(world.PlcAId, cycleId, 1, start, start.AddSeconds(120), CycleStatus.Completed, CycleDetectionMode.ExplicitEvents, "1.0"),
            new(world.PlcAId, Guid.NewGuid(), null, start.AddSeconds(130), start.AddSeconds(300), CycleStatus.Aborted, CycleDetectionMode.RunningBit, "1.0")
        };
        var motors = new List<IngestMotorEvent>
        {
            new(world.PlcAId, "hyd-pump", start, MotorEventType.CommandedOn, true, null, false),
            new(world.PlcAId, "hyd-pump", start.AddSeconds(1.5), MotorEventType.ConfirmedOn, true, true, false),
            new(world.PlcAId, "cool-pump", start.AddSeconds(50), MotorEventType.FeedbackMismatch, true, false, true)
        };

        await TestWorld.ExpectAsync(HttpStatusCode.Accepted, await world.Gateway.PostAsJsonAsync("/api/v1/ingest/batches",
            TestWorld.Batch(cycles: cycles, motors: motors), ApiFixture.Json));

        var range = $"fromUtc={TestWorld.Utc(TestWorld.SimStart)}&toUtc={TestWorld.Utc(TestWorld.SimStart.AddHours(1))}";
        var cycleResponse = await TestWorld.Ok<CyclesResponse>(await world.Reader.GetAsync($"/api/v1/machines/{world.MachineAId}/cycles?{range}"));
        Assert.Equal(2, cycleResponse.Items.Count);
        Assert.Equal(120_000, cycleResponse.Items[0].DurationMs);
        Assert.Equal(CycleStatus.Completed, cycleResponse.Items[0].Status);
        Assert.Equal(CycleStatus.Aborted, cycleResponse.Items[1].Status);
        Assert.Equal(world.PlcAId, cycleResponse.Items[0].PlcDeviceId);

        var motorResponse = await TestWorld.Ok<MotorEventsResponse>(await world.Reader.GetAsync($"/api/v1/machines/{world.MachineAId}/motor-events?{range}"));
        Assert.Equal(3, motorResponse.Items.Count);
        var mismatch = motorResponse.Items.Single(e => e.EventType == MotorEventType.FeedbackMismatch);
        Assert.True(mismatch.Commanded);
        Assert.False(mismatch.Confirmed);   // commanded and confirmed are kept separate
        Assert.True(mismatch.IsAbnormal);
        var filtered = await TestWorld.Ok<MotorEventsResponse>(await world.Reader.GetAsync($"/api/v1/machines/{world.MachineAId}/motor-events?{range}&motorId=hyd-pump"));
        Assert.Equal(2, filtered.Items.Count);

        // The same cycle id again, in a new batch, is refused.
        await TestWorld.ExpectAsync(HttpStatusCode.Conflict, await world.Gateway.PostAsJsonAsync("/api/v1/ingest/batches",
            TestWorld.Batch(cycles: new List<IngestCycle> { cycles[0] }), ApiFixture.Json));

        // Machine B has no cycles.
        var other = await TestWorld.Ok<CyclesResponse>(await world.Reader.GetAsync($"/api/v1/machines/{world.MachineBId}/cycles?{range}"));
        Assert.Empty(other.Items);
    }

    [SqlServerFact]
    public async Task Gateway_health_buffer_sync_and_connection_diagnostics_are_stored_and_readable()
    {
        var world = await TestWorld.CreateAsync(_fixture);
        var now = DateTimeOffset.UtcNow;
        var health = new IngestGatewayHealth(now, "0.1.0-test", 12.5, 340, 10_000, 2_048_000, now.AddSeconds(-30), SyncStatus.Behind, 4,
            new List<IngestPlcHealth>
            {
                new(world.PlcAId, PlcConnectionState.Connected, now.AddSeconds(-1), 0, 5.2, null),
                new(world.PlcBId, PlcConnectionState.Faulted, now.AddMinutes(-3), 7, null, "Simulated communication failure.")
            });

        await TestWorld.ExpectAsync(HttpStatusCode.Accepted, await world.Gateway.PostAsJsonAsync("/api/v1/ingest/batches",
            TestWorld.Batch(health: health), ApiFixture.Json));

        var latest = await TestWorld.Ok<GatewayHealthDto>(await world.Reader.GetAsync($"/api/v1/gateways/{world.GatewayId}/health/latest"));
        Assert.Equal(340, latest.BufferDepth);
        Assert.Equal(10_000, latest.BufferCapacity);
        Assert.Equal(SyncStatus.Behind, latest.SyncStatus);
        Assert.Equal(4, latest.PendingBatches);
        Assert.Equal("0.1.0-test", latest.SoftwareVersion);
        Assert.Equal(2, latest.Plcs.Count);
        var faulted = latest.Plcs.Single(p => p.PlcDeviceId == world.PlcBId);
        Assert.Equal(PlcConnectionState.Faulted, faulted.State);
        Assert.Equal(7, faulted.ConsecutiveFailures);
        Assert.Equal("Simulated communication failure.", faulted.LastError);
    }

    private static async Task ExpectRejected(TestWorld world, IEnumerable<IngestReading> readings, string expectedMessagePart)
    {
        var response = await world.Gateway.PostAsJsonAsync("/api/v1/ingest/batches", TestWorld.Batch(readings), ApiFixture.Json);
        await TestWorld.ExpectAsync(HttpStatusCode.BadRequest, response);
        Assert.Contains(expectedMessagePart, await response.Content.ReadAsStringAsync(), StringComparison.OrdinalIgnoreCase);
    }
}
