using Masnaei.Acquisition.Contracts;
using Masnaei.Api.Ingestion;
using Masnaei.Api.Security;
using Masnaei.Modules.Production.Domain;
using Masnaei.Modules.Telemetry.Domain;
using Masnaei.SharedKernel;

namespace Masnaei.Api.Tests;

public class ApiKeyTests
{
    [Fact]
    public void Generated_keys_have_a_prefix_a_sha256_hash_and_are_unique()
    {
        var a = ApiKeys.Generate();
        var b = ApiKeys.Generate();

        Assert.StartsWith(ApiKeys.Prefix, a.Key);
        Assert.Equal(a.Key[..8], a.KeyPrefix);
        Assert.Equal(64, a.Hash.Length);
        Assert.Matches("^[0-9a-f]{64}$", a.Hash);
        Assert.Equal(a.Hash, ApiKeys.Hash(a.Key));
        Assert.NotEqual(a.Key, b.Key);
        Assert.NotEqual(a.Hash, b.Hash);
        Assert.DoesNotContain(a.Key, a.Hash);
    }

    [Fact]
    public void Fixed_time_comparison_matches_only_equal_keys()
    {
        Assert.True(ApiKeys.FixedTimeEquals("same-key", "same-key"));
        Assert.False(ApiKeys.FixedTimeEquals("same-key", "other-key"));
    }
}

public class DevKeysOptionsTests
{
    private const string Admin = "admin-key-0123456789-abcdef";
    private const string Reader = "reader-key-0123456789-abcdef";

    [Fact]
    public void Resolves_roles_for_configured_keys()
    {
        var options = new DevKeysOptions { DevAdminKey = Admin, DevReaderKey = Reader };

        Assert.Equal(AuthRoles.Admin, options.ResolveRole(Admin));
        Assert.Equal(AuthRoles.Reader, options.ResolveRole(Reader));
        Assert.Null(options.ResolveRole("something-else-entirely-0123"));
    }

    [Fact]
    public void Keys_shorter_than_the_minimum_are_never_accepted()
    {
        var options = new DevKeysOptions { DevAdminKey = "short", DevReaderKey = "" };

        Assert.Null(options.ResolveRole("short"));
        Assert.Null(options.ResolveRole(""));
        Assert.True(options.AnyConfigured);
    }

    [Fact]
    public void Nothing_is_configured_by_default()
    {
        Assert.False(new DevKeysOptions().AnyConfigured);
        Assert.Null(new DevKeysOptions().ResolveRole(Admin));
    }
}

public class IngestBatchValidatorTests
{
    private static readonly DateTimeOffset Now = new(2026, 10, 13, 12, 0, 0, TimeSpan.Zero);

    private static IngestReading Reading(
        DateTimeOffset? time = null, double? value = 1.0, SampleQuality quality = SampleQuality.Good, string key = "t") =>
        new(1, key, time ?? Now.AddSeconds(-10), value, null, quality, DataOrigin.Simulated);

    private static IngestBatchRequest Batch(params IngestReading[] readings) =>
        new(Guid.NewGuid(), Now, readings.ToList(), null, null, null);

    [Fact]
    public void A_clean_batch_has_no_errors()
    {
        Assert.Empty(IngestBatchValidator.Validate(Batch(Reading()), Now));
    }

    [Fact]
    public void Empty_batches_and_empty_ids_are_rejected()
    {
        var errors = IngestBatchValidator.Validate(new IngestBatchRequest(Guid.Empty, Now, null, null, null, null), Now);

        Assert.Contains(errors, e => e.Contains("batchId"));
        Assert.Contains(errors, e => e.Contains("empty"));
    }

    [Fact]
    public void Timestamps_in_the_future_or_before_the_year_2000_are_rejected()
    {
        Assert.Contains(IngestBatchValidator.Validate(Batch(Reading(Now.AddMinutes(6))), Now), e => e.Contains("timestampUtc"));
        Assert.Empty(IngestBatchValidator.Validate(Batch(Reading(Now.AddMinutes(4))), Now));
        Assert.Contains(IngestBatchValidator.Validate(Batch(Reading(new DateTimeOffset(1999, 12, 31, 0, 0, 0, TimeSpan.Zero))), Now), e => e.Contains("timestampUtc"));
    }

    [Fact]
    public void Good_quality_requires_a_finite_value()
    {
        Assert.Contains(IngestBatchValidator.Validate(Batch(Reading(value: null)), Now), e => e.Contains("quality Good"));
        Assert.Contains(IngestBatchValidator.Validate(Batch(Reading(value: double.NaN)), Now), e => e.Contains("finite"));
        Assert.Empty(IngestBatchValidator.Validate(Batch(Reading(value: null, quality: SampleQuality.BadCommunication)), Now));
    }

    [Fact]
    public void Undefined_enum_values_and_blank_tag_keys_are_rejected()
    {
        var bad = new IngestReading(1, " ", Now, 1.0, null, (SampleQuality)99, (DataOrigin)42);
        var errors = IngestBatchValidator.Validate(Batch(bad), Now);

        Assert.Contains(errors, e => e.Contains("tagKey"));
        Assert.Contains(errors, e => e.Contains("quality"));
        Assert.Contains(errors, e => e.Contains("origin"));
    }

    [Fact]
    public void Oversized_batches_are_rejected()
    {
        var readings = Enumerable.Range(0, IngestBatchValidator.MaxReadings + 1)
            .Select(i => Reading(Now.AddSeconds(-i - 1))).ToArray();

        Assert.Contains(IngestBatchValidator.Validate(Batch(readings), Now), e => e.Contains("At most"));
    }

    [Fact]
    public void Cycles_must_be_consistent()
    {
        var start = Now.AddMinutes(-5);
        var cycles = new List<IngestCycle>
        {
            new(1, Guid.NewGuid(), 1, start, start.AddSeconds(-1), CycleStatus.Completed, CycleDetectionMode.ExplicitEvents, "1"),
            new(1, Guid.NewGuid(), 2, start, null, CycleStatus.Completed, CycleDetectionMode.CounterIncrement, "1"),
            new(1, Guid.Empty, 3, start, start.AddSeconds(5), CycleStatus.Completed, CycleDetectionMode.RunningBit, "")
        };
        var errors = IngestBatchValidator.Validate(new IngestBatchRequest(Guid.NewGuid(), Now, null, cycles, null, null), Now);

        Assert.Contains(errors, e => e.Contains("cycles[0]") && e.Contains("before startUtc"));
        Assert.Contains(errors, e => e.Contains("cycles[1]") && e.Contains("no endUtc"));
        Assert.Contains(errors, e => e.Contains("cycles[2]") && e.Contains("clientCycleId"));
        Assert.Contains(errors, e => e.Contains("cycles[2]") && e.Contains("detectorVersion"));
    }

    [Fact]
    public void Gateway_health_values_are_range_checked()
    {
        var health = new IngestGatewayHealth(Now, "1.0", null, -1, 100, null, null, SyncStatus.Idle, -2, null);
        var errors = IngestBatchValidator.Validate(new IngestBatchRequest(Guid.NewGuid(), Now, null, null, null, health), Now);

        Assert.Contains(errors, e => e.Contains("bufferDepth"));
        Assert.Contains(errors, e => e.Contains("pendingBatches"));
    }

    [Fact]
    public void The_number_of_reported_errors_is_capped()
    {
        var readings = Enumerable.Range(0, 400).Select(i => Reading(key: "")).ToArray();

        Assert.Equal(IngestBatchValidator.MaxErrors, IngestBatchValidator.Validate(Batch(readings), Now).Count);
    }
}
