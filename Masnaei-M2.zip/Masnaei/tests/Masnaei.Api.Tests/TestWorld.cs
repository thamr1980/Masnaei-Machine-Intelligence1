using System.Net;
using Masnaei.Acquisition.Contracts;
using Masnaei.Acquisition.Simulation;
using Masnaei.Api.Ingestion;
using Masnaei.Modules.Registry;
using Xunit.Sdk;

namespace Masnaei.Api.Tests;

public sealed class ManualTimeProvider : TimeProvider
{
    private DateTimeOffset _now;
    public ManualTimeProvider(DateTimeOffset start) => _now = start;
    public override DateTimeOffset GetUtcNow() => _now;
    public void Set(DateTimeOffset value) => _now = value;
}

/// <summary>Everything one integration test needs: a factory, a gateway, and two machines with different simulated PLCs.</summary>
public sealed class TestWorld
{
    public static readonly DateTimeOffset SimStart = new(2026, 1, 1, 0, 0, 0, TimeSpan.Zero);

    public required ApiFixture Fixture { get; init; }
    public required HttpClient Admin { get; init; }
    public required HttpClient Reader { get; init; }
    public required HttpClient Gateway { get; init; }
    public required int FactoryId { get; init; }
    public required int GatewayId { get; init; }
    public required string GatewayKey { get; init; }
    public required int MachineAId { get; init; }
    public required int PlcAId { get; init; }
    public required int MachineBId { get; init; }
    public required int PlcBId { get; init; }
    public required SimulatedPlcProfile ProfileA { get; init; }
    public required SimulatedPlcProfile ProfileB { get; init; }

    public static async Task<TestWorld> CreateAsync(ApiFixture fixture, bool activate = true)
    {
        var admin = fixture.CreateClient(ApiFixture.AdminKey);
        var suffix = Guid.NewGuid().ToString("N")[..8];

        var factory = await Ok<FactoryDto>(await admin.PostAsJsonAsync("/api/v1/factories",
            new CreateFactoryRequest("Test factory " + suffix, "UTC"), ApiFixture.Json));
        var gateway = await Ok<GatewayCreatedDto>(await admin.PostAsJsonAsync("/api/v1/gateways",
            new CreateGatewayRequest(factory.Id, "Gateway " + suffix), ApiFixture.Json));

        var profileA = SimulatedPlcProfiles.MachineA();
        var profileB = SimulatedPlcProfiles.MachineB();

        var machineA = await Ok<MachineDto>(await admin.PostAsJsonAsync("/api/v1/machines",
            new CreateMachineRequest(factory.Id, "A-" + suffix, "EPS Machine A", "ماكينة أ"), ApiFixture.Json));
        var machineB = await Ok<MachineDto>(await admin.PostAsJsonAsync("/api/v1/machines",
            new CreateMachineRequest(factory.Id, "B-" + suffix, "EPS Machine B", null), ApiFixture.Json));

        var plcA = await Ok<PlcSummaryDto>(await admin.PostAsJsonAsync($"/api/v1/machines/{machineA.Id}/plcs",
            new CreatePlcRequest(gateway.Id, "Omron", "CP1H", "CP1W-CIF41", true), ApiFixture.Json));
        var plcB = await Ok<PlcSummaryDto>(await admin.PostAsJsonAsync($"/api/v1/machines/{machineB.Id}/plcs",
            new CreatePlcRequest(gateway.Id, "Omron", "CP1H", "CP1W-CIF41", true), ApiFixture.Json));

        await Ok<List<TagDto>>(await admin.PutAsJsonAsync($"/api/v1/plcs/{plcA.Id}/tags", ToTagRequest(profileA), ApiFixture.Json));
        await Ok<List<TagDto>>(await admin.PutAsJsonAsync($"/api/v1/plcs/{plcB.Id}/tags", ToTagRequest(profileB), ApiFixture.Json));

        if (activate)
        {
            await Ok<PlcSummaryDto>(await admin.PostAsync($"/api/v1/plcs/{plcA.Id}/activate", null));
            await Ok<PlcSummaryDto>(await admin.PostAsync($"/api/v1/plcs/{plcB.Id}/activate", null));
        }

        var gatewayClient = fixture.CreateClient(gateway.ApiKey);
        return new TestWorld
        {
            Fixture = fixture,
            Admin = admin,
            Reader = fixture.CreateClient(ApiFixture.ReaderKey),
            Gateway = gatewayClient,
            FactoryId = factory.Id,
            GatewayId = gateway.Id,
            GatewayKey = gateway.ApiKey,
            MachineAId = machineA.Id,
            PlcAId = plcA.Id,
            MachineBId = machineB.Id,
            PlcBId = plcB.Id,
            ProfileA = profileA,
            ProfileB = profileB
        };
    }

    public static SetTagsRequest ToTagRequest(SimulatedPlcProfile profile) =>
        new(profile.Tags.Select(t => new TagRequest(
            t.Key, t.DataType, t.DisplayName, t.Address, t.Scale, t.Offset, t.Unit, t.MinValid, t.MaxValid,
            t.PollGroup, t.Role, t.MotorId, t.IsConfirmed)).ToList());

    /// <summary>Runs the real simulated adapter and converts its output into ingest readings, exactly as a gateway would.</summary>
    public static async Task<List<IngestReading>> SimulatedReadingsAsync(
        SimulatedPlcProfile profile, int plcDeviceId, double fromSeconds, double toSeconds, double stepSeconds)
    {
        var clock = new ManualTimeProvider(SimStart);
        await using var adapter = new SimulatedPlcAdapter(profile.ToOptions(SimStart), clock);
        await adapter.ConnectAsync(CancellationToken.None);
        var byKey = profile.Tags.ToDictionary(t => t.Key);

        var list = new List<IngestReading>();
        for (var t = fromSeconds; t <= toSeconds; t += stepSeconds)
        {
            clock.Set(SimStart + TimeSpan.FromSeconds(t));
            var result = await adapter.ReadAsync(profile.Tags, CancellationToken.None);
            foreach (var raw in result.Samples)
            {
                var sample = TagScaler.ToSample(byKey[raw.TagKey], raw);
                list.Add(new IngestReading(plcDeviceId, sample.TagKey, sample.TimestampUtc, sample.Value, raw.RawValue, sample.Quality, sample.Origin));
            }
        }
        return list;
    }

    public static IngestBatchRequest Batch(
        IEnumerable<IngestReading>? readings = null, List<IngestCycle>? cycles = null,
        List<IngestMotorEvent>? motors = null, IngestGatewayHealth? health = null, Guid? batchId = null) =>
        new(batchId ?? Guid.NewGuid(), DateTimeOffset.UtcNow, readings?.ToList(), cycles, motors, health);

    public static string Utc(DateTimeOffset t) => Uri.EscapeDataString(t.UtcDateTime.ToString("O"));

    public string ReadingsUrl(int machineId, string tagKey, double fromSeconds, double toSeconds, int? limit = null) =>
        $"/api/v1/machines/{machineId}/readings?tagKey={Uri.EscapeDataString(tagKey)}" +
        $"&fromUtc={Utc(SimStart + TimeSpan.FromSeconds(fromSeconds))}&toUtc={Utc(SimStart + TimeSpan.FromSeconds(toSeconds))}" +
        (limit is null ? "" : $"&limit={limit}");

    public static async Task<T> Ok<T>(HttpResponseMessage response)
    {
        if (!response.IsSuccessStatusCode)
            throw new XunitException($"Unexpected {(int)response.StatusCode} {response.StatusCode}: {await response.Content.ReadAsStringAsync()}");
        return (await response.Content.ReadFromJsonAsync<T>(ApiFixture.Json))!;
    }

    public static async Task ExpectAsync(HttpStatusCode expected, HttpResponseMessage response)
    {
        if (response.StatusCode != expected)
            throw new XunitException($"Expected {(int)expected} {expected} but got {(int)response.StatusCode} {response.StatusCode}: {await response.Content.ReadAsStringAsync()}");
    }
}
