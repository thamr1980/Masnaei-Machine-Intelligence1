using System.Text.Json;
using System.Text.Json.Serialization;
using Masnaei.Persistence;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.DependencyInjection;

namespace Masnaei.Api.Tests;

/// <summary>
/// Integration tests need a real SQL Server. In CI the connection string comes from the SQL Server service container.
/// Locally, tests are skipped (visibly) unless MASNAEI_TEST_SQL is set. In CI a missing variable is a failure, never a skip.
/// </summary>
public sealed class SqlServerFactAttribute : FactAttribute
{
    public SqlServerFactAttribute()
    {
        var hasSql = !string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("MASNAEI_TEST_SQL"));
        var inCi = string.Equals(Environment.GetEnvironmentVariable("CI"), "true", StringComparison.OrdinalIgnoreCase);
        if (!hasSql && !inCi)
            Skip = "Set MASNAEI_TEST_SQL to a SQL Server connection string to run integration tests.";
    }
}

public sealed class ApiFixture : IAsyncLifetime
{
    public const string AdminKey = "test-admin-key-0123456789-abcdef";
    public const string ReaderKey = "test-reader-key-0123456789-abcde";

    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        Converters = { new JsonStringEnumConverter() }
    };

    private string? _masterConnectionString;
    private string? _databaseName;

    public WebApplicationFactory<Program> Factory { get; private set; } = null!;

    public async Task InitializeAsync()
    {
        var baseConnection = Environment.GetEnvironmentVariable("MASNAEI_TEST_SQL");
        var inCi = string.Equals(Environment.GetEnvironmentVariable("CI"), "true", StringComparison.OrdinalIgnoreCase);

        if (string.IsNullOrWhiteSpace(baseConnection))
        {
            if (inCi) throw new InvalidOperationException("MASNAEI_TEST_SQL must be set in CI.");

            // Local run without SQL Server: only tests that never touch the database can run.
            Factory = new WebApplicationFactory<Program>().WithWebHostBuilder(b =>
            {
                b.UseSetting("Security:DevAdminKey", AdminKey);
                b.UseSetting("Security:DevReaderKey", ReaderKey);
            });
            return;
        }

        _databaseName = "masnaei_test_" + Guid.NewGuid().ToString("N");
        var master = new SqlConnectionStringBuilder(baseConnection) { InitialCatalog = "master" };
        _masterConnectionString = master.ConnectionString;
        await WaitForSqlServerAsync(_masterConnectionString);

        var testDb = new SqlConnectionStringBuilder(baseConnection) { InitialCatalog = _databaseName }.ConnectionString;
        Factory = new WebApplicationFactory<Program>().WithWebHostBuilder(b =>
        {
            b.UseSetting("ConnectionStrings:MasnaeiDb", testDb);
            b.UseSetting("Security:DevAdminKey", AdminKey);
            b.UseSetting("Security:DevReaderKey", ReaderKey);
            b.UseSetting("Database:ApplyMigrationsOnStartup", "true");
        });

        // Creating the client starts the host, which applies the EF Core migrations to the new database.
        using var _ = Factory.CreateClient();
    }

    public HttpClient CreateClient(string? apiKey)
    {
        var client = Factory.CreateClient();
        if (apiKey is not null) client.DefaultRequestHeaders.Add("X-Api-Key", apiKey);
        return client;
    }

    public MasnaeiDbContext CreateDbContext(out IServiceScope scope)
    {
        scope = Factory.Services.CreateScope();
        return scope.ServiceProvider.GetRequiredService<MasnaeiDbContext>();
    }

    public async Task DisposeAsync()
    {
        Factory?.Dispose();
        if (_masterConnectionString is null || _databaseName is null) return;

        SqlConnection.ClearAllPools();
        await using var connection = new SqlConnection(_masterConnectionString);
        await connection.OpenAsync();
        await using var command = connection.CreateCommand();
        command.CommandText =
            $"IF DB_ID(N'{_databaseName}') IS NOT NULL BEGIN " +
            $"ALTER DATABASE [{_databaseName}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; " +
            $"DROP DATABASE [{_databaseName}]; END";
        await command.ExecuteNonQueryAsync();
    }

    private static async Task WaitForSqlServerAsync(string connectionString)
    {
        Exception? last = null;
        for (var attempt = 0; attempt < 45; attempt++)
        {
            try
            {
                await using var connection = new SqlConnection(connectionString);
                await connection.OpenAsync();
                return;
            }
            catch (Exception ex)
            {
                last = ex;
                await Task.Delay(TimeSpan.FromSeconds(2));
            }
        }
        throw new InvalidOperationException("SQL Server did not become available in time.", last);
    }
}
