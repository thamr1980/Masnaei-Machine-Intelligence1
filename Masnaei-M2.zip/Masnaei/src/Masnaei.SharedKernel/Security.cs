using System.Security.Cryptography;
using System.Text;

namespace Masnaei.SharedKernel;

public static class AuthPolicies
{
    public const string Admin = "Admin";
    public const string Reader = "Reader";
    public const string Gateway = "Gateway";
}

public static class AuthRoles
{
    public const string Admin = "admin";
    public const string Reader = "reader";
    public const string Gateway = "gateway";
}

public static class AuthClaims
{
    public const string GatewayId = "gateway_id";
}

/// <summary>API key generation and hashing. Only the SHA-256 hash of a key is ever stored.</summary>
public static class ApiKeys
{
    public const string Prefix = "mgk_";

    public static (string Key, string KeyPrefix, string Hash) Generate()
    {
        var bytes = RandomNumberGenerator.GetBytes(32);
        var key = Prefix + Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_');
        return (key, key[..8], Hash(key));
    }

    public static string Hash(string key)
    {
        ArgumentNullException.ThrowIfNull(key);
        var digest = SHA256.HashData(Encoding.UTF8.GetBytes(key));
        return Convert.ToHexString(digest).ToLowerInvariant();
    }

    /// <summary>Compares two keys in constant time by comparing their hashes.</summary>
    public static bool FixedTimeEquals(string a, string b) =>
        CryptographicOperations.FixedTimeEquals(
            Encoding.UTF8.GetBytes(Hash(a)),
            Encoding.UTF8.GetBytes(Hash(b)));
}
