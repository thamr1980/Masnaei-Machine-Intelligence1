using System.Reflection;
using Masnaei.Modules.Production;
using Masnaei.Modules.Registry;
using Masnaei.Modules.Telemetry;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Masnaei.Persistence;

/// <summary>Every DateTime is stored as UTC and comes back with Kind = Utc.</summary>
public sealed class UtcDateTimeConverter : ValueConverter<DateTime, DateTime>
{
    public UtcDateTimeConverter()
        : base(
            v => v.Kind == DateTimeKind.Local ? v.ToUniversalTime() : DateTime.SpecifyKind(v, DateTimeKind.Utc),
            v => DateTime.SpecifyKind(v, DateTimeKind.Utc))
    {
    }
}

public static class ModuleAssemblies
{
    public static readonly Assembly[] All =
    {
        typeof(RegistryModule).Assembly,
        typeof(TelemetryModule).Assembly,
        typeof(ProductionModule).Assembly
    };
}

/// <summary>
/// One database, one context, but each module owns its own schema and its own entity configurations.
/// Modules never reference this project; they only see <see cref="DbContext"/>.
/// </summary>
public sealed class MasnaeiDbContext : DbContext
{
    public MasnaeiDbContext(DbContextOptions<MasnaeiDbContext> options) : base(options) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        foreach (var assembly in ModuleAssemblies.All)
            modelBuilder.ApplyConfigurationsFromAssembly(assembly);
    }

    protected override void ConfigureConventions(ModelConfigurationBuilder configurationBuilder)
    {
        configurationBuilder.Properties<DateTime>()
            .HavePrecision(3)
            .HaveConversion<UtcDateTimeConverter>();
    }
}

public static class PersistenceServiceCollectionExtensions
{
    public static IServiceCollection AddMasnaeiPersistence(this IServiceCollection services)
    {
        services.AddDbContext<MasnaeiDbContext>((sp, options) =>
        {
            var connectionString = sp.GetRequiredService<IConfiguration>().GetConnectionString("MasnaeiDb");
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new InvalidOperationException("ConnectionStrings:MasnaeiDb is not configured.");
            options.UseSqlServer(connectionString, sql => sql.EnableRetryOnFailure());
        });
        services.AddScoped<DbContext>(sp => sp.GetRequiredService<MasnaeiDbContext>());
        return services;
    }
}
