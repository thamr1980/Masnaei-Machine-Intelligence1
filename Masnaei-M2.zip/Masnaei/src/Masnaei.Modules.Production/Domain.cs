namespace Masnaei.Modules.Production.Domain;

public enum CycleStatus
{
    Completed,
    Aborted,
    Incomplete
}

public enum CycleDetectionMode
{
    ExplicitEvents,
    CounterIncrement,
    RunningBit
}

/// <summary>A production cycle detected by the gateway. Closed cycles only in Milestone 2.</summary>
public sealed class CycleEvent
{
    public long Id { get; set; }
    public int MachineId { get; set; }
    public int PlcDeviceId { get; set; }
    public Guid ClientCycleId { get; set; }
    public long? CycleNumber { get; set; }
    public DateTime StartUtc { get; set; }
    public DateTime? EndUtc { get; set; }
    public long? DurationMs { get; set; }
    public CycleStatus Status { get; set; }
    public CycleDetectionMode DetectionMode { get; set; }
    public string DetectorVersion { get; set; } = "";
    public DateTime ReceivedUtc { get; set; }
}

public enum MotorEventType
{
    CommandedOn,
    CommandedOff,
    ConfirmedOn,
    ConfirmedOff,
    FeedbackMismatch
}

/// <summary>Commanded and confirmed states are stored separately; they are never merged into one flag.</summary>
public sealed class MotorEvent
{
    public long Id { get; set; }
    public int MachineId { get; set; }
    public int PlcDeviceId { get; set; }
    public string MotorId { get; set; } = "";
    public DateTime TimestampUtc { get; set; }
    public MotorEventType EventType { get; set; }
    public bool? Commanded { get; set; }
    public bool? Confirmed { get; set; }
    public bool IsAbnormal { get; set; }
    public DateTime ReceivedUtc { get; set; }
}
