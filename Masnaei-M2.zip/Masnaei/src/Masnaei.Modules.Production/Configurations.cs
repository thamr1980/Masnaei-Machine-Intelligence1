using Masnaei.Modules.Production.Domain;

namespace Masnaei.Modules.Production;

public sealed class CycleEventConfiguration : IEntityTypeConfiguration<CycleEvent>
{
    public void Configure(EntityTypeBuilder<CycleEvent> b)
    {
        b.ToTable("CycleEvents", "production");
        b.HasKey(x => x.Id);
        b.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
        b.Property(x => x.DetectionMode).HasConversion<string>().HasMaxLength(30);
        b.Property(x => x.DetectorVersion).HasMaxLength(50).IsRequired();
        b.HasIndex(x => new { x.MachineId, x.StartUtc });
        b.HasIndex(x => new { x.PlcDeviceId, x.ClientCycleId }).IsUnique();
    }
}

public sealed class MotorEventConfiguration : IEntityTypeConfiguration<MotorEvent>
{
    public void Configure(EntityTypeBuilder<MotorEvent> b)
    {
        b.ToTable("MotorEvents", "production");
        b.HasKey(x => x.Id);
        b.Property(x => x.MotorId).HasMaxLength(100).IsRequired();
        b.Property(x => x.EventType).HasConversion<string>().HasMaxLength(30);
        b.HasIndex(x => new { x.MachineId, x.MotorId, x.TimestampUtc });
    }
}
