using Masnaei.Modules.Production.Domain;
using Masnaei.Modules.Registry;
using Masnaei.SharedKernel;

namespace Masnaei.Modules.Production;

public sealed record CycleInput(
    int MachineId, int PlcDeviceId, Guid ClientCycleId, long? CycleNumber, DateTime StartUtc, DateTime? EndUtc,
    CycleStatus Status, CycleDetectionMode DetectionMode, string DetectorVersion);

public sealed record MotorEventInput(
    int MachineId, int PlcDeviceId, string MotorId, DateTime TimestampUtc, MotorEventType EventType,
    bool? Commanded, bool? Confirmed, bool IsAbnormal);

public interface IProductionStore
{
    void StageCycles(IEnumerable<CycleInput> cycles, DateTime receivedUtc);

    void StageMotorEvents(IEnumerable<MotorEventInput> events, DateTime receivedUtc);
}

public sealed class ProductionStore(DbContext db) : IProductionStore
{
    public void StageCycles(IEnumerable<CycleInput> cycles, DateTime receivedUtc)
    {
        foreach (var c in cycles)
        {
            db.Set<CycleEvent>().Add(new CycleEvent
            {
                MachineId = c.MachineId,
                PlcDeviceId = c.PlcDeviceId,
                ClientCycleId = c.ClientCycleId,
                CycleNumber = c.CycleNumber,
                StartUtc = c.StartUtc,
                EndUtc = c.EndUtc,
                DurationMs = c.EndUtc is null ? null : (long)(c.EndUtc.Value - c.StartUtc).TotalMilliseconds,
                Status = c.Status,
                DetectionMode = c.DetectionMode,
                DetectorVersion = c.DetectorVersion,
                ReceivedUtc = receivedUtc
            });
        }
    }

    public void StageMotorEvents(IEnumerable<MotorEventInput> events, DateTime receivedUtc)
    {
        foreach (var e in events)
        {
            db.Set<MotorEvent>().Add(new MotorEvent
            {
                MachineId = e.MachineId,
                PlcDeviceId = e.PlcDeviceId,
                MotorId = e.MotorId,
                TimestampUtc = e.TimestampUtc,
                EventType = e.EventType,
                Commanded = e.Commanded,
                Confirmed = e.Confirmed,
                IsAbnormal = e.IsAbnormal,
                ReceivedUtc = receivedUtc
            });
        }
    }
}

public sealed record CycleDto(
    long Id, int MachineId, int PlcDeviceId, Guid ClientCycleId, long? CycleNumber, DateTime StartUtc, DateTime? EndUtc,
    long? DurationMs, CycleStatus Status, CycleDetectionMode DetectionMode, string DetectorVersion);

public sealed record CyclesResponse(int MachineId, IReadOnlyList<CycleDto> Items, DateTime? NextFromUtc);

public sealed record MotorEventDto(
    long Id, int MachineId, int PlcDeviceId, string MotorId, DateTime TimestampUtc, MotorEventType EventType,
    bool? Commanded, bool? Confirmed, bool IsAbnormal);

public sealed record MotorEventsResponse(int MachineId, IReadOnlyList<MotorEventDto> Items, DateTime? NextFromUtc);

public static class ProductionModule
{
    public const int DefaultLimit = 500;
    public const int MaxLimit = 5000;
    public static readonly TimeSpan MaxRange = TimeSpan.FromDays(92);

    public static IServiceCollection AddProductionModule(this IServiceCollection services)
    {
        services.AddScoped<IProductionStore, ProductionStore>();
        return services;
    }

    public static IEndpointRouteBuilder MapProductionEndpoints(this IEndpointRouteBuilder app)
    {
        var read = app.MapGroup("/api/v1").RequireAuthorization(AuthPolicies.Reader).WithTags("Production (read)");
        read.MapGet("/machines/{machineId:int}/cycles", GetCycles);
        read.MapGet("/machines/{machineId:int}/motor-events", GetMotorEvents);
        return app;
    }

    private static Dictionary<string, string[]> ValidateRange(DateTimeOffset? from, DateTimeOffset? to, int? limit, out int take)
    {
        var errors = new Dictionary<string, string[]>();
        if (from is null) errors["fromUtc"] = new[] { "fromUtc is required." };
        if (to is null) errors["toUtc"] = new[] { "toUtc is required." };
        if (from is not null && to is not null)
        {
            if (to < from) errors["toUtc"] = new[] { "toUtc must not be before fromUtc." };
            else if (to - from > MaxRange) errors["toUtc"] = new[] { $"The range must not exceed {MaxRange.TotalDays:0} days." };
        }
        take = limit ?? DefaultLimit;
        if (take < 1 || take > MaxLimit) errors["limit"] = new[] { $"limit must be 1-{MaxLimit}." };
        return errors;
    }

    private static async Task<IResult> GetCycles(
        int machineId, DateTimeOffset? fromUtc, DateTimeOffset? toUtc, int? limit,
        DbContext db, IRegistryDirectory registry, CancellationToken ct)
    {
        var errors = ValidateRange(fromUtc, toUtc, limit, out var take);
        if (errors.Count > 0) return Results.ValidationProblem(errors);
        if (!await registry.MachineExistsAsync(machineId, ct)) return Results.NotFound();

        var from = fromUtc!.Value.UtcDateTime;
        var to = toUtc!.Value.UtcDateTime;
        var rows = await db.Set<CycleEvent>().AsNoTracking()
            .Where(c => c.MachineId == machineId && c.StartUtc >= from && c.StartUtc <= to)
            .OrderBy(c => c.StartUtc).ThenBy(c => c.Id)
            .Take(take + 1).ToListAsync(ct);

        DateTime? next = null;
        if (rows.Count > take)
        {
            next = rows[take].StartUtc;
            rows = rows.Take(take).ToList();
        }

        var items = rows.Select(c => new CycleDto(c.Id, c.MachineId, c.PlcDeviceId, c.ClientCycleId, c.CycleNumber, c.StartUtc,
            c.EndUtc, c.DurationMs, c.Status, c.DetectionMode, c.DetectorVersion)).ToList();
        return Results.Ok(new CyclesResponse(machineId, items, next));
    }

    private static async Task<IResult> GetMotorEvents(
        int machineId, DateTimeOffset? fromUtc, DateTimeOffset? toUtc, string? motorId, int? limit,
        DbContext db, IRegistryDirectory registry, CancellationToken ct)
    {
        var errors = ValidateRange(fromUtc, toUtc, limit, out var take);
        if (errors.Count > 0) return Results.ValidationProblem(errors);
        if (!await registry.MachineExistsAsync(machineId, ct)) return Results.NotFound();

        var from = fromUtc!.Value.UtcDateTime;
        var to = toUtc!.Value.UtcDateTime;
        var query = db.Set<MotorEvent>().AsNoTracking()
            .Where(e => e.MachineId == machineId && e.TimestampUtc >= from && e.TimestampUtc <= to);
        if (!string.IsNullOrWhiteSpace(motorId)) query = query.Where(e => e.MotorId == motorId);

        var rows = await query.OrderBy(e => e.TimestampUtc).ThenBy(e => e.Id).Take(take + 1).ToListAsync(ct);

        DateTime? next = null;
        if (rows.Count > take)
        {
            next = rows[take].TimestampUtc;
            rows = rows.Take(take).ToList();
        }

        var items = rows.Select(e => new MotorEventDto(e.Id, e.MachineId, e.PlcDeviceId, e.MotorId, e.TimestampUtc,
            e.EventType, e.Commanded, e.Confirmed, e.IsAbnormal)).ToList();
        return Results.Ok(new MotorEventsResponse(machineId, items, next));
    }
}
