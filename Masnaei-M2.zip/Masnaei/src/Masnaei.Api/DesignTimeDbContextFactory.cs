using Masnaei.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Masnaei.Api;

/// <summary>
/// Used only by `dotnet ef` to create migrations. It never opens a connection when adding a migration,
/// and the fallback connection string is a placeholder, not a real server.
/// </summary>
public sealed class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<MasnaeiDbContext>
{
    public MasnaeiDbContext CreateDbContext(string[] args)
    {
        var connectionString = Environment.GetEnvironmentVariable("MASNAEI_DESIGNTIME_SQL")
            ?? "Server=localhost,1433;Database=masnaei_design;User Id=sa;Password=placeholder;TrustServerCertificate=True";

        var options = new DbContextOptionsBuilder<MasnaeiDbContext>()
            .UseSqlServer(connectionString)
            .Options;
        return new MasnaeiDbContext(options);
    }
}
