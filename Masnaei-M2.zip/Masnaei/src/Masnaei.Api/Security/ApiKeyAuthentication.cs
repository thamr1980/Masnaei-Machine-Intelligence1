using System.Security.Claims;
using System.Text.Encodings.Web;
using Masnaei.Modules.Registry;
using Masnaei.SharedKernel;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;

namespace Masnaei.Api.Security;

public static class ApiKeyDefaults
{
    public const string Scheme = "ApiKey";
    public const string HeaderName = "X-Api-Key";
}

/// <summary>
/// Local development and testing keys for the admin and reader roles. They exist only when configured,
/// must be at least 24 characters, and are refused outright in the Production environment.
/// Production user authentication is designed separately.
/// </summary>
public sealed class DevKeysOptions
{
    public const int MinLength = 24;

    public string? DevAdminKey { get; set; }
    public string? DevReaderKey { get; set; }

    public bool AnyConfigured => !string.IsNullOrEmpty(DevAdminKey) || !string.IsNullOrEmpty(DevReaderKey);

    public string? ResolveRole(string presentedKey)
    {
        if (Usable(DevAdminKey) && ApiKeys.FixedTimeEquals(presentedKey, DevAdminKey!)) return AuthRoles.Admin;
        if (Usable(DevReaderKey) && ApiKeys.FixedTimeEquals(presentedKey, DevReaderKey!)) return AuthRoles.Reader;
        return null;
    }

    private static bool Usable(string? key) => key is not null && key.Length >= MinLength;
}

public sealed class ApiKeyAuthenticationHandler(
    IOptionsMonitor<AuthenticationSchemeOptions> options,
    ILoggerFactory logger,
    UrlEncoder encoder,
    IOptions<DevKeysOptions> devKeys,
    IGatewayCredentialStore gatewayStore)
    : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
{
    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        if (!Request.Headers.TryGetValue(ApiKeyDefaults.HeaderName, out var header))
            return AuthenticateResult.NoResult();

        var key = header.ToString();
        if (string.IsNullOrWhiteSpace(key) || key.Length > 200)
            return AuthenticateResult.Fail("Invalid API key.");

        var devRole = devKeys.Value.ResolveRole(key);
        if (devRole is not null)
            return Success(new[] { new Claim(ClaimTypes.Name, "dev-" + devRole), new Claim(ClaimTypes.Role, devRole) });

        var gateway = await gatewayStore.FindActiveAsync(key, Context.RequestAborted);
        if (gateway is null)
            return AuthenticateResult.Fail("Invalid API key.");

        return Success(new[]
        {
            new Claim(ClaimTypes.Name, "gateway-" + gateway.GatewayId),
            new Claim(ClaimTypes.Role, AuthRoles.Gateway),
            new Claim(AuthClaims.GatewayId, gateway.GatewayId.ToString())
        });
    }

    private AuthenticateResult Success(IEnumerable<Claim> claims)
    {
        var identity = new ClaimsIdentity(claims, Scheme.Name);
        return AuthenticateResult.Success(new AuthenticationTicket(new ClaimsPrincipal(identity), Scheme.Name));
    }
}
