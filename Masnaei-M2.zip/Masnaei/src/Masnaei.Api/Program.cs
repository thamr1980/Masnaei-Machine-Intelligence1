using System.Text.Json.Serialization;
using Masnaei.Api.Ingestion;
using Masnaei.Api.Security;
using Masnaei.Modules.Production;
using Masnaei.Modules.Registry;
using Masnaei.Modules.Telemetry;
using Masnaei.Persistence;
using Masnaei.SharedKernel;
using Microsoft.AspNetCore.Authentication;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<DevKeysOptions>(builder.Configuration.GetSection("Security"));
builder.Services.AddSingleton(TimeProvider.System);

// Enum values travel as readable strings (for example "Simulated", "Good").
builder.Services.ConfigureHttpJsonOptions(o => o.SerializerOptions.Converters.Add(new JsonStringEnumConverter()));
builder.Services.Configure<Microsoft.AspNetCore.Mvc.JsonOptions>(o => o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()));

builder.Services.AddAuthentication(ApiKeyDefaults.Scheme)
    .AddScheme<AuthenticationSchemeOptions, ApiKeyAuthenticationHandler>(ApiKeyDefaults.Scheme, null);
builder.Services.AddAuthorizationBuilder()
    .AddPolicy(AuthPolicies.Admin, p => p.RequireRole(AuthRoles.Admin))
    .AddPolicy(AuthPolicies.Reader, p => p.RequireRole(AuthRoles.Reader, AuthRoles.Admin))
    .AddPolicy(AuthPolicies.Gateway, p => p.RequireRole(AuthRoles.Gateway));

builder.Services.AddMasnaeiPersistence();
builder.Services.AddRegistryModule();
builder.Services.AddTelemetryModule();
builder.Services.AddProductionModule();
builder.Services.AddScoped<IngestionService>();

builder.Services.AddProblemDetails();
builder.Services.AddHealthChecks();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Masnaei Machine Intelligence API",
        Version = "v1",
        Description = "Read-only monitoring platform. Gateways upload telemetry through /api/v1/ingest/batches; " +
                      "nothing in this API sends commands to a PLC."
    });
    c.AddSecurityDefinition(ApiKeyDefaults.Scheme, new OpenApiSecurityScheme
    {
        Type = SecuritySchemeType.ApiKey,
        In = ParameterLocation.Header,
        Name = ApiKeyDefaults.HeaderName,
        Description = "Gateway API key (ingest and gateway config) or a development admin/reader key."
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        [new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = ApiKeyDefaults.Scheme } }] = Array.Empty<string>()
    });
});

var app = builder.Build();

// Development keys must never exist in production; production authentication is designed separately.
if (app.Environment.IsProduction() && app.Services.GetRequiredService<Microsoft.Extensions.Options.IOptions<DevKeysOptions>>().Value.AnyConfigured)
    throw new InvalidOperationException("Security:DevAdminKey / Security:DevReaderKey must not be configured in Production.");

if (app.Configuration.GetValue<bool>("Database:ApplyMigrationsOnStartup"))
{
    using var scope = app.Services.CreateScope();
    scope.ServiceProvider.GetRequiredService<MasnaeiDbContext>().Database.Migrate();
}

app.UseExceptionHandler();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthentication();
app.UseAuthorization();

app.MapHealthChecks("/health").AllowAnonymous();
app.MapRegistryEndpoints();
app.MapTelemetryEndpoints();
app.MapProductionEndpoints();
app.MapIngestEndpoints();

app.Run();

public partial class Program;
