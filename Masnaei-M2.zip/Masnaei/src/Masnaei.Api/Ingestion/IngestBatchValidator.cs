using Masnaei.Acquisition.Contracts;
using Masnaei.Modules.Production.Domain;

namespace Masnaei.Api.Ingestion;

/// <summary>Pure, database-free validation of an ingest batch. Whatever it rejects is never stored.</summary>
public static class IngestBatchValidator
{
    public const int MaxReadings = 5000;
    public const int MaxCycles = 500;
    public const int MaxMotorEvents = 1000;
    public const int MaxErrors = 50;

    public static readonly TimeSpan FutureTolerance = TimeSpan.FromMinutes(5);
    public static readonly DateTimeOffset Earliest = new(2000, 1, 1, 0, 0, 0, TimeSpan.Zero);

    public static IReadOnlyList<string> Validate(IngestBatchRequest request, DateTimeOffset nowUtc)
    {
        ArgumentNullException.ThrowIfNull(request);
        var errors = new List<string>();

        void Add(string message)
        {
            if (errors.Count < MaxErrors) errors.Add(message);
        }

        bool TimeOk(DateTimeOffset t) => t >= Earliest && t <= nowUtc + FutureTolerance;

        if (request.BatchId == Guid.Empty) Add("batchId is required.");

        var readings = request.Readings ?? new List<IngestReading>();
        var cycles = request.Cycles ?? new List<IngestCycle>();
        var motors = request.MotorEvents ?? new List<IngestMotorEvent>();

        if (readings.Count == 0 && cycles.Count == 0 && motors.Count == 0 && request.GatewayHealth is null)
            Add("The batch is empty.");
        if (readings.Count > MaxReadings) Add($"At most {MaxReadings} readings per batch.");
        if (cycles.Count > MaxCycles) Add($"At most {MaxCycles} cycles per batch.");
        if (motors.Count > MaxMotorEvents) Add($"At most {MaxMotorEvents} motor events per batch.");

        for (var i = 0; i < Math.Min(readings.Count, MaxReadings); i++)
        {
            var r = readings[i];
            if (r is null) { Add($"readings[{i}] is null."); continue; }
            if (string.IsNullOrWhiteSpace(r.TagKey) || r.TagKey.Length > 100) Add($"readings[{i}].tagKey is required (max 100 characters).");
            if (!TimeOk(r.TimestampUtc)) Add($"readings[{i}].timestampUtc is outside the accepted range.");
            if (!Enum.IsDefined(r.Quality)) Add($"readings[{i}].quality is not a valid value.");
            if (!Enum.IsDefined(r.Origin)) Add($"readings[{i}].origin is not a valid value.");
            if (r.Value is double v && !double.IsFinite(v)) Add($"readings[{i}].value must be finite.");
            if (r.RawValue is double rv && !double.IsFinite(rv)) Add($"readings[{i}].rawValue must be finite.");
            if (r.Quality == SampleQuality.Good && r.Value is null) Add($"readings[{i}] has quality Good but no value.");
        }

        for (var i = 0; i < Math.Min(cycles.Count, MaxCycles); i++)
        {
            var c = cycles[i];
            if (c is null) { Add($"cycles[{i}] is null."); continue; }
            if (c.ClientCycleId == Guid.Empty) Add($"cycles[{i}].clientCycleId is required.");
            if (!TimeOk(c.StartUtc)) Add($"cycles[{i}].startUtc is outside the accepted range.");
            if (c.EndUtc is { } end)
            {
                if (!TimeOk(end)) Add($"cycles[{i}].endUtc is outside the accepted range.");
                if (end < c.StartUtc) Add($"cycles[{i}].endUtc is before startUtc.");
            }
            if (c.Status == CycleStatus.Completed && c.EndUtc is null) Add($"cycles[{i}] is Completed but has no endUtc.");
            if (!Enum.IsDefined(c.Status)) Add($"cycles[{i}].status is not a valid value.");
            if (!Enum.IsDefined(c.DetectionMode)) Add($"cycles[{i}].detectionMode is not a valid value.");
            if (string.IsNullOrWhiteSpace(c.DetectorVersion) || c.DetectorVersion.Length > 50) Add($"cycles[{i}].detectorVersion is required (max 50 characters).");
        }

        for (var i = 0; i < Math.Min(motors.Count, MaxMotorEvents); i++)
        {
            var m = motors[i];
            if (m is null) { Add($"motorEvents[{i}] is null."); continue; }
            if (string.IsNullOrWhiteSpace(m.MotorId) || m.MotorId.Length > 100) Add($"motorEvents[{i}].motorId is required (max 100 characters).");
            if (!TimeOk(m.TimestampUtc)) Add($"motorEvents[{i}].timestampUtc is outside the accepted range.");
            if (!Enum.IsDefined(m.EventType)) Add($"motorEvents[{i}].eventType is not a valid value.");
        }

        if (request.GatewayHealth is { } h)
        {
            if (!TimeOk(h.TimestampUtc)) Add("gatewayHealth.timestampUtc is outside the accepted range.");
            if (h.BufferDepth < 0) Add("gatewayHealth.bufferDepth must not be negative.");
            if (h.BufferCapacity < 0) Add("gatewayHealth.bufferCapacity must not be negative.");
            if (h.PendingBatches < 0) Add("gatewayHealth.pendingBatches must not be negative.");
            if (!Enum.IsDefined(h.SyncStatus)) Add("gatewayHealth.syncStatus is not a valid value.");
            if (h.Plcs is { Count: > 100 }) Add("gatewayHealth.plcs has too many entries.");
            foreach (var p in h.Plcs ?? new List<IngestPlcHealth>())
            {
                if (p is null) { Add("gatewayHealth.plcs contains a null entry."); continue; }
                if (!Enum.IsDefined(p.State)) Add($"gatewayHealth.plcs[{p.PlcDeviceId}].state is not a valid value.");
                if (p.LastError is { Length: > 500 }) Add($"gatewayHealth.plcs[{p.PlcDeviceId}].lastError is too long (max 500).");
            }
        }

        return errors;
    }
}
