using System.Security.Claims;
using Masnaei.SharedKernel;

namespace Masnaei.Api.Ingestion;

public static class IngestEndpoints
{
    public const int MaxBodyBytes = 5 * 1024 * 1024;

    public static IEndpointRouteBuilder MapIngestEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapPost("/api/v1/ingest/batches", Ingest)
            .RequireAuthorization(AuthPolicies.Gateway)
            .WithTags("Ingestion (gateway)")
            .WithMetadata(new Microsoft.AspNetCore.Mvc.RequestSizeLimitAttribute(MaxBodyBytes))
            .Produces<IngestResult>(StatusCodes.Status202Accepted)
            .Produces<IngestResult>(StatusCodes.Status200OK)
            .ProducesValidationProblem()
            .ProducesProblem(StatusCodes.Status409Conflict);
        return app;
    }

    private static async Task<IResult> Ingest(
        IngestBatchRequest request, ClaimsPrincipal user, IngestionService service, CancellationToken ct)
    {
        if (!int.TryParse(user.FindFirstValue(AuthClaims.GatewayId), out var gatewayId))
            return Results.Forbid();

        var outcome = await service.IngestAsync(gatewayId, request, ct);
        return outcome.Status switch
        {
            IngestStatus.Accepted => Results.Accepted(value: outcome.Result),
            IngestStatus.Duplicate => Results.Ok(outcome.Result),
            IngestStatus.Invalid => Results.ValidationProblem(new Dictionary<string, string[]> { ["batch"] = outcome.Errors.ToArray() }),
            _ => Results.Problem(statusCode: StatusCodes.Status409Conflict, title: "Conflict", detail: string.Join(" ", outcome.Errors))
        };
    }
}
