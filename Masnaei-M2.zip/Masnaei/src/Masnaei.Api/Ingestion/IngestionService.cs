using Masnaei.Acquisition.Contracts;
using Masnaei.Modules.Production;
using Masnaei.Modules.Registry;
using Masnaei.Modules.Registry.Domain;
using Masnaei.Modules.Telemetry;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace Masnaei.Api.Ingestion;

/// <summary>
/// Coordinates one ingest batch across modules. Everything in a batch is validated first and then saved in a single
/// transaction, so a rejected batch leaves no partial data behind.
/// </summary>
public sealed class IngestionService(
    DbContext db,
    IRegistryDirectory registry,
    ITelemetryStore telemetry,
    IProductionStore production,
    TimeProvider time)
{
    public async Task<IngestOutcome> IngestAsync(int gatewayId, IngestBatchRequest request, CancellationToken ct)
    {
        var now = time.GetUtcNow();
        var errors = new List<string>(IngestBatchValidator.Validate(request, now));
        if (errors.Count > 0) return Invalid(errors);

        if (await telemetry.BatchExistsAsync(gatewayId, request.BatchId, ct))
            return DuplicateOutcome(request);

        var readings = request.Readings ?? new List<IngestReading>();
        var cycles = request.Cycles ?? new List<IngestCycle>();
        var motors = request.MotorEvents ?? new List<IngestMotorEvent>();
        var health = request.GatewayHealth;

        var dataPlcIds = readings.Select(r => r.PlcDeviceId)
            .Concat(cycles.Select(c => c.PlcDeviceId))
            .Concat(motors.Select(m => m.PlcDeviceId))
            .Distinct().ToList();
        var healthPlcIds = (health?.Plcs ?? new List<IngestPlcHealth>()).Select(p => p.PlcDeviceId).Distinct().ToList();
        var allPlcIds = dataPlcIds.Concat(healthPlcIds).Distinct().ToList();

        var plcs = await registry.GetPlcsByIdAsync(allPlcIds, ct);
        foreach (var id in allPlcIds)
        {
            if (!plcs.TryGetValue(id, out var plc))
                errors.Add($"plcDeviceId {id} does not exist.");
            else if (plc.GatewayId != gatewayId)
                errors.Add($"plcDeviceId {id} is not assigned to this gateway.");
            else if (dataPlcIds.Contains(id) && plc.Status != PlcDeviceStatus.Active)
                errors.Add($"plcDeviceId {id} is not active.");
        }
        if (errors.Count > 0) return Invalid(errors);

        var tags = await registry.GetActiveTagsAsync(dataPlcIds, ct);
        var readingInputs = new List<ReadingInput>(readings.Count);
        var seen = new HashSet<(int, int, DateTime)>();

        for (var i = 0; i < readings.Count; i++)
        {
            var r = readings[i];
            var plc = plcs[r.PlcDeviceId];

            if (!tags.TryGetValue((r.PlcDeviceId, r.TagKey), out var tag))
            {
                errors.Add($"readings[{i}]: tag '{r.TagKey}' is not an active tag of PLC {r.PlcDeviceId}.");
                continue;
            }
            if (!tag.IsConfirmed)
            {
                errors.Add($"readings[{i}]: tag '{r.TagKey}' is not confirmed, so its data is not accepted.");
                continue;
            }
            // Simulated data may only come from simulated PLCs, and live data only from real ones.
            if (plc.IsSimulated != (r.Origin == DataOrigin.Simulated))
            {
                errors.Add($"readings[{i}]: origin {r.Origin} does not match PLC {r.PlcDeviceId} (simulated: {plc.IsSimulated}).");
                continue;
            }

            var timestamp = r.TimestampUtc.UtcDateTime;
            if (!seen.Add((r.PlcDeviceId, tag.Id, timestamp)))
            {
                errors.Add($"readings[{i}]: duplicate reading for tag '{r.TagKey}' at the same timestamp in this batch.");
                continue;
            }

            readingInputs.Add(new ReadingInput(plc.MachineId, r.PlcDeviceId, tag.Id, timestamp, r.Value, r.RawValue, r.Quality, r.Origin));
        }
        if (errors.Count > 0) return Invalid(errors);

        var received = now.UtcDateTime;
        telemetry.StageBatch(gatewayId, request.BatchId, received, readings.Count, cycles.Count, motors.Count, health is not null);
        telemetry.StageReadings(readingInputs, received);

        production.StageCycles(cycles.Select(c => new CycleInput(
            plcs[c.PlcDeviceId].MachineId, c.PlcDeviceId, c.ClientCycleId, c.CycleNumber, c.StartUtc.UtcDateTime,
            c.EndUtc?.UtcDateTime, c.Status, c.DetectionMode, c.DetectorVersion)), received);

        production.StageMotorEvents(motors.Select(m => new MotorEventInput(
            plcs[m.PlcDeviceId].MachineId, m.PlcDeviceId, m.MotorId, m.TimestampUtc.UtcDateTime, m.EventType,
            m.Commanded, m.Confirmed, m.IsAbnormal)), received);

        if (health is not null)
        {
            telemetry.StageGatewayHealth(gatewayId, new GatewayHealthInput(
                health.TimestampUtc.UtcDateTime, health.SoftwareVersion, health.ClockDriftMs, health.BufferDepth,
                health.BufferCapacity, health.BufferBytes, health.LastSyncUtc?.UtcDateTime, health.SyncStatus,
                health.PendingBatches,
                (health.Plcs ?? new List<IngestPlcHealth>()).Select(p => new PlcHealthInput(
                    p.PlcDeviceId, p.State, p.LastSuccessUtc?.UtcDateTime, p.ConsecutiveFailures, p.RoundTripMs, p.LastError)).ToList()),
                received);
        }

        try
        {
            await db.SaveChangesAsync(ct);
        }
        catch (DbUpdateException ex) when (IsUniqueViolation(ex))
        {
            db.ChangeTracker.Clear();
            if (await telemetry.BatchExistsAsync(gatewayId, request.BatchId, ct))
                return DuplicateOutcome(request);

            return new IngestOutcome(IngestStatus.Conflict,
                new[] { "The batch contains readings or cycles that are already stored. Nothing from this batch was saved." }, null);
        }

        return new IngestOutcome(IngestStatus.Accepted, Array.Empty<string>(),
            new IngestResult(false, readingInputs.Count, cycles.Count, motors.Count, health is not null));
    }

    private static IngestOutcome Invalid(IReadOnlyList<string> errors) =>
        new(IngestStatus.Invalid, errors, null);

    private static IngestOutcome DuplicateOutcome(IngestBatchRequest request) =>
        new(IngestStatus.Duplicate, Array.Empty<string>(),
            new IngestResult(true, request.Readings?.Count ?? 0, request.Cycles?.Count ?? 0, request.MotorEvents?.Count ?? 0,
                request.GatewayHealth is not null));

    private static bool IsUniqueViolation(DbUpdateException ex) =>
        ex.InnerException is SqlException { Number: 2627 or 2601 };
}
