using Masnaei.Acquisition.Contracts;
using Masnaei.Modules.Production.Domain;
using Masnaei.Modules.Telemetry.Domain;

namespace Masnaei.Api.Ingestion;

public sealed record IngestReading(
    int PlcDeviceId, string TagKey, DateTimeOffset TimestampUtc, double? Value, double? RawValue,
    SampleQuality Quality, DataOrigin Origin);

public sealed record IngestCycle(
    int PlcDeviceId, Guid ClientCycleId, long? CycleNumber, DateTimeOffset StartUtc, DateTimeOffset? EndUtc,
    CycleStatus Status, CycleDetectionMode DetectionMode, string DetectorVersion);

public sealed record IngestMotorEvent(
    int PlcDeviceId, string MotorId, DateTimeOffset TimestampUtc, MotorEventType EventType,
    bool? Commanded, bool? Confirmed, bool IsAbnormal);

public sealed record IngestPlcHealth(
    int PlcDeviceId, PlcConnectionState State, DateTimeOffset? LastSuccessUtc, int ConsecutiveFailures,
    double? RoundTripMs, string? LastError);

public sealed record IngestGatewayHealth(
    DateTimeOffset TimestampUtc, string? SoftwareVersion, double? ClockDriftMs, int BufferDepth, int BufferCapacity,
    long? BufferBytes, DateTimeOffset? LastSyncUtc, SyncStatus SyncStatus, int PendingBatches,
    List<IngestPlcHealth>? Plcs);

/// <summary>
/// One idempotent upload from a gateway. Sending the same BatchId again is safe and stores nothing twice.
/// The gateway identity comes from its API key, never from the payload.
/// </summary>
public sealed record IngestBatchRequest(
    Guid BatchId,
    DateTimeOffset SentUtc,
    List<IngestReading>? Readings,
    List<IngestCycle>? Cycles,
    List<IngestMotorEvent>? MotorEvents,
    IngestGatewayHealth? GatewayHealth);

public sealed record IngestResult(bool Duplicate, int Readings, int Cycles, int MotorEvents, bool HealthStored);

public enum IngestStatus
{
    Accepted,
    Duplicate,
    Invalid,
    Conflict
}

public sealed record IngestOutcome(IngestStatus Status, IReadOnlyList<string> Errors, IngestResult? Result);
