using Masnaei.Acquisition.Contracts;
using Masnaei.Modules.Registry;
using Masnaei.Modules.Telemetry.Domain;
using Masnaei.SharedKernel;

namespace Masnaei.Modules.Telemetry;

public sealed record ReadingPoint(
    int PlcDeviceId, DateTime TimestampUtc, double? Value, double? RawValue, SampleQuality Quality, DataOrigin Origin);

public sealed record ReadingsResponse(
    int MachineId, string TagKey, IReadOnlyList<int> PlcDeviceIds, IReadOnlyList<ReadingPoint> Items, DateTime? NextFromUtc);

public sealed record PlcHealthDto(
    int PlcDeviceId, PlcConnectionState State, DateTime? LastSuccessUtc, int ConsecutiveFailures, double? RoundTripMs, string? LastError);

public sealed record GatewayHealthDto(
    int GatewayId, DateTime TimestampUtc, DateTime ReceivedUtc, string? SoftwareVersion, double? ClockDriftMs,
    int BufferDepth, int BufferCapacity, long? BufferBytes, DateTime? LastSyncUtc, SyncStatus SyncStatus,
    int PendingBatches, IReadOnlyList<PlcHealthDto> Plcs);

public static class TelemetryModule
{
    public const int DefaultLimit = 1000;
    public const int MaxLimit = 10_000;
    public static readonly TimeSpan MaxRange = TimeSpan.FromDays(31);

    public static IServiceCollection AddTelemetryModule(this IServiceCollection services)
    {
        services.AddScoped<ITelemetryStore, TelemetryStore>();
        return services;
    }

    public static IEndpointRouteBuilder MapTelemetryEndpoints(this IEndpointRouteBuilder app)
    {
        var read = app.MapGroup("/api/v1").RequireAuthorization(AuthPolicies.Reader).WithTags("Telemetry (read)");
        read.MapGet("/machines/{machineId:int}/readings", GetReadings);
        read.MapGet("/gateways/{gatewayId:int}/health/latest", GetLatestHealth);
        return app;
    }

    private static async Task<IResult> GetReadings(
        int machineId, string? tagKey, DateTimeOffset? fromUtc, DateTimeOffset? toUtc, int? limit,
        DbContext db, IRegistryDirectory registry, CancellationToken ct)
    {
        var errors = new Dictionary<string, string[]>();
        if (string.IsNullOrWhiteSpace(tagKey)) errors["tagKey"] = new[] { "tagKey is required." };
        if (fromUtc is null) errors["fromUtc"] = new[] { "fromUtc is required." };
        if (toUtc is null) errors["toUtc"] = new[] { "toUtc is required." };
        if (fromUtc is not null && toUtc is not null)
        {
            if (toUtc < fromUtc) errors["toUtc"] = new[] { "toUtc must not be before fromUtc." };
            else if (toUtc - fromUtc > MaxRange) errors["toUtc"] = new[] { $"The range must not exceed {MaxRange.TotalDays:0} days." };
        }
        var take = limit ?? DefaultLimit;
        if (take < 1 || take > MaxLimit) errors["limit"] = new[] { $"limit must be 1-{MaxLimit}." };
        if (errors.Count > 0) return Results.ValidationProblem(errors);

        if (!await registry.MachineExistsAsync(machineId, ct)) return Results.NotFound();
        var tags = await registry.FindActiveTagsAsync(machineId, tagKey!, ct);
        if (tags.Count == 0) return Results.NotFound();

        var tagIds = tags.Select(t => t.Id).ToList();
        var from = fromUtc!.Value.UtcDateTime;
        var to = toUtc!.Value.UtcDateTime;

        var rows = await db.Set<SensorReading>().AsNoTracking()
            .Where(r => tagIds.Contains(r.TagId) && r.SourceTimeUtc >= from && r.SourceTimeUtc <= to)
            .OrderBy(r => r.SourceTimeUtc)
            .Take(take + 1)
            .ToListAsync(ct);

        DateTime? next = null;
        if (rows.Count > take)
        {
            next = rows[take].SourceTimeUtc;   // first row of the next page
            rows = rows.Take(take).ToList();
        }

        var items = rows.Select(r => new ReadingPoint(r.PlcDeviceId, r.SourceTimeUtc, r.Value, r.RawValue, r.Quality, r.Origin)).ToList();
        return Results.Ok(new ReadingsResponse(machineId, tagKey!, tags.Select(t => t.PlcDeviceId).Distinct().ToList(), items, next));
    }

    private static async Task<IResult> GetLatestHealth(int gatewayId, DbContext db, IRegistryDirectory registry, CancellationToken ct)
    {
        if (!await registry.GatewayExistsAsync(gatewayId, ct)) return Results.NotFound();

        var h = await db.Set<GatewayHealth>().AsNoTracking().Include(x => x.Plcs)
            .Where(x => x.GatewayId == gatewayId)
            .OrderByDescending(x => x.TimestampUtc)
            .FirstOrDefaultAsync(ct);
        if (h is null) return Results.NotFound();

        return Results.Ok(new GatewayHealthDto(
            h.GatewayId, h.TimestampUtc, h.ReceivedUtc, h.SoftwareVersion, h.ClockDriftMs, h.BufferDepth, h.BufferCapacity,
            h.BufferBytes, h.LastSyncUtc, h.SyncStatus, h.PendingBatches,
            h.Plcs.OrderBy(p => p.PlcDeviceId)
                .Select(p => new PlcHealthDto(p.PlcDeviceId, p.State, p.LastSuccessUtc, p.ConsecutiveFailures, p.RoundTripMs, p.LastError))
                .ToList()));
    }
}
