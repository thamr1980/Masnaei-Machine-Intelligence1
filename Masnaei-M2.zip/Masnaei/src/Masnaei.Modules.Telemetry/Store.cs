using Masnaei.Acquisition.Contracts;
using Masnaei.Modules.Telemetry.Domain;

namespace Masnaei.Modules.Telemetry;

public sealed record ReadingInput(
    int MachineId, int PlcDeviceId, int TagId, DateTime TimestampUtc,
    double? Value, double? RawValue, SampleQuality Quality, DataOrigin Origin);

public sealed record PlcHealthInput(
    int PlcDeviceId, PlcConnectionState State, DateTime? LastSuccessUtc,
    int ConsecutiveFailures, double? RoundTripMs, string? LastError);

public sealed record GatewayHealthInput(
    DateTime TimestampUtc, string? SoftwareVersion, double? ClockDriftMs, int BufferDepth, int BufferCapacity,
    long? BufferBytes, DateTime? LastSyncUtc, SyncStatus SyncStatus, int PendingBatches,
    IReadOnlyList<PlcHealthInput> Plcs);

/// <summary>Stages telemetry rows on the shared unit of work. The caller saves everything in one transaction.</summary>
public interface ITelemetryStore
{
    Task<bool> BatchExistsAsync(int gatewayId, Guid clientBatchId, CancellationToken ct);

    void StageBatch(int gatewayId, Guid clientBatchId, DateTime receivedUtc, int readings, int cycles, int motorEvents, bool hasHealth);

    void StageReadings(IEnumerable<ReadingInput> readings, DateTime receivedUtc);

    void StageGatewayHealth(int gatewayId, GatewayHealthInput health, DateTime receivedUtc);
}

public sealed class TelemetryStore(DbContext db) : ITelemetryStore
{
    public Task<bool> BatchExistsAsync(int gatewayId, Guid clientBatchId, CancellationToken ct) =>
        db.Set<IngestBatch>().AnyAsync(b => b.GatewayId == gatewayId && b.ClientBatchId == clientBatchId, ct);

    public void StageBatch(int gatewayId, Guid clientBatchId, DateTime receivedUtc, int readings, int cycles, int motorEvents, bool hasHealth) =>
        db.Set<IngestBatch>().Add(new IngestBatch
        {
            GatewayId = gatewayId,
            ClientBatchId = clientBatchId,
            ReceivedUtc = receivedUtc,
            ReadingCount = readings,
            CycleCount = cycles,
            MotorEventCount = motorEvents,
            HasHealth = hasHealth
        });

    public void StageReadings(IEnumerable<ReadingInput> readings, DateTime receivedUtc)
    {
        foreach (var r in readings)
        {
            db.Set<SensorReading>().Add(new SensorReading
            {
                PlcDeviceId = r.PlcDeviceId,
                TagId = r.TagId,
                SourceTimeUtc = r.TimestampUtc,
                MachineId = r.MachineId,
                ReceivedTimeUtc = receivedUtc,
                Value = r.Value,
                RawValue = r.RawValue,
                Quality = r.Quality,
                Origin = r.Origin
            });
        }
    }

    public void StageGatewayHealth(int gatewayId, GatewayHealthInput h, DateTime receivedUtc)
    {
        var row = new GatewayHealth
        {
            GatewayId = gatewayId,
            TimestampUtc = h.TimestampUtc,
            ReceivedUtc = receivedUtc,
            SoftwareVersion = h.SoftwareVersion,
            ClockDriftMs = h.ClockDriftMs,
            BufferDepth = h.BufferDepth,
            BufferCapacity = h.BufferCapacity,
            BufferBytes = h.BufferBytes,
            LastSyncUtc = h.LastSyncUtc,
            SyncStatus = h.SyncStatus,
            PendingBatches = h.PendingBatches
        };

        foreach (var p in h.Plcs)
        {
            row.Plcs.Add(new PlcConnectionHealth
            {
                PlcDeviceId = p.PlcDeviceId,
                State = p.State,
                LastSuccessUtc = p.LastSuccessUtc,
                ConsecutiveFailures = p.ConsecutiveFailures,
                RoundTripMs = p.RoundTripMs,
                LastError = p.LastError
            });
        }

        db.Set<GatewayHealth>().Add(row);
    }
}
