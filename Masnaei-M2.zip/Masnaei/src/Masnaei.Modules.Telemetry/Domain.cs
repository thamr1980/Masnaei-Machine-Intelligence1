using Masnaei.Acquisition.Contracts;

namespace Masnaei.Modules.Telemetry.Domain;

/// <summary>
/// One stored measurement. The key (PlcDeviceId, TagId, SourceTimeUtc) makes a reading unique, so the same
/// measurement can never be stored twice. No database foreign keys to registry tables: modules reference each other by id only.
/// </summary>
public sealed class SensorReading
{
    public int PlcDeviceId { get; set; }
    public int TagId { get; set; }
    public DateTime SourceTimeUtc { get; set; }
    public int MachineId { get; set; }
    public DateTime ReceivedTimeUtc { get; set; }
    public double? Value { get; set; }
    public double? RawValue { get; set; }
    public SampleQuality Quality { get; set; }
    public DataOrigin Origin { get; set; }
}

public enum SyncStatus
{
    Idle,
    Syncing,
    Behind,
    Offline
}

public sealed class GatewayHealth
{
    public long Id { get; set; }
    public int GatewayId { get; set; }
    public DateTime TimestampUtc { get; set; }
    public DateTime ReceivedUtc { get; set; }
    public string? SoftwareVersion { get; set; }
    public double? ClockDriftMs { get; set; }
    public int BufferDepth { get; set; }
    public int BufferCapacity { get; set; }
    public long? BufferBytes { get; set; }
    public DateTime? LastSyncUtc { get; set; }
    public SyncStatus SyncStatus { get; set; }
    public int PendingBatches { get; set; }
    public List<PlcConnectionHealth> Plcs { get; set; } = new();
}

public sealed class PlcConnectionHealth
{
    public long Id { get; set; }
    public long GatewayHealthId { get; set; }
    public int PlcDeviceId { get; set; }
    public PlcConnectionState State { get; set; }
    public DateTime? LastSuccessUtc { get; set; }
    public int ConsecutiveFailures { get; set; }
    public double? RoundTripMs { get; set; }
    public string? LastError { get; set; }
}

public sealed class IngestBatch
{
    public long Id { get; set; }
    public int GatewayId { get; set; }
    public Guid ClientBatchId { get; set; }
    public DateTime ReceivedUtc { get; set; }
    public int ReadingCount { get; set; }
    public int CycleCount { get; set; }
    public int MotorEventCount { get; set; }
    public bool HasHealth { get; set; }
}
