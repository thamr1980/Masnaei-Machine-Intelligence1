using Masnaei.Modules.Telemetry.Domain;

namespace Masnaei.Modules.Telemetry;

public sealed class SensorReadingConfiguration : IEntityTypeConfiguration<SensorReading>
{
    public void Configure(EntityTypeBuilder<SensorReading> b)
    {
        b.ToTable("SensorReadings", "telemetry");
        b.HasKey(x => new { x.PlcDeviceId, x.TagId, x.SourceTimeUtc });
        b.Property(x => x.Quality).HasConversion<byte>();
        b.Property(x => x.Origin).HasConversion<byte>();
        b.HasIndex(x => new { x.MachineId, x.SourceTimeUtc });
    }
}

public sealed class GatewayHealthConfiguration : IEntityTypeConfiguration<GatewayHealth>
{
    public void Configure(EntityTypeBuilder<GatewayHealth> b)
    {
        b.ToTable("GatewayHealth", "telemetry");
        b.HasKey(x => x.Id);
        b.Property(x => x.SoftwareVersion).HasMaxLength(50);
        b.Property(x => x.SyncStatus).HasConversion<string>().HasMaxLength(20);
        b.HasIndex(x => new { x.GatewayId, x.TimestampUtc });
        b.HasMany(x => x.Plcs).WithOne().HasForeignKey(p => p.GatewayHealthId).OnDelete(DeleteBehavior.Cascade);
    }
}

public sealed class PlcConnectionHealthConfiguration : IEntityTypeConfiguration<PlcConnectionHealth>
{
    public void Configure(EntityTypeBuilder<PlcConnectionHealth> b)
    {
        b.ToTable("PlcConnectionHealth", "telemetry");
        b.HasKey(x => x.Id);
        b.Property(x => x.State).HasConversion<string>().HasMaxLength(20);
        b.Property(x => x.LastError).HasMaxLength(500);
        b.HasIndex(x => new { x.PlcDeviceId, x.GatewayHealthId });
    }
}

public sealed class IngestBatchConfiguration : IEntityTypeConfiguration<IngestBatch>
{
    public void Configure(EntityTypeBuilder<IngestBatch> b)
    {
        b.ToTable("IngestBatches", "telemetry");
        b.HasKey(x => x.Id);
        b.HasIndex(x => new { x.GatewayId, x.ClientBatchId }).IsUnique();
    }
}
