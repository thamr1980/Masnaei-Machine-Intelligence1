using Masnaei.Acquisition.Contracts;

namespace Masnaei.Modules.Registry.Domain;

public sealed class Factory
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string TimeZoneId { get; set; } = "UTC";
    public DateTime CreatedUtc { get; set; }
}

public sealed class Gateway
{
    public int Id { get; set; }
    public int FactoryId { get; set; }
    public string Name { get; set; } = "";
    public bool IsActive { get; set; } = true;
    public DateTime CreatedUtc { get; set; }
    public List<GatewayCredential> Credentials { get; set; } = new();
}

/// <summary>Only the SHA-256 hash of the gateway's API key is stored; the key itself is shown once at creation.</summary>
public sealed class GatewayCredential
{
    public int Id { get; set; }
    public int GatewayId { get; set; }
    public string KeyPrefix { get; set; } = "";
    public string KeyHash { get; set; } = "";
    public DateTime CreatedUtc { get; set; }
    public DateTime? RevokedUtc { get; set; }
}

public sealed class Machine
{
    public int Id { get; set; }
    public int FactoryId { get; set; }
    public string Code { get; set; } = "";
    public string NameEn { get; set; } = "";
    public string? NameAr { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedUtc { get; set; }
}

public enum PlcDeviceStatus
{
    Draft,
    Active,
    Disabled
}

public sealed class PlcDevice
{
    public int Id { get; set; }
    public int MachineId { get; set; }
    public int GatewayId { get; set; }
    public string Manufacturer { get; set; } = "";
    public string Model { get; set; } = "";
    public string EthernetModuleModel { get; set; } = "";
    public bool IsSimulated { get; set; }
    public PlcDeviceStatus Status { get; set; } = PlcDeviceStatus.Draft;
    public DateTime CreatedUtc { get; set; }
}

/// <summary>Versioned connection settings. No default values: nothing here is assumed about real hardware.</summary>
public sealed class PlcConnectionConfig
{
    public int Id { get; set; }
    public int PlcDeviceId { get; set; }
    public int Version { get; set; }
    public bool IsCurrent { get; set; }
    public string? IpAddress { get; set; }
    public int? Port { get; set; }
    public int? FinsNetwork { get; set; }
    public int? FinsDestinationNode { get; set; }
    public int? FinsSourceNode { get; set; }
    public int TimeoutMs { get; set; }
    public int PollIntervalMs { get; set; }
    public DateTime EffectiveFromUtc { get; set; }
}

public sealed class Tag
{
    public int Id { get; set; }
    public int PlcDeviceId { get; set; }
    public string Key { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string Address { get; set; } = "";
    public TagDataType DataType { get; set; }
    public double Scale { get; set; } = 1.0;
    public double Offset { get; set; }
    public string Unit { get; set; } = "";
    public double? MinValid { get; set; }
    public double? MaxValid { get; set; }
    public string PollGroup { get; set; } = "default";
    public TagRole Role { get; set; } = TagRole.None;
    public string? MotorId { get; set; }
    public bool IsConfirmed { get; set; }
    public bool IsActive { get; set; } = true;
}
