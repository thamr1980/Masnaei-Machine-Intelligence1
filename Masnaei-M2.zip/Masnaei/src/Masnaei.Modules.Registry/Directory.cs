using Masnaei.Modules.Registry.Domain;

namespace Masnaei.Modules.Registry;

public sealed record PlcInfo(int Id, int MachineId, int GatewayId, bool IsSimulated, PlcDeviceStatus Status);

public sealed record TagInfo(int Id, int PlcDeviceId, string Key, bool IsConfirmed);

public sealed record GatewayPrincipalInfo(int GatewayId, string KeyPrefix);

/// <summary>The only way other modules look at registry data. They never touch registry tables directly.</summary>
public interface IRegistryDirectory
{
    Task<IReadOnlyDictionary<int, PlcInfo>> GetPlcsByIdAsync(IReadOnlyCollection<int> plcIds, CancellationToken ct);

    Task<IReadOnlyDictionary<(int PlcId, string Key), TagInfo>> GetActiveTagsAsync(IReadOnlyCollection<int> plcIds, CancellationToken ct);

    Task<bool> MachineExistsAsync(int machineId, CancellationToken ct);

    Task<bool> GatewayExistsAsync(int gatewayId, CancellationToken ct);

    /// <summary>Active tags with the given key on any PLC of the machine.</summary>
    Task<IReadOnlyList<TagInfo>> FindActiveTagsAsync(int machineId, string tagKey, CancellationToken ct);
}

public interface IGatewayCredentialStore
{
    Task<GatewayPrincipalInfo?> FindActiveAsync(string apiKey, CancellationToken ct);
}

public sealed class RegistryDirectory(DbContext db) : IRegistryDirectory, IGatewayCredentialStore
{
    public async Task<IReadOnlyDictionary<int, PlcInfo>> GetPlcsByIdAsync(IReadOnlyCollection<int> plcIds, CancellationToken ct)
    {
        var ids = plcIds.ToList();
        var rows = await db.Set<PlcDevice>().AsNoTracking()
            .Where(p => ids.Contains(p.Id))
            .Select(p => new PlcInfo(p.Id, p.MachineId, p.GatewayId, p.IsSimulated, p.Status))
            .ToListAsync(ct);
        return rows.ToDictionary(p => p.Id);
    }

    public async Task<IReadOnlyDictionary<(int PlcId, string Key), TagInfo>> GetActiveTagsAsync(IReadOnlyCollection<int> plcIds, CancellationToken ct)
    {
        var ids = plcIds.ToList();
        var rows = await db.Set<Tag>().AsNoTracking()
            .Where(t => ids.Contains(t.PlcDeviceId) && t.IsActive)
            .Select(t => new TagInfo(t.Id, t.PlcDeviceId, t.Key, t.IsConfirmed))
            .ToListAsync(ct);
        return rows.ToDictionary(t => (t.PlcDeviceId, t.Key));
    }

    public Task<bool> MachineExistsAsync(int machineId, CancellationToken ct) =>
        db.Set<Machine>().AnyAsync(m => m.Id == machineId, ct);

    public Task<bool> GatewayExistsAsync(int gatewayId, CancellationToken ct) =>
        db.Set<Gateway>().AnyAsync(g => g.Id == gatewayId, ct);

    public async Task<IReadOnlyList<TagInfo>> FindActiveTagsAsync(int machineId, string tagKey, CancellationToken ct)
    {
        return await (from t in db.Set<Tag>().AsNoTracking()
                      join p in db.Set<PlcDevice>().AsNoTracking() on t.PlcDeviceId equals p.Id
                      where p.MachineId == machineId && t.Key == tagKey && t.IsActive
                      select new TagInfo(t.Id, t.PlcDeviceId, t.Key, t.IsConfirmed))
            .ToListAsync(ct);
    }

    public async Task<GatewayPrincipalInfo?> FindActiveAsync(string apiKey, CancellationToken ct)
    {
        var hash = Masnaei.SharedKernel.ApiKeys.Hash(apiKey);
        return await (from c in db.Set<GatewayCredential>().AsNoTracking()
                      join g in db.Set<Gateway>().AsNoTracking() on c.GatewayId equals g.Id
                      where c.KeyHash == hash && c.RevokedUtc == null && g.IsActive
                      select new GatewayPrincipalInfo(g.Id, c.KeyPrefix))
            .FirstOrDefaultAsync(ct);
    }
}
