using Masnaei.Acquisition.Contracts;
using Masnaei.Modules.Registry.Domain;

namespace Masnaei.Modules.Registry;

public sealed record CreateFactoryRequest(string Name, string? TimeZoneId);
public sealed record FactoryDto(int Id, string Name, string TimeZoneId);

public sealed record CreateGatewayRequest(int FactoryId, string Name);
public sealed record GatewayCreatedDto(int Id, int FactoryId, string Name, string ApiKey, string KeyPrefix);

public sealed record CreateMachineRequest(int FactoryId, string Code, string NameEn, string? NameAr);

public sealed record CreatePlcRequest(int GatewayId, string Manufacturer, string Model, string EthernetModuleModel, bool IsSimulated);

public sealed record PlcSummaryDto(
    int Id, int MachineId, int GatewayId, string Manufacturer, string Model,
    string EthernetModuleModel, PlcDeviceStatus Status, bool IsSimulated);

public sealed record MachineDto(
    int Id, int FactoryId, string Code, string NameEn, string? NameAr, bool IsActive,
    IReadOnlyList<PlcSummaryDto> Plcs);

public sealed record ConnectionConfigRequest(
    string? IpAddress, int? Port, int? FinsNetwork, int? FinsDestinationNode, int? FinsSourceNode,
    int TimeoutMs, int PollIntervalMs);

public sealed record ConnectionConfigDto(
    int PlcDeviceId, int Version, string? IpAddress, int? Port, int? FinsNetwork,
    int? FinsDestinationNode, int? FinsSourceNode, int TimeoutMs, int PollIntervalMs);

public sealed record TagRequest(
    string Key,
    TagDataType DataType,
    string? DisplayName = null,
    string? Address = null,
    double Scale = 1.0,
    double Offset = 0.0,
    string? Unit = null,
    double? MinValid = null,
    double? MaxValid = null,
    string? PollGroup = null,
    TagRole Role = TagRole.None,
    string? MotorId = null,
    bool IsConfirmed = false);

public sealed record SetTagsRequest(List<TagRequest> Tags);

public sealed record TagDto(
    int Id, string Key, string DisplayName, string Address, TagDataType DataType, double Scale, double Offset,
    string Unit, double? MinValid, double? MaxValid, string PollGroup, TagRole Role, string? MotorId,
    bool IsConfirmed, bool IsActive);

public sealed record GatewayPlcConfigDto(
    int PlcDeviceId, int MachineId, bool IsSimulated, ConnectionConfigDto? Connection, IReadOnlyList<TagDto> Tags);

public sealed record GatewayConfigDto(int GatewayId, IReadOnlyList<GatewayPlcConfigDto> Plcs);
