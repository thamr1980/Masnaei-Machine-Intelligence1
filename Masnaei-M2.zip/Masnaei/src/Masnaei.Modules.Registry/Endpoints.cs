using System.Net;
using System.Net.Sockets;
using System.Security.Claims;
using System.Text.RegularExpressions;
using Masnaei.Acquisition.Contracts;
using Masnaei.Modules.Registry.Domain;
using Masnaei.SharedKernel;

namespace Masnaei.Modules.Registry;

public static class RegistryModule
{
    public static IServiceCollection AddRegistryModule(this IServiceCollection services)
    {
        services.AddScoped<RegistryDirectory>();
        services.AddScoped<IRegistryDirectory>(sp => sp.GetRequiredService<RegistryDirectory>());
        services.AddScoped<IGatewayCredentialStore>(sp => sp.GetRequiredService<RegistryDirectory>());
        return services;
    }

    public static IEndpointRouteBuilder MapRegistryEndpoints(this IEndpointRouteBuilder app)
    {
        var admin = app.MapGroup("/api/v1").RequireAuthorization(AuthPolicies.Admin).WithTags("Registry (admin)");
        admin.MapPost("/factories", RegistryHandlers.CreateFactory);
        admin.MapPost("/gateways", RegistryHandlers.CreateGateway);
        admin.MapPost("/machines", RegistryHandlers.CreateMachine);
        admin.MapPost("/machines/{machineId:int}/plcs", RegistryHandlers.CreatePlc);
        admin.MapPut("/plcs/{plcId:int}/connection-config", RegistryHandlers.SetConnectionConfig);
        admin.MapPut("/plcs/{plcId:int}/tags", RegistryHandlers.SetTags);
        admin.MapPost("/plcs/{plcId:int}/activate", RegistryHandlers.ActivatePlc);

        var read = app.MapGroup("/api/v1").RequireAuthorization(AuthPolicies.Reader).WithTags("Registry (read)");
        read.MapGet("/machines", RegistryHandlers.ListMachines);
        read.MapGet("/plcs/{plcId:int}/tags", RegistryHandlers.GetTags);

        var gateway = app.MapGroup("/api/v1/gateway").RequireAuthorization(AuthPolicies.Gateway).WithTags("Gateway");
        gateway.MapGet("/config", RegistryHandlers.GetGatewayConfig);

        return app;
    }
}

internal static class RegistryHandlers
{
    private static readonly Regex MachineCode = new("^[A-Za-z0-9_-]{1,50}$", RegexOptions.Compiled);

    private static IResult Invalid(string field, string message) =>
        Results.ValidationProblem(new Dictionary<string, string[]> { [field] = new[] { message } });

    private static IResult Invalid(IEnumerable<string> messages) =>
        Results.ValidationProblem(new Dictionary<string, string[]> { ["request"] = messages.ToArray() });

    public static async Task<IResult> CreateFactory(CreateFactoryRequest r, DbContext db, TimeProvider time, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(r.Name) || r.Name.Length > 200)
            return Invalid("name", "Name is required (max 200 characters).");

        var tz = string.IsNullOrWhiteSpace(r.TimeZoneId) ? "UTC" : r.TimeZoneId!;
        try { TimeZoneInfo.FindSystemTimeZoneById(tz); }
        catch (TimeZoneNotFoundException) { return Invalid("timeZoneId", $"Unknown time zone '{tz}'."); }
        catch (InvalidTimeZoneException) { return Invalid("timeZoneId", $"Invalid time zone '{tz}'."); }

        var factory = new Factory { Name = r.Name.Trim(), TimeZoneId = tz, CreatedUtc = time.GetUtcNow().UtcDateTime };
        db.Set<Factory>().Add(factory);
        await db.SaveChangesAsync(ct);
        return Results.Created($"/api/v1/factories/{factory.Id}", new FactoryDto(factory.Id, factory.Name, factory.TimeZoneId));
    }

    public static async Task<IResult> CreateGateway(CreateGatewayRequest r, DbContext db, TimeProvider time, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(r.Name) || r.Name.Length > 200)
            return Invalid("name", "Name is required (max 200 characters).");
        if (!await db.Set<Factory>().AnyAsync(f => f.Id == r.FactoryId, ct))
            return Invalid("factoryId", "Factory does not exist.");

        var now = time.GetUtcNow().UtcDateTime;
        var (key, prefix, hash) = ApiKeys.Generate();
        var gateway = new Gateway { FactoryId = r.FactoryId, Name = r.Name.Trim(), CreatedUtc = now };
        gateway.Credentials.Add(new GatewayCredential { KeyPrefix = prefix, KeyHash = hash, CreatedUtc = now });
        db.Set<Gateway>().Add(gateway);
        await db.SaveChangesAsync(ct);

        // The plaintext key is returned exactly once and never stored.
        return Results.Created($"/api/v1/gateways/{gateway.Id}",
            new GatewayCreatedDto(gateway.Id, gateway.FactoryId, gateway.Name, key, prefix));
    }

    public static async Task<IResult> CreateMachine(CreateMachineRequest r, DbContext db, TimeProvider time, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(r.Code) || !MachineCode.IsMatch(r.Code))
            return Invalid("code", "Code must be 1-50 characters: letters, digits, '-' or '_'.");
        if (string.IsNullOrWhiteSpace(r.NameEn) || r.NameEn.Length > 200)
            return Invalid("nameEn", "English name is required (max 200 characters).");
        if (r.NameAr is { Length: > 200 })
            return Invalid("nameAr", "Arabic name is too long (max 200 characters).");
        if (!await db.Set<Factory>().AnyAsync(f => f.Id == r.FactoryId, ct))
            return Invalid("factoryId", "Factory does not exist.");
        if (await db.Set<Machine>().AnyAsync(m => m.FactoryId == r.FactoryId && m.Code == r.Code, ct))
            return Results.Problem(statusCode: StatusCodes.Status409Conflict, title: "Machine code already exists in this factory.");

        var machine = new Machine
        {
            FactoryId = r.FactoryId,
            Code = r.Code,
            NameEn = r.NameEn.Trim(),
            NameAr = r.NameAr?.Trim(),
            CreatedUtc = time.GetUtcNow().UtcDateTime
        };
        db.Set<Machine>().Add(machine);
        await db.SaveChangesAsync(ct);
        return Results.Created($"/api/v1/machines/{machine.Id}",
            new MachineDto(machine.Id, machine.FactoryId, machine.Code, machine.NameEn, machine.NameAr, machine.IsActive,
                Array.Empty<PlcSummaryDto>()));
    }

    public static async Task<IResult> CreatePlc(int machineId, CreatePlcRequest r, DbContext db, TimeProvider time, CancellationToken ct)
    {
        var machine = await db.Set<Machine>().AsNoTracking().FirstOrDefaultAsync(m => m.Id == machineId, ct);
        if (machine is null) return Results.NotFound();

        foreach (var (field, value) in new[]
        {
            ("manufacturer", r.Manufacturer), ("model", r.Model), ("ethernetModuleModel", r.EthernetModuleModel)
        })
        {
            if (string.IsNullOrWhiteSpace(value) || value.Length > 100)
                return Invalid(field, "Required (max 100 characters).");
        }

        var gateway = await db.Set<Gateway>().AsNoTracking().FirstOrDefaultAsync(g => g.Id == r.GatewayId, ct);
        if (gateway is null) return Invalid("gatewayId", "Gateway does not exist.");
        if (gateway.FactoryId != machine.FactoryId) return Invalid("gatewayId", "Gateway belongs to a different factory.");

        var plc = new PlcDevice
        {
            MachineId = machineId,
            GatewayId = r.GatewayId,
            Manufacturer = r.Manufacturer.Trim(),
            Model = r.Model.Trim(),
            EthernetModuleModel = r.EthernetModuleModel.Trim(),
            IsSimulated = r.IsSimulated,
            Status = PlcDeviceStatus.Draft,
            CreatedUtc = time.GetUtcNow().UtcDateTime
        };
        db.Set<PlcDevice>().Add(plc);
        await db.SaveChangesAsync(ct);
        return Results.Created($"/api/v1/plcs/{plc.Id}", ToSummary(plc));
    }

    public static async Task<IResult> SetConnectionConfig(int plcId, ConnectionConfigRequest r, DbContext db, TimeProvider time, CancellationToken ct)
    {
        var plc = await db.Set<PlcDevice>().AsNoTracking().FirstOrDefaultAsync(p => p.Id == plcId, ct);
        if (plc is null) return Results.NotFound();

        string? normalizedIp = null;
        if (r.IpAddress is not null)
        {
            if (!IPAddress.TryParse(r.IpAddress, out var ip) ||
                ip.AddressFamily != AddressFamily.InterNetwork ||
                r.IpAddress.Split('.').Length != 4)
                return Invalid("ipAddress", "Must be a dotted-quad IPv4 address.");
            normalizedIp = ip.ToString();
        }

        if (r.Port is < 1 or > 65535) return Invalid("port", "Port must be 1-65535.");
        foreach (var (field, value) in new[] { ("finsNetwork", r.FinsNetwork), ("finsDestinationNode", r.FinsDestinationNode), ("finsSourceNode", r.FinsSourceNode) })
        {
            if (value is < 0 or > 255) return Invalid(field, "Must be 0-255.");
        }
        if (r.TimeoutMs is < 100 or > 60_000) return Invalid("timeoutMs", "Must be 100-60000.");
        if (r.PollIntervalMs is < 100 or > 3_600_000) return Invalid("pollIntervalMs", "Must be 100-3600000.");

        if (normalizedIp is not null)
        {
            var clash = await (from c in db.Set<PlcConnectionConfig>()
                               join p in db.Set<PlcDevice>() on c.PlcDeviceId equals p.Id
                               where c.IsCurrent && c.IpAddress == normalizedIp && p.GatewayId == plc.GatewayId && p.Id != plc.Id
                               select c.Id).AnyAsync(ct);
            if (clash)
                return Results.Problem(statusCode: StatusCodes.Status409Conflict,
                    title: "Another PLC on the same gateway network already uses this IP address.");
        }

        var existing = await db.Set<PlcConnectionConfig>().Where(c => c.PlcDeviceId == plcId).ToListAsync(ct);
        var version = existing.Count == 0 ? 1 : existing.Max(c => c.Version) + 1;
        foreach (var old in existing) old.IsCurrent = false;

        var config = new PlcConnectionConfig
        {
            PlcDeviceId = plcId,
            Version = version,
            IsCurrent = true,
            IpAddress = normalizedIp,
            Port = r.Port,
            FinsNetwork = r.FinsNetwork,
            FinsDestinationNode = r.FinsDestinationNode,
            FinsSourceNode = r.FinsSourceNode,
            TimeoutMs = r.TimeoutMs,
            PollIntervalMs = r.PollIntervalMs,
            EffectiveFromUtc = time.GetUtcNow().UtcDateTime
        };
        db.Set<PlcConnectionConfig>().Add(config);
        await db.SaveChangesAsync(ct);
        return Results.Ok(ToDto(config));
    }

    public static async Task<IResult> SetTags(int plcId, SetTagsRequest r, DbContext db, CancellationToken ct)
    {
        if (!await db.Set<PlcDevice>().AnyAsync(p => p.Id == plcId, ct)) return Results.NotFound();
        if (r.Tags is null || r.Tags.Count == 0) return Invalid("tags", "At least one tag is required.");
        if (r.Tags.Count > 500) return Invalid("tags", "At most 500 tags per PLC.");

        var errors = new List<string>();
        foreach (var t in r.Tags)
        {
            if (!string.IsNullOrEmpty(t.Key) && t.Key.Length > 100) errors.Add($"Tag '{t.Key[..20]}...': key is longer than 100 characters.");
            if ((t.Address?.Length ?? 0) > 100) errors.Add($"Tag '{t.Key}': address is longer than 100 characters.");
            if ((t.DisplayName?.Length ?? 0) > 200) errors.Add($"Tag '{t.Key}': display name is longer than 200 characters.");
            if ((t.Unit?.Length ?? 0) > 20) errors.Add($"Tag '{t.Key}': unit is longer than 20 characters.");
        }

        errors.AddRange(TagDefinitionValidator.Validate(r.Tags.Select(t => new TagDefinition
        {
            Key = t.Key ?? "",
            DataType = t.DataType,
            Scale = t.Scale,
            Offset = t.Offset,
            MinValid = t.MinValid,
            MaxValid = t.MaxValid,
            Role = t.Role,
            MotorId = t.MotorId,
            IsConfirmed = t.IsConfirmed
        })));
        if (errors.Count > 0) return Invalid(errors);

        var existing = await db.Set<Tag>().Where(t => t.PlcDeviceId == plcId).ToListAsync(ct);
        var byKey = existing.ToDictionary(t => t.Key, StringComparer.Ordinal);
        var incoming = new HashSet<string>(StringComparer.Ordinal);

        foreach (var req in r.Tags)
        {
            incoming.Add(req.Key);
            if (!byKey.TryGetValue(req.Key, out var tag))
            {
                tag = new Tag { PlcDeviceId = plcId, Key = req.Key };
                db.Set<Tag>().Add(tag);
            }

            tag.DisplayName = req.DisplayName ?? req.Key;
            tag.Address = req.Address ?? "";
            tag.DataType = req.DataType;
            tag.Scale = req.Scale;
            tag.Offset = req.Offset;
            tag.Unit = req.Unit ?? "";
            tag.MinValid = req.MinValid;
            tag.MaxValid = req.MaxValid;
            tag.PollGroup = string.IsNullOrWhiteSpace(req.PollGroup) ? "default" : req.PollGroup!;
            tag.Role = req.Role;
            tag.MotorId = req.MotorId;
            tag.IsConfirmed = req.IsConfirmed;
            tag.IsActive = true;
        }

        // Tags omitted from the request are deactivated, never deleted, so history keeps its meaning.
        foreach (var old in existing.Where(t => !incoming.Contains(t.Key))) old.IsActive = false;

        await db.SaveChangesAsync(ct);
        var saved = await db.Set<Tag>().AsNoTracking().Where(t => t.PlcDeviceId == plcId && t.IsActive).OrderBy(t => t.Key).ToListAsync(ct);
        return Results.Ok(saved.Select(ToDto).ToList());
    }

    public static async Task<IResult> ActivatePlc(int plcId, DbContext db, CancellationToken ct)
    {
        var plc = await db.Set<PlcDevice>().FirstOrDefaultAsync(p => p.Id == plcId, ct);
        if (plc is null) return Results.NotFound();

        var errors = new List<string>();
        var tags = await db.Set<Tag>().AsNoTracking().Where(t => t.PlcDeviceId == plcId && t.IsActive).ToListAsync(ct);
        if (tags.Count == 0) errors.Add("The PLC has no active tags.");
        else if (!tags.Any(t => t.IsConfirmed)) errors.Add("The PLC has no confirmed tags.");

        if (!plc.IsSimulated)
        {
            var config = await db.Set<PlcConnectionConfig>().AsNoTracking()
                .FirstOrDefaultAsync(c => c.PlcDeviceId == plcId && c.IsCurrent, ct);
            if (config is null || string.IsNullOrEmpty(config.IpAddress) || config.Port is null)
                errors.Add("A real PLC needs a connection configuration with IP address and port before activation.");
        }

        if (errors.Count > 0) return Invalid(errors);

        plc.Status = PlcDeviceStatus.Active;
        await db.SaveChangesAsync(ct);
        return Results.Ok(ToSummary(plc));
    }

    public static async Task<IResult> ListMachines(DbContext db, CancellationToken ct)
    {
        var machines = await db.Set<Machine>().AsNoTracking().OrderBy(m => m.Code).ToListAsync(ct);
        var plcs = await db.Set<PlcDevice>().AsNoTracking().OrderBy(p => p.Id).ToListAsync(ct);
        var byMachine = plcs.GroupBy(p => p.MachineId).ToDictionary(g => g.Key, g => g.Select(ToSummary).ToList());

        var result = machines.Select(m => new MachineDto(
            m.Id, m.FactoryId, m.Code, m.NameEn, m.NameAr, m.IsActive,
            byMachine.TryGetValue(m.Id, out var list) ? list : new List<PlcSummaryDto>())).ToList();
        return Results.Ok(result);
    }

    public static async Task<IResult> GetTags(int plcId, DbContext db, CancellationToken ct, bool includeInactive = false)
    {
        if (!await db.Set<PlcDevice>().AnyAsync(p => p.Id == plcId, ct)) return Results.NotFound();
        var query = db.Set<Tag>().AsNoTracking().Where(t => t.PlcDeviceId == plcId);
        if (!includeInactive) query = query.Where(t => t.IsActive);
        var tags = await query.OrderBy(t => t.Key).ToListAsync(ct);
        return Results.Ok(tags.Select(ToDto).ToList());
    }

    public static async Task<IResult> GetGatewayConfig(ClaimsPrincipal user, DbContext db, CancellationToken ct)
    {
        if (!int.TryParse(user.FindFirstValue(AuthClaims.GatewayId), out var gatewayId)) return Results.Forbid();

        var plcs = await db.Set<PlcDevice>().AsNoTracking()
            .Where(p => p.GatewayId == gatewayId && p.Status == PlcDeviceStatus.Active)
            .OrderBy(p => p.Id).ToListAsync(ct);
        var plcIds = plcs.Select(p => p.Id).ToList();

        var configs = await db.Set<PlcConnectionConfig>().AsNoTracking()
            .Where(c => plcIds.Contains(c.PlcDeviceId) && c.IsCurrent).ToListAsync(ct);
        var tags = await db.Set<Tag>().AsNoTracking()
            .Where(t => plcIds.Contains(t.PlcDeviceId) && t.IsActive).OrderBy(t => t.Key).ToListAsync(ct);

        var configByPlc = configs.ToDictionary(c => c.PlcDeviceId);
        var tagsByPlc = tags.GroupBy(t => t.PlcDeviceId).ToDictionary(g => g.Key, g => g.Select(ToDto).ToList());

        var dto = new GatewayConfigDto(gatewayId, plcs.Select(p => new GatewayPlcConfigDto(
            p.Id, p.MachineId, p.IsSimulated,
            configByPlc.TryGetValue(p.Id, out var c) ? ToDto(c) : null,
            tagsByPlc.TryGetValue(p.Id, out var tl) ? tl : new List<TagDto>())).ToList());
        return Results.Ok(dto);
    }

    private static PlcSummaryDto ToSummary(PlcDevice p) =>
        new(p.Id, p.MachineId, p.GatewayId, p.Manufacturer, p.Model, p.EthernetModuleModel, p.Status, p.IsSimulated);

    private static ConnectionConfigDto ToDto(PlcConnectionConfig c) =>
        new(c.PlcDeviceId, c.Version, c.IpAddress, c.Port, c.FinsNetwork, c.FinsDestinationNode, c.FinsSourceNode, c.TimeoutMs, c.PollIntervalMs);

    private static TagDto ToDto(Tag t) =>
        new(t.Id, t.Key, t.DisplayName, t.Address, t.DataType, t.Scale, t.Offset, t.Unit, t.MinValid, t.MaxValid,
            t.PollGroup, t.Role, t.MotorId, t.IsConfirmed, t.IsActive);
}
