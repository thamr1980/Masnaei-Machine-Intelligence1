using Masnaei.Modules.Registry.Domain;

namespace Masnaei.Modules.Registry;

public sealed class FactoryConfiguration : IEntityTypeConfiguration<Factory>
{
    public void Configure(EntityTypeBuilder<Factory> b)
    {
        b.ToTable("Factories", "registry");
        b.HasKey(x => x.Id);
        b.Property(x => x.Name).HasMaxLength(200).IsRequired();
        b.Property(x => x.TimeZoneId).HasMaxLength(100).IsRequired();
    }
}

public sealed class GatewayConfiguration : IEntityTypeConfiguration<Gateway>
{
    public void Configure(EntityTypeBuilder<Gateway> b)
    {
        b.ToTable("Gateways", "registry");
        b.HasKey(x => x.Id);
        b.Property(x => x.Name).HasMaxLength(200).IsRequired();
        b.HasOne<Factory>().WithMany().HasForeignKey(x => x.FactoryId).OnDelete(DeleteBehavior.Restrict);
        b.HasMany(x => x.Credentials).WithOne().HasForeignKey(c => c.GatewayId).OnDelete(DeleteBehavior.Cascade);
    }
}

public sealed class GatewayCredentialConfiguration : IEntityTypeConfiguration<GatewayCredential>
{
    public void Configure(EntityTypeBuilder<GatewayCredential> b)
    {
        b.ToTable("GatewayCredentials", "registry");
        b.HasKey(x => x.Id);
        b.Property(x => x.KeyPrefix).HasMaxLength(16).IsRequired();
        b.Property(x => x.KeyHash).HasMaxLength(64).IsFixedLength().IsRequired();
        b.HasIndex(x => x.KeyHash).IsUnique();
    }
}

public sealed class MachineConfiguration : IEntityTypeConfiguration<Machine>
{
    public void Configure(EntityTypeBuilder<Machine> b)
    {
        b.ToTable("Machines", "registry");
        b.HasKey(x => x.Id);
        b.Property(x => x.Code).HasMaxLength(50).IsRequired();
        b.Property(x => x.NameEn).HasMaxLength(200).IsRequired();
        b.Property(x => x.NameAr).HasMaxLength(200);
        b.HasIndex(x => new { x.FactoryId, x.Code }).IsUnique();
        b.HasOne<Factory>().WithMany().HasForeignKey(x => x.FactoryId).OnDelete(DeleteBehavior.Restrict);
    }
}

public sealed class PlcDeviceConfiguration : IEntityTypeConfiguration<PlcDevice>
{
    public void Configure(EntityTypeBuilder<PlcDevice> b)
    {
        b.ToTable("PlcDevices", "registry");
        b.HasKey(x => x.Id);
        b.Property(x => x.Manufacturer).HasMaxLength(100).IsRequired();
        b.Property(x => x.Model).HasMaxLength(100).IsRequired();
        b.Property(x => x.EthernetModuleModel).HasMaxLength(100).IsRequired();
        b.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
        b.HasIndex(x => x.MachineId);
        b.HasIndex(x => x.GatewayId);
        b.HasOne<Machine>().WithMany().HasForeignKey(x => x.MachineId).OnDelete(DeleteBehavior.Restrict);
        b.HasOne<Gateway>().WithMany().HasForeignKey(x => x.GatewayId).OnDelete(DeleteBehavior.Restrict);
    }
}

public sealed class PlcConnectionConfigConfiguration : IEntityTypeConfiguration<PlcConnectionConfig>
{
    public void Configure(EntityTypeBuilder<PlcConnectionConfig> b)
    {
        b.ToTable("PlcConnectionConfigs", "registry");
        b.HasKey(x => x.Id);
        b.Property(x => x.IpAddress).HasMaxLength(45);
        b.HasIndex(x => new { x.PlcDeviceId, x.Version }).IsUnique();
        b.HasIndex(x => new { x.PlcDeviceId, x.IsCurrent });
        b.HasOne<PlcDevice>().WithMany().HasForeignKey(x => x.PlcDeviceId).OnDelete(DeleteBehavior.Cascade);
    }
}

public sealed class TagConfiguration : IEntityTypeConfiguration<Tag>
{
    public void Configure(EntityTypeBuilder<Tag> b)
    {
        b.ToTable("Tags", "registry");
        b.HasKey(x => x.Id);
        b.Property(x => x.Key).HasMaxLength(100).IsRequired();
        b.Property(x => x.DisplayName).HasMaxLength(200).IsRequired();
        b.Property(x => x.Address).HasMaxLength(100).IsRequired();
        b.Property(x => x.Unit).HasMaxLength(20).IsRequired();
        b.Property(x => x.PollGroup).HasMaxLength(50).IsRequired();
        b.Property(x => x.MotorId).HasMaxLength(100);
        b.Property(x => x.DataType).HasConversion<string>().HasMaxLength(20);
        b.Property(x => x.Role).HasConversion<string>().HasMaxLength(30);
        b.HasIndex(x => new { x.PlcDeviceId, x.Key }).IsUnique();
        b.HasOne<PlcDevice>().WithMany().HasForeignKey(x => x.PlcDeviceId).OnDelete(DeleteBehavior.Cascade);
    }
}
