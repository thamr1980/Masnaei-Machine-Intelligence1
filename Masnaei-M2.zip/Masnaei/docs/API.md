# Masnaei API v1 (Milestone 2)

Interactive documentation: run the API in the Development environment and open `/swagger`.
All requests use the `X-Api-Key` header. All timestamps are UTC (ISO 8601 with `Z`). Enums are strings.

| Role | How it authenticates | Can do |
|---|---|---|
| gateway | API key issued by `POST /api/v1/gateways` (shown once, stored only as a SHA-256 hash) | ingest batches, read its own configuration |
| admin | development key `Security:DevAdminKey` (local testing only) | registration endpoints, and everything a reader can do |
| reader | development key `Security:DevReaderKey` (local testing only) | query endpoints |

Development keys must be at least 24 characters, are never committed, and the API refuses to start in the Production environment if any is set.
Production user authentication is designed separately (not part of this milestone).

## Endpoints
| Method and path | Role | Purpose |
|---|---|---|
| GET `/health` | none | liveness |
| POST `/api/v1/factories` | admin | create a factory |
| POST `/api/v1/gateways` | admin | create a gateway and its API key |
| POST `/api/v1/machines` | admin | register a machine |
| POST `/api/v1/machines/{id}/plcs` | admin | register a PLC (`isSimulated` marks simulator PLCs) |
| PUT `/api/v1/plcs/{id}/connection-config` | admin | new versioned connection settings (no defaults; IP unique per gateway) |
| PUT `/api/v1/plcs/{id}/tags` | admin | set the PLC's own tag mapping (omitted tags are deactivated, not deleted) |
| POST `/api/v1/plcs/{id}/activate` | admin | activate a PLC (needs confirmed tags; real PLCs also need IP and port) |
| GET `/api/v1/machines` | reader | machines with their PLCs |
| GET `/api/v1/plcs/{id}/tags` | reader | tag mapping (`includeInactive=true` for history) |
| GET `/api/v1/machines/{id}/readings?tagKey&fromUtc&toUtc&limit` | reader | historical readings, paged with `nextFromUtc`, max 31 days |
| GET `/api/v1/machines/{id}/cycles?fromUtc&toUtc&limit` | reader | production cycles |
| GET `/api/v1/machines/{id}/motor-events?fromUtc&toUtc&motorId&limit` | reader | motor events (commanded and confirmed kept separate) |
| GET `/api/v1/gateways/{id}/health/latest` | reader | latest gateway health: buffer, sync status, per-PLC connection diagnostics |
| GET `/api/v1/gateway/config` | gateway | active PLCs, connection settings and tags for this gateway |
| POST `/api/v1/ingest/batches` | gateway | idempotent upload of readings, cycles, motor events and health |

## Ingest rules
- `batchId` makes an upload idempotent: the same id again returns 200 with `duplicate: true` and stores nothing.
- Everything is validated first; a rejected batch stores nothing (400 with the reasons, or 409 for already-stored readings or cycles).
- Readings must reference an active, confirmed tag of an active PLC assigned to the calling gateway.
- `origin` must match the PLC: Simulated only from simulated PLCs, Live only from real ones.
- Timestamps must be after 2000-01-01 and at most 5 minutes in the future. Limits: 5000 readings, 500 cycles, 1000 motor events, 5 MB per request.
- A reading is unique by (PLC, tag, timestamp).

## Known limitations in this milestone
- Changing a tag's scale or type does not version historic data yet.
- Cycles are uploaded only once closed; updating an open cycle is not supported yet.
- No PLC is contacted anywhere; there are no write or command operations in the API or the adapter interface.
