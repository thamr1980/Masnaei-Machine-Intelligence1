#!/usr/bin/env bash
# Creates the solution file (once), restores, builds and runs all tests.
# Requires the .NET 8 SDK and NuGet access.
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f Masnaei.sln ]; then
  dotnet new sln -n Masnaei
  find . -name '*.csproj' -print0 | xargs -0 -n1 dotnet sln Masnaei.sln add
fi
dotnet restore
dotnet build --no-restore -c Debug
dotnet test --no-build -c Debug --logger "trx;LogFileName=test-results.trx" --logger "console;verbosity=normal"
