using Masnaei.Acquisition.Contracts;

namespace Masnaei.Acquisition.Simulation;

/// <summary>A simulated PLC: its behavior, its tag mapping and how tags bind to simulated signals.</summary>
public sealed record SimulatedPlcProfile(
    string Name,
    ScenarioDefinition Scenario,
    IReadOnlyList<TagDefinition> Tags,
    IReadOnlyDictionary<string, SignalBinding> SignalMap)
{
    public SimulatedPlcOptions ToOptions(DateTimeOffset startUtc) => new(Scenario, SignalMap, startUtc);
}

/// <summary>
/// Two deliberately different simulated PLCs. They share no tag keys, use different data types, scaling
/// and offsets, and expose different signal sets. No real PLC addresses or IPs are involved.
/// </summary>
public static class SimulatedPlcProfiles
{
    /// <summary>Machine A: full signal set including explicit cycle start/end bits and cycle duration; two motors.</summary>
    public static SimulatedPlcProfile MachineA()
    {
        var scenario = new ScenarioDefinition
        {
            Name = "machine-a-baseline",
            Seed = 1001,
            FirstCycleStartSeconds = 5,
            NominalCycleSeconds = 120,
            GapSeconds = 10,
            StopWindows = new[] { new TimeWindow(1000, 1300) },
            CommunicationFailureWindows = new[] { new TimeWindow(500, 520) },
            AbnormalCycleFactors = new Dictionary<int, double> { [3] = 1.5 },
            Motors = new[]
            {
                new MotorSimulation("Hydraulic pump", MotorBehavior.WhileMachineRunning, 1.5),
                new MotorSimulation("Cooling pump", MotorBehavior.DuringCycle, 2.0,
                    new[] { new TimeWindow(2000, 2030) })
            }
        };

        TagDefinition Analog(string key, string name, TagDataType type, double scale, string unit, double min, double max, string group = "fast") =>
            new()
            {
                Key = key, DisplayName = name, DataType = type, Scale = scale, Unit = unit,
                MinValid = min, MaxValid = max, PollGroup = group, IsConfirmed = true
            };

        TagDefinition Bit(string key, string name, TagRole role, string? motorId = null) =>
            new()
            {
                Key = key, DisplayName = name, DataType = TagDataType.Bool, Role = role,
                MotorId = motorId, IsConfirmed = true, PollGroup = "fast"
            };

        var tags = new List<TagDefinition>
        {
            Analog("steam.fixed.pressure", "Fixed mold steam pressure", TagDataType.Int16, 0.01, "bar", 0, 5),
            Analog("steam.moving.pressure", "Moving mold steam pressure", TagDataType.Int16, 0.01, "bar", 0, 5),
            Analog("temp.fixed", "Fixed mold temperature", TagDataType.Int16, 0.1, "C", -20, 200),
            Analog("temp.moving", "Moving mold temperature", TagDataType.Int16, 0.1, "C", -20, 200),
            Analog("hyd.pressure", "Hydraulic pressure", TagDataType.UInt16, 0.1, "bar", 0, 300),
            Analog("water.inlet.temp", "Inlet water temperature", TagDataType.Int16, 0.1, "C", 0, 80, "slow"),
            Bit("machine.running", "Machine running", TagRole.MachineRunning),
            new TagDefinition
            {
                Key = "cycle.counter", DisplayName = "Cycle counter", DataType = TagDataType.UInt16,
                Role = TagRole.CycleCounter, PollGroup = "slow", IsConfirmed = true
            },
            new TagDefinition
            {
                Key = "cycle.duration", DisplayName = "Last cycle duration", DataType = TagDataType.UInt16,
                Scale = 0.1, Unit = "s", Role = TagRole.CycleDuration, PollGroup = "slow", IsConfirmed = true
            },
            Bit("cycle.start", "Cycle start", TagRole.CycleStart),
            Bit("cycle.end", "Cycle end", TagRole.CycleEnd),
            Bit("motor.hyd.cmd", "Hydraulic pump command", TagRole.MotorCommand, "hyd-pump"),
            Bit("motor.hyd.fb", "Hydraulic pump feedback", TagRole.MotorFeedback, "hyd-pump"),
            Bit("motor.cool.cmd", "Cooling pump command", TagRole.MotorCommand, "cool-pump"),
            Bit("motor.cool.fb", "Cooling pump feedback", TagRole.MotorFeedback, "cool-pump")
        };

        var map = new Dictionary<string, SignalBinding>
        {
            ["steam.fixed.pressure"] = new(SimulatedSignalKind.FixedSteamPressure),
            ["steam.moving.pressure"] = new(SimulatedSignalKind.MovingSteamPressure),
            ["temp.fixed"] = new(SimulatedSignalKind.FixedMoldTemperature),
            ["temp.moving"] = new(SimulatedSignalKind.MovingMoldTemperature),
            ["hyd.pressure"] = new(SimulatedSignalKind.HydraulicPressure),
            ["water.inlet.temp"] = new(SimulatedSignalKind.WaterInletTemperature),
            ["machine.running"] = new(SimulatedSignalKind.MachineRunning),
            ["cycle.counter"] = new(SimulatedSignalKind.CycleCounter),
            ["cycle.duration"] = new(SimulatedSignalKind.CycleDuration),
            ["cycle.start"] = new(SimulatedSignalKind.CycleStartPulse),
            ["cycle.end"] = new(SimulatedSignalKind.CycleEndPulse),
            ["motor.hyd.cmd"] = new(SimulatedSignalKind.MotorCommand, 0),
            ["motor.hyd.fb"] = new(SimulatedSignalKind.MotorFeedback, 0),
            ["motor.cool.cmd"] = new(SimulatedSignalKind.MotorCommand, 1),
            ["motor.cool.fb"] = new(SimulatedSignalKind.MotorFeedback, 1)
        };

        return new SimulatedPlcProfile("Machine A", scenario, tags, map);
    }

    /// <summary>
    /// Machine B: different keys, scaling and offsets, 32-bit counter, one motor, and NO cycle start/end/duration
    /// tags, so only counter-based or running-bit-based cycle detection is possible.
    /// </summary>
    public static SimulatedPlcProfile MachineB()
    {
        var scenario = new ScenarioDefinition
        {
            Name = "machine-b-baseline",
            Seed = 2002,
            FirstCycleStartSeconds = 12,
            NominalCycleSeconds = 90,
            GapSeconds = 15,
            InitialCounter = 1000,
            StopWindows = new[] { new TimeWindow(600, 700) },
            CommunicationFailureWindows = new[] { new TimeWindow(200, 230) },
            Motors = new[] { new MotorSimulation("Main pump", MotorBehavior.WhileMachineRunning, 1.0) }
        };

        TagDefinition Analog(string key, TagDataType type, double scale, double offset, string unit, double min, double max) =>
            new()
            {
                Key = key, DataType = type, Scale = scale, Offset = offset, Unit = unit,
                MinValid = min, MaxValid = max, IsConfirmed = true, PollGroup = "default"
            };

        var tags = new List<TagDefinition>
        {
            Analog("SteamP_Fix", TagDataType.UInt16, 0.001, 0, "bar", 0, 5),
            Analog("SteamP_Mov", TagDataType.UInt16, 0.001, 0, "bar", 0, 5),
            Analog("T_Fix", TagDataType.Int16, 0.01, 0, "C", -20, 200),
            Analog("T_Mov", TagDataType.Int16, 0.01, 0, "C", -20, 200),
            Analog("HydP", TagDataType.Int16, 0.01, 0, "bar", 0, 300),
            Analog("WaterT", TagDataType.UInt16, 0.05, -10, "C", 0, 80),
            new TagDefinition { Key = "Run", DataType = TagDataType.Bool, Role = TagRole.MachineRunning, IsConfirmed = true },
            new TagDefinition { Key = "CycCnt", DataType = TagDataType.UInt32, Role = TagRole.CycleCounter, IsConfirmed = true },
            new TagDefinition { Key = "M_Main_Cmd", DataType = TagDataType.Bool, Role = TagRole.MotorCommand, MotorId = "main-pump", IsConfirmed = true },
            new TagDefinition { Key = "M_Main_Fb", DataType = TagDataType.Bool, Role = TagRole.MotorFeedback, MotorId = "main-pump", IsConfirmed = true }
        };

        var map = new Dictionary<string, SignalBinding>
        {
            ["SteamP_Fix"] = new(SimulatedSignalKind.FixedSteamPressure),
            ["SteamP_Mov"] = new(SimulatedSignalKind.MovingSteamPressure),
            ["T_Fix"] = new(SimulatedSignalKind.FixedMoldTemperature),
            ["T_Mov"] = new(SimulatedSignalKind.MovingMoldTemperature),
            ["HydP"] = new(SimulatedSignalKind.HydraulicPressure),
            ["WaterT"] = new(SimulatedSignalKind.WaterInletTemperature),
            ["Run"] = new(SimulatedSignalKind.MachineRunning),
            ["CycCnt"] = new(SimulatedSignalKind.CycleCounter),
            ["M_Main_Cmd"] = new(SimulatedSignalKind.MotorCommand, 0),
            ["M_Main_Fb"] = new(SimulatedSignalKind.MotorFeedback, 0)
        };

        return new SimulatedPlcProfile("Machine B", scenario, tags, map);
    }
}
