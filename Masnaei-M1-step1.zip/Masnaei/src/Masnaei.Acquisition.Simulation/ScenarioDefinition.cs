namespace Masnaei.Acquisition.Simulation;

/// <summary>Half-open time window [StartSeconds, EndSeconds) measured from simulation start.</summary>
public readonly record struct TimeWindow(double StartSeconds, double EndSeconds)
{
    public bool Contains(double t) => t >= StartSeconds && t < EndSeconds;
}

public enum MotorBehavior
{
    /// <summary>Commanded whenever the machine is running.</summary>
    WhileMachineRunning,

    /// <summary>Commanded only while a production cycle is active.</summary>
    DuringCycle
}

/// <summary>A simulated motor. Feedback follows the command after a delay unless inside a fault window.</summary>
public sealed record MotorSimulation(
    string Name,
    MotorBehavior Behavior,
    double FeedbackDelaySeconds,
    IReadOnlyList<TimeWindow>? FeedbackFaultWindows = null);

/// <summary>
/// Deterministic description of what a simulated machine does over time.
/// The same definition always produces the same behavior. The signal shapes are synthetic test data,
/// not a claim about real EPS process stages.
/// </summary>
public sealed record ScenarioDefinition
{
    public string Name { get; init; } = "scenario";
    public int Seed { get; init; } = 1;
    public double FirstCycleStartSeconds { get; init; } = 5;
    public double NominalCycleSeconds { get; init; } = 120;
    public double GapSeconds { get; init; } = 10;
    public double PulseSeconds { get; init; } = 2;

    /// <summary>Noise amplitude as a fraction of each signal's nominal span. Zero gives exact curves.</summary>
    public double NoiseFraction { get; init; } = 0.005;

    public double HorizonSeconds { get; init; } = 86_400;
    public long InitialCounter { get; init; } = 0;

    /// <summary>Machine stopped: no new cycle starts, running bit false. A cycle in progress is aborted.</summary>
    public IReadOnlyList<TimeWindow> StopWindows { get; init; } = Array.Empty<TimeWindow>();

    /// <summary>Reads fail with a communication error inside these windows.</summary>
    public IReadOnlyList<TimeWindow> CommunicationFailureWindows { get; init; } = Array.Empty<TimeWindow>();

    /// <summary>Cycle attempt index (0-based) to duration multiplier, for abnormal cycles.</summary>
    public IReadOnlyDictionary<int, double> AbnormalCycleFactors { get; init; } = new Dictionary<int, double>();

    public IReadOnlyList<MotorSimulation> Motors { get; init; } = Array.Empty<MotorSimulation>();
}
