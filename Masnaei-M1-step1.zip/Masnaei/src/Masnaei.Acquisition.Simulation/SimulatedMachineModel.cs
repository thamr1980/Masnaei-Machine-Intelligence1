namespace Masnaei.Acquisition.Simulation;

/// <summary>
/// Pure function of simulated time: given the same scenario and the same time it always returns
/// the same value, regardless of how often or in what order it is polled.
/// </summary>
public sealed class SimulatedMachineModel
{
    private static readonly (double X, double Y)[] SteamProfile =
    {
        (0.00, 0.0), (0.10, 0.0), (0.25, 1.2), (0.45, 1.2), (0.55, 0.1), (1.00, 0.0)
    };

    private static readonly (double X, double Y)[] HeatProfile =
    {
        (0.00, 0.0), (0.15, 0.0), (0.35, 1.0), (0.55, 1.0), (1.00, 0.2)
    };

    private const double AmbientTemperature = 30.0;
    private const double FixedTemperatureSpan = 72.0;
    private const double MovingTemperatureSpan = 70.0;
    private const double ResidualDecaySeconds = 180.0;

    private readonly ScenarioDefinition _scenario;
    private readonly TimeWindow[] _stops;
    private readonly PlannedCycle[] _cycles;

    public SimulatedMachineModel(ScenarioDefinition scenario)
    {
        _scenario = scenario ?? throw new ArgumentNullException(nameof(scenario));
        ValidateScalars(scenario);
        _stops = scenario.StopWindows.OrderBy(w => w.StartSeconds).ToArray();
        ValidateStops(_stops);
        _cycles = BuildSchedule();
    }

    public ScenarioDefinition Scenario => _scenario;

    /// <summary>Ground truth cycle timeline, used by tests to verify cycle detection later.</summary>
    public IReadOnlyList<PlannedCycle> Cycles => _cycles;

    // ---- discrete state -------------------------------------------------

    public bool IsCommunicationFailed(double t) => InAny(_scenario.CommunicationFailureWindows, t);

    public bool IsRunning(double t) => t >= _scenario.FirstCycleStartSeconds && !InAny(_stops, t);

    public bool IsCycleActive(double t) => TryGetActiveCycle(t, out _);

    /// <summary>Completed cycles (aborted ones do not count) plus the configured initial counter, not yet wrapped.</summary>
    public long CounterTotal(double t)
    {
        long completed = 0;
        foreach (var c in _cycles)
            if (c.Completed && c.EndSeconds <= t)
                completed++;
        return _scenario.InitialCounter + completed;
    }

    /// <summary>Duration in seconds of the last completed cycle, or 0 if none has completed.</summary>
    public double LastCompletedCycleDuration(double t)
    {
        double result = 0;
        foreach (var c in _cycles)
            if (c.Completed && c.EndSeconds <= t)
                result = c.ActualDurationSeconds;
        return result;
    }

    public bool StartPulse(double t)
    {
        foreach (var c in _cycles)
            if (t >= c.StartSeconds && t < c.StartSeconds + _scenario.PulseSeconds)
                return true;
        return false;
    }

    public bool EndPulse(double t)
    {
        foreach (var c in _cycles)
            if (c.Completed && t >= c.EndSeconds && t < c.EndSeconds + _scenario.PulseSeconds)
                return true;
        return false;
    }

    public bool MotorCommand(int motorIndex, double t)
    {
        var motor = GetMotor(motorIndex);
        return motor.Behavior switch
        {
            MotorBehavior.WhileMachineRunning => IsRunning(t),
            MotorBehavior.DuringCycle => IsCycleActive(t),
            _ => false
        };
    }

    public bool MotorFeedback(int motorIndex, double t)
    {
        var motor = GetMotor(motorIndex);
        if (!MotorCommand(motorIndex, t)) return false;
        if (motor.FeedbackFaultWindows is not null && InAny(motor.FeedbackFaultWindows, t)) return false;
        var earlier = t - motor.FeedbackDelaySeconds;
        return earlier >= 0 && MotorCommand(motorIndex, earlier);
    }

    // ---- analog signals (engineering units) -----------------------------

    public double Analog(SimulatedSignalKind kind, double t)
    {
        var active = TryGetActiveCycle(t, out var cycle);
        var u = active ? (t - cycle!.StartSeconds) / cycle.PlannedDurationSeconds : 0.0;

        double value;
        switch (kind)
        {
            case SimulatedSignalKind.FixedSteamPressure:
                value = active ? Interp(SteamProfile, u) : 0.0;
                break;
            case SimulatedSignalKind.MovingSteamPressure:
                value = active ? 0.95 * Interp(SteamProfile, Math.Clamp(u - 0.02, 0, 1)) : 0.0;
                break;
            case SimulatedSignalKind.FixedMoldTemperature:
                value = AmbientTemperature + FixedTemperatureSpan * (active ? Interp(HeatProfile, u) : ResidualFraction(t, 1.0));
                break;
            case SimulatedSignalKind.MovingMoldTemperature:
                value = AmbientTemperature + MovingTemperatureSpan * (active ? Interp(HeatProfile, Math.Clamp(u - 0.03, 0, 1)) : ResidualFraction(t, 1.0));
                break;
            case SimulatedSignalKind.HydraulicPressure:
                if (!IsRunning(t)) { value = 0.0; break; }
                value = 150.0 + (active && (u < 0.08 || u > 0.92) ? 40.0 : 0.0);
                break;
            case SimulatedSignalKind.WaterInletTemperature:
                value = 24.0 + 2.0 * Math.Sin(2.0 * Math.PI * t / 3600.0);
                break;
            default:
                throw new ArgumentException($"{kind} is not an analog signal.", nameof(kind));
        }

        // No noise on an idle (zero) pressure so it never reads negative.
        var isPressure = kind is SimulatedSignalKind.FixedSteamPressure or SimulatedSignalKind.MovingSteamPressure;
        if (isPressure && value <= 0.0) return 0.0;

        value += Noise(kind, t) * _scenario.NoiseFraction * NominalSpan(kind);
        return value;
    }

    // ---- internals ------------------------------------------------------

    private static double NominalSpan(SimulatedSignalKind kind) => kind switch
    {
        SimulatedSignalKind.FixedSteamPressure => 1.2,
        SimulatedSignalKind.MovingSteamPressure => 1.2,
        SimulatedSignalKind.FixedMoldTemperature => 70.0,
        SimulatedSignalKind.MovingMoldTemperature => 70.0,
        SimulatedSignalKind.HydraulicPressure => 150.0,
        SimulatedSignalKind.WaterInletTemperature => 24.0,
        _ => 1.0
    };

    /// <summary>Residual heat after the most recent cycle ended, as a fraction of the end-of-cycle excess.</summary>
    private double ResidualFraction(double t, double amplitudeScale)
    {
        PlannedCycle? last = null;
        foreach (var c in _cycles)
            if (c.EndSeconds <= t)
                last = c;
        if (last is null) return 0.0;

        // Heat profile ends at 0.2 of span; decay from there.
        var endFraction = 0.2 * amplitudeScale;
        return endFraction * Math.Exp(-(t - last.EndSeconds) / ResidualDecaySeconds);
    }

    private bool TryGetActiveCycle(double t, out PlannedCycle? cycle)
    {
        foreach (var c in _cycles)
        {
            if (t >= c.StartSeconds && t < c.EndSeconds)
            {
                cycle = c;
                return true;
            }
        }
        cycle = null;
        return false;
    }

    private MotorSimulation GetMotor(int index)
    {
        if (index < 0 || index >= _scenario.Motors.Count)
            throw new ArgumentOutOfRangeException(nameof(index), $"No simulated motor with index {index}.");
        return _scenario.Motors[index];
    }

    private PlannedCycle[] BuildSchedule()
    {
        var cycles = new List<PlannedCycle>();
        var t = _scenario.FirstCycleStartSeconds;
        var attempt = 0;

        while (t < _scenario.HorizonSeconds)
        {
            if (TryFindWindow(_stops, t, out var stopAtStart))
            {
                t = stopAtStart.EndSeconds;
                continue;
            }

            var factor = _scenario.AbnormalCycleFactors.TryGetValue(attempt, out var f) ? f : 1.0;
            var planned = _scenario.NominalCycleSeconds * factor;
            var plannedEnd = t + planned;

            TimeWindow? interrupting = null;
            foreach (var stop in _stops)
            {
                if (stop.StartSeconds > t && stop.StartSeconds < plannedEnd)
                {
                    interrupting = stop;
                    break;
                }
            }

            if (interrupting is { } stopWindow)
            {
                cycles.Add(new PlannedCycle(attempt, t, stopWindow.StartSeconds, false, planned));
                t = stopWindow.EndSeconds;
            }
            else
            {
                cycles.Add(new PlannedCycle(attempt, t, plannedEnd, true, planned));
                t = plannedEnd + _scenario.GapSeconds;
            }

            attempt++;
        }

        return cycles.ToArray();
    }

    private static void ValidateScalars(ScenarioDefinition s)
    {
        if (s.NominalCycleSeconds <= 0) throw new ArgumentException("NominalCycleSeconds must be positive.");
        if (s.GapSeconds < 0) throw new ArgumentException("GapSeconds must not be negative.");
        if (s.PulseSeconds <= 0) throw new ArgumentException("PulseSeconds must be positive.");
        if (s.NoiseFraction < 0) throw new ArgumentException("NoiseFraction must not be negative.");
        if (s.HorizonSeconds <= 0) throw new ArgumentException("HorizonSeconds must be positive.");
        if (s.InitialCounter < 0) throw new ArgumentException("InitialCounter must not be negative.");
        foreach (var kv in s.AbnormalCycleFactors)
            if (kv.Value <= 0) throw new ArgumentException($"Abnormal factor for cycle {kv.Key} must be positive.");
        foreach (var w in s.CommunicationFailureWindows)
            if (w.EndSeconds <= w.StartSeconds) throw new ArgumentException("Communication failure window must have End > Start.");
    }

    private static void ValidateStops(TimeWindow[] sortedStops)
    {
        for (var i = 0; i < sortedStops.Length; i++)
        {
            if (sortedStops[i].EndSeconds <= sortedStops[i].StartSeconds)
                throw new ArgumentException("Stop window must have End > Start.");
            if (i > 0 && sortedStops[i].StartSeconds < sortedStops[i - 1].EndSeconds)
                throw new ArgumentException("Stop windows must not overlap.");
        }
    }

    private static bool InAny(IReadOnlyList<TimeWindow> windows, double t)
    {
        for (var i = 0; i < windows.Count; i++)
            if (windows[i].Contains(t)) return true;
        return false;
    }

    private static bool InAny(TimeWindow[] windows, double t)
    {
        for (var i = 0; i < windows.Length; i++)
            if (windows[i].Contains(t)) return true;
        return false;
    }

    private static bool TryFindWindow(TimeWindow[] windows, double t, out TimeWindow found)
    {
        foreach (var w in windows)
        {
            if (w.Contains(t))
            {
                found = w;
                return true;
            }
        }
        found = default;
        return false;
    }

    private static double Interp((double X, double Y)[] points, double u)
    {
        if (u <= points[0].X) return points[0].Y;
        for (var i = 1; i < points.Length; i++)
        {
            if (u <= points[i].X)
            {
                var a = points[i - 1];
                var b = points[i];
                var f = (u - a.X) / (b.X - a.X);
                return a.Y + f * (b.Y - a.Y);
            }
        }
        return points[^1].Y;
    }

    // Deterministic noise in [-1, 1]: SplitMix64 over (seed, signal, 100 ms tick).
    private double Noise(SimulatedSignalKind kind, double t)
    {
        var tick = (long)Math.Floor(t * 10.0);
        ulong h;
        unchecked
        {
            h = Mix((ulong)(long)_scenario.Seed ^ Mix((ulong)(int)kind) ^ Mix((ulong)tick + 0x1234567UL));
            h = Mix(h);
        }
        var unit = (h >> 11) * (1.0 / 9007199254740992.0);
        return unit * 2.0 - 1.0;
    }

    private static ulong Mix(ulong x)
    {
        unchecked
        {
            x += 0x9E3779B97F4A7C15UL;
            x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9UL;
            x = (x ^ (x >> 27)) * 0x94D049BB133111EBUL;
            return x ^ (x >> 31);
        }
    }
}
