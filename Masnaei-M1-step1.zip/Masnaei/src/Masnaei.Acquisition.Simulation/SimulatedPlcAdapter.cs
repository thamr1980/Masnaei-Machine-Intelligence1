using Masnaei.Acquisition.Contracts;

namespace Masnaei.Acquisition.Simulation;

public sealed record SimulatedPlcOptions(
    ScenarioDefinition Scenario,
    IReadOnlyDictionary<string, SignalBinding> SignalMap,
    DateTimeOffset StartUtc);

/// <summary>
/// Simulated PLC behind the same <see cref="IPlcAdapter"/> interface as the real adapter.
/// Time comes from an injected <see cref="TimeProvider"/> so tests are fully deterministic.
/// Every sample is marked <see cref="DataOrigin.Simulated"/>.
/// </summary>
public sealed class SimulatedPlcAdapter : IPlcAdapter
{
    private static readonly TimeSpan SimulatedRoundTrip = TimeSpan.FromMilliseconds(5);

    private readonly SimulatedPlcOptions _options;
    private readonly TimeProvider _time;
    private readonly SimulatedMachineModel _model;

    public SimulatedPlcAdapter(SimulatedPlcOptions options, TimeProvider timeProvider)
    {
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _time = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        _model = new SimulatedMachineModel(options.Scenario);
    }

    public PlcConnectionState State { get; private set; } = PlcConnectionState.Disconnected;

    /// <summary>Ground truth for tests.</summary>
    public SimulatedMachineModel Model => _model;

    public async Task ConnectAsync(CancellationToken cancellationToken)
    {
        await Task.CompletedTask;
        cancellationToken.ThrowIfCancellationRequested();

        State = PlcConnectionState.Connecting;
        if (_model.IsCommunicationFailed(ElapsedSeconds()))
        {
            State = PlcConnectionState.Faulted;
            throw new PlcCommunicationException("Simulated PLC is unreachable.");
        }

        State = PlcConnectionState.Connected;
    }

    public async Task DisconnectAsync(CancellationToken cancellationToken)
    {
        await Task.CompletedTask;
        State = PlcConnectionState.Disconnected;
    }

    public async Task<PlcReadResult> ReadAsync(IReadOnlyList<TagDefinition> tags, CancellationToken cancellationToken)
    {
        await Task.CompletedTask;
        cancellationToken.ThrowIfCancellationRequested();
        ArgumentNullException.ThrowIfNull(tags);

        if (State != PlcConnectionState.Connected)
            throw new PlcCommunicationException("Simulated PLC is not connected.");

        var t = ElapsedSeconds();
        if (_model.IsCommunicationFailed(t))
        {
            State = PlcConnectionState.Faulted;
            throw new PlcCommunicationException("Simulated communication failure.");
        }

        var timestamp = _time.GetUtcNow();
        var samples = new List<RawSample>(tags.Count);

        foreach (var tag in tags)
        {
            if (!_options.SignalMap.TryGetValue(tag.Key, out var binding))
            {
                samples.Add(new RawSample(tag.Key, null, SampleQuality.BadConfiguration, timestamp, DataOrigin.Simulated));
                continue;
            }

            var engineering = EngineeringValue(tag, binding, t);
            var raw = TagScaler.ToRaw(tag, engineering);
            samples.Add(new RawSample(tag.Key, raw, SampleQuality.Good, timestamp, DataOrigin.Simulated));
        }

        return new PlcReadResult(samples, SimulatedRoundTrip);
    }

    public ValueTask DisposeAsync()
    {
        State = PlcConnectionState.Disconnected;
        return ValueTask.CompletedTask;
    }

    private double ElapsedSeconds() => Math.Max(0.0, (_time.GetUtcNow() - _options.StartUtc).TotalSeconds);

    private double EngineeringValue(TagDefinition tag, SignalBinding binding, double t)
    {
        switch (binding.Kind)
        {
            case SimulatedSignalKind.MachineRunning:
                return _model.IsRunning(t) ? 1 : 0;
            case SimulatedSignalKind.CycleStartPulse:
                return _model.StartPulse(t) ? 1 : 0;
            case SimulatedSignalKind.CycleEndPulse:
                return _model.EndPulse(t) ? 1 : 0;
            case SimulatedSignalKind.MotorCommand:
                return _model.MotorCommand(binding.MotorIndex, t) ? 1 : 0;
            case SimulatedSignalKind.MotorFeedback:
                return _model.MotorFeedback(binding.MotorIndex, t) ? 1 : 0;
            case SimulatedSignalKind.CycleCounter:
                // Wraps at the register size of the mapped tag, so rollover behavior is testable.
                return _model.CounterTotal(t) % TagScaler.CounterModulus(tag.DataType);
            case SimulatedSignalKind.CycleDuration:
                return _model.LastCompletedCycleDuration(t);
            default:
                return _model.Analog(binding.Kind, t);
        }
    }
}
