namespace Masnaei.Acquisition.Simulation;

public enum SimulatedSignalKind
{
    FixedSteamPressure,
    MovingSteamPressure,
    FixedMoldTemperature,
    MovingMoldTemperature,
    HydraulicPressure,
    WaterInletTemperature,
    MachineRunning,
    CycleCounter,
    CycleDuration,
    CycleStartPulse,
    CycleEndPulse,
    MotorCommand,
    MotorFeedback
}

/// <summary>
/// Binds a tag key to a simulated signal. This is how two simulated PLCs expose the same
/// physical behavior under different tag keys, data types and scaling.
/// </summary>
public readonly record struct SignalBinding(SimulatedSignalKind Kind, int MotorIndex = 0);

public sealed record PlannedCycle(
    int AttemptIndex,
    double StartSeconds,
    double EndSeconds,
    bool Completed,
    double PlannedDurationSeconds)
{
    public double ActualDurationSeconds => EndSeconds - StartSeconds;
}
