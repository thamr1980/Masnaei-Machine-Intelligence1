namespace Masnaei.Acquisition.Contracts;

/// <summary>Value as read from the PLC, before scaling.</summary>
public readonly record struct RawSample(
    string TagKey,
    double? RawValue,
    SampleQuality Quality,
    DateTimeOffset TimestampUtc,
    DataOrigin Origin);

/// <summary>Scaled engineering value with quality and origin.</summary>
public readonly record struct Sample(
    string TagKey,
    double? Value,
    SampleQuality Quality,
    DateTimeOffset TimestampUtc,
    DataOrigin Origin);
