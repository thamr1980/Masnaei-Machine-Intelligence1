namespace Masnaei.Acquisition.Contracts;

/// <summary>Converts between raw register values and engineering values and applies quality rules.</summary>
public static class TagScaler
{
    public static Sample ToSample(TagDefinition tag, RawSample raw)
    {
        ArgumentNullException.ThrowIfNull(tag);

        if (!tag.IsConfirmed)
            return new Sample(tag.Key, null, SampleQuality.BadConfiguration, raw.TimestampUtc, raw.Origin);

        if (raw.Quality != SampleQuality.Good)
            return new Sample(tag.Key, null, raw.Quality, raw.TimestampUtc, raw.Origin);

        if (raw.RawValue is not double rawValue || double.IsNaN(rawValue) || double.IsInfinity(rawValue))
            return new Sample(tag.Key, null, SampleQuality.BadCommunication, raw.TimestampUtc, raw.Origin);

        var engineering = rawValue * tag.Scale + tag.Offset;

        var outOfRange =
            (tag.MinValid.HasValue && engineering < tag.MinValid.Value) ||
            (tag.MaxValid.HasValue && engineering > tag.MaxValid.Value);

        // The value is kept for display, but quality tells consumers not to use it in statistics.
        return new Sample(
            tag.Key,
            engineering,
            outOfRange ? SampleQuality.BadOutOfRange : SampleQuality.Good,
            raw.TimestampUtc,
            raw.Origin);
    }

    /// <summary>Inverse of scaling, rounded and clamped to the register type. Used by the simulator.</summary>
    public static double ToRaw(TagDefinition tag, double engineeringValue)
    {
        ArgumentNullException.ThrowIfNull(tag);

        if (tag.DataType == TagDataType.Bool)
            return engineeringValue != 0 ? 1 : 0;

        if (tag.Scale == 0)
            throw new ArgumentException($"Tag '{tag.Key}' has zero scale.", nameof(tag));

        var raw = Math.Round((engineeringValue - tag.Offset) / tag.Scale, MidpointRounding.AwayFromZero);
        var (min, max) = Range(tag.DataType);
        return Math.Clamp(raw, min, max);
    }

    public static (double Min, double Max) Range(TagDataType type) => type switch
    {
        TagDataType.Bool => (0, 1),
        TagDataType.Int16 => (short.MinValue, short.MaxValue),
        TagDataType.UInt16 => (0, ushort.MaxValue),
        TagDataType.Int32 => (int.MinValue, int.MaxValue),
        TagDataType.UInt32 => (0, uint.MaxValue),
        _ => throw new ArgumentOutOfRangeException(nameof(type))
    };

    /// <summary>Counter wrap-around modulus for unsigned counter types (65536 or 4294967296).</summary>
    public static long CounterModulus(TagDataType type) => type switch
    {
        TagDataType.UInt16 => 65_536L,
        TagDataType.UInt32 => 4_294_967_296L,
        _ => throw new ArgumentException("Counters must be UInt16 or UInt32.", nameof(type))
    };
}
