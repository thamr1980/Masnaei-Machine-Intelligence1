namespace Masnaei.Acquisition.Contracts;

/// <summary>Raw register interpretation of a tag.</summary>
public enum TagDataType
{
    Bool,
    Int16,
    UInt16,
    Int32,
    UInt32
}

/// <summary>
/// Semantic role a tag plays for downstream detectors (cycle and motor detection).
/// Roles are configuration, never inferred from tag names.
/// </summary>
public enum TagRole
{
    None,
    MachineRunning,
    CycleCounter,
    CycleStart,
    CycleEnd,
    CycleDuration,
    MotorCommand,
    MotorFeedback
}

public enum SampleQuality
{
    Good,
    BadCommunication,
    BadOutOfRange,
    BadConfiguration
}

/// <summary>Where a value came from. Simulated data must never be presented as live data.</summary>
public enum DataOrigin
{
    Live,
    Simulated
}

public enum PlcConnectionState
{
    Disconnected,
    Connecting,
    Connected,
    Faulted
}
