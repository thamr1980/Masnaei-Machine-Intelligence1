namespace Masnaei.Acquisition.Contracts;

/// <summary>Validates a tag mapping before it is accepted for a PLC.</summary>
public static class TagDefinitionValidator
{
    public static IReadOnlyList<string> Validate(IEnumerable<TagDefinition> tags)
    {
        ArgumentNullException.ThrowIfNull(tags);

        var errors = new List<string>();
        var seen = new HashSet<string>(StringComparer.Ordinal);

        foreach (var tag in tags)
        {
            if (string.IsNullOrWhiteSpace(tag.Key))
            {
                errors.Add("Tag key must not be empty.");
                continue;
            }

            if (!seen.Add(tag.Key))
                errors.Add($"Duplicate tag key '{tag.Key}'.");

            if (tag.Scale == 0 || double.IsNaN(tag.Scale) || double.IsInfinity(tag.Scale))
                errors.Add($"Tag '{tag.Key}': scale must be a finite, non-zero number.");

            if (tag.MinValid.HasValue && tag.MaxValid.HasValue && tag.MinValid.Value > tag.MaxValid.Value)
                errors.Add($"Tag '{tag.Key}': MinValid is greater than MaxValid.");

            var isMotorRole = tag.Role == TagRole.MotorCommand || tag.Role == TagRole.MotorFeedback;
            if (isMotorRole && string.IsNullOrWhiteSpace(tag.MotorId))
                errors.Add($"Tag '{tag.Key}': motor tags require a MotorId.");

            var mustBeBool =
                tag.Role == TagRole.MachineRunning ||
                tag.Role == TagRole.CycleStart ||
                tag.Role == TagRole.CycleEnd ||
                isMotorRole;
            if (mustBeBool && tag.DataType != TagDataType.Bool)
                errors.Add($"Tag '{tag.Key}': role {tag.Role} requires data type Bool.");

            if (tag.Role == TagRole.CycleCounter &&
                tag.DataType != TagDataType.UInt16 && tag.DataType != TagDataType.UInt32)
                errors.Add($"Tag '{tag.Key}': cycle counter must be UInt16 or UInt32.");
        }

        return errors;
    }
}
