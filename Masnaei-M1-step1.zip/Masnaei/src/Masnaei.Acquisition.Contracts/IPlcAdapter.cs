namespace Masnaei.Acquisition.Contracts;

/// <summary>
/// The only way the rest of the system talks to a PLC. By design this interface has no
/// write, set or command methods: V1 is read-only. Real and simulated adapters implement it identically.
/// </summary>
public interface IPlcAdapter : IAsyncDisposable
{
    PlcConnectionState State { get; }

    /// <summary>Throws <see cref="PlcCommunicationException"/> if the PLC cannot be reached.</summary>
    Task ConnectAsync(CancellationToken cancellationToken);

    Task DisconnectAsync(CancellationToken cancellationToken);

    /// <summary>Reads the given tags. Throws <see cref="PlcCommunicationException"/> on communication failure.</summary>
    Task<PlcReadResult> ReadAsync(IReadOnlyList<TagDefinition> tags, CancellationToken cancellationToken);
}

public sealed record PlcReadResult(IReadOnlyList<RawSample> Samples, TimeSpan RoundTripTime);

public class PlcCommunicationException : Exception
{
    public PlcCommunicationException(string message) : base(message) { }
    public PlcCommunicationException(string message, Exception inner) : base(message, inner) { }
}
