namespace Masnaei.Acquisition.Contracts;

/// <summary>
/// One configurable PLC signal. Every PLC has its own tag set; nothing here assumes
/// a particular memory map. <see cref="Address"/> is opaque to the simulator and is
/// interpreted only by a real adapter.
/// </summary>
public sealed record TagDefinition
{
    public required string Key { get; init; }
    public string DisplayName { get; init; } = "";

    /// <summary>Adapter-specific address text (for example a memory area and offset). Empty for simulated tags.</summary>
    public string Address { get; init; } = "";

    public required TagDataType DataType { get; init; }

    /// <summary>Engineering value = raw * Scale + Offset.</summary>
    public double Scale { get; init; } = 1.0;
    public double Offset { get; init; } = 0.0;
    public string Unit { get; init; } = "";
    public double? MinValid { get; init; }
    public double? MaxValid { get; init; }
    public string PollGroup { get; init; } = "default";
    public TagRole Role { get; init; } = TagRole.None;

    /// <summary>Links a MotorCommand and MotorFeedback tag to the same motor.</summary>
    public string? MotorId { get; init; }

    /// <summary>Unconfirmed tags are never reported as data (quality BadConfiguration).</summary>
    public bool IsConfirmed { get; init; } = false;
}
