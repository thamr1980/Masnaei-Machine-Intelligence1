using Masnaei.Acquisition.Contracts;
using Masnaei.Acquisition.Simulation;

namespace Masnaei.Acquisition.Tests;

public sealed class ManualTimeProvider : TimeProvider
{
    private DateTimeOffset _now;

    public ManualTimeProvider(DateTimeOffset start) => _now = start;

    public override DateTimeOffset GetUtcNow() => _now;

    public void Set(DateTimeOffset value) => _now = value;
}

public static class TestSupport
{
    public static readonly DateTimeOffset Start = new(2026, 1, 1, 0, 0, 0, TimeSpan.Zero);

    public static DateTimeOffset At(double seconds) => Start + TimeSpan.FromSeconds(seconds);

    public static async Task<(SimulatedPlcAdapter Adapter, ManualTimeProvider Clock)> ConnectedAsync(SimulatedPlcProfile profile)
    {
        var clock = new ManualTimeProvider(Start);
        var adapter = new SimulatedPlcAdapter(profile.ToOptions(Start), clock);
        await adapter.ConnectAsync(CancellationToken.None);
        return (adapter, clock);
    }

    public static async Task<Dictionary<string, Sample>> ReadScaledAsync(
        SimulatedPlcAdapter adapter, ManualTimeProvider clock, SimulatedPlcProfile profile, double atSeconds)
    {
        clock.Set(At(atSeconds));
        var result = await adapter.ReadAsync(profile.Tags, CancellationToken.None);
        var byKey = profile.Tags.ToDictionary(t => t.Key);
        return result.Samples.ToDictionary(s => s.TagKey, s => TagScaler.ToSample(byKey[s.TagKey], s));
    }

    public static ScenarioDefinition CleanScenario() => new()
    {
        Name = "clean",
        Seed = 7,
        FirstCycleStartSeconds = 10,
        NominalCycleSeconds = 100,
        GapSeconds = 20,
        HorizonSeconds = 1000,
        NoiseFraction = 0,
        StopWindows = new[] { new TimeWindow(300, 400) },
        AbnormalCycleFactors = new Dictionary<int, double> { [1] = 2.0 },
        Motors = new[]
        {
            new MotorSimulation("Hydraulic pump", MotorBehavior.WhileMachineRunning, 1.5),
            new MotorSimulation("Cooling pump", MotorBehavior.DuringCycle, 2.0, new[] { new TimeWindow(50, 60) })
        }
    };
}
