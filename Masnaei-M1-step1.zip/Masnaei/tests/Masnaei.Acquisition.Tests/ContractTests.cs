using Masnaei.Acquisition.Contracts;

namespace Masnaei.Acquisition.Tests;

public class ContractTests
{
    private static TagDefinition Tag(Action<TagDefinitionBuilder>? configure = null)
    {
        var b = new TagDefinitionBuilder();
        configure?.Invoke(b);
        return b.Build();
    }

    private sealed class TagDefinitionBuilder
    {
        public string Key = "t";
        public TagDataType DataType = TagDataType.Int16;
        public double Scale = 1.0;
        public double Offset = 0.0;
        public double? Min;
        public double? Max;
        public bool Confirmed = true;
        public TagRole Role = TagRole.None;
        public string? MotorId;

        public TagDefinition Build() => new()
        {
            Key = Key, DataType = DataType, Scale = Scale, Offset = Offset,
            MinValid = Min, MaxValid = Max, IsConfirmed = Confirmed, Role = Role, MotorId = MotorId
        };
    }

    private static RawSample Raw(double? value, SampleQuality quality = SampleQuality.Good) =>
        new("t", value, quality, TestSupport.Start, DataOrigin.Simulated);

    [Fact]
    public void Adapter_interface_has_no_write_or_control_members()
    {
        var forbidden = new[] { "Write", "Set", "Send", "Command", "Control", "Put", "Update", "Delete" };
        var methodNames = typeof(IPlcAdapter).GetMethods().Select(m => m.Name).ToList();

        Assert.DoesNotContain(methodNames, n => forbidden.Any(f => n.Contains(f, StringComparison.OrdinalIgnoreCase)));
        Assert.All(typeof(IPlcAdapter).GetProperties(), p => Assert.False(p.CanWrite));
    }

    [Fact]
    public void Scaling_applies_scale_and_offset()
    {
        var tag = Tag(b => { b.Scale = 0.05; b.Offset = -10; b.DataType = TagDataType.UInt16; });
        var sample = TagScaler.ToSample(tag, Raw(680));

        Assert.Equal(SampleQuality.Good, sample.Quality);
        Assert.Equal(24.0, sample.Value!.Value, 6);
    }

    [Fact]
    public void Unconfirmed_tag_is_never_reported_as_data()
    {
        var tag = Tag(b => b.Confirmed = false);
        var sample = TagScaler.ToSample(tag, Raw(123));

        Assert.Equal(SampleQuality.BadConfiguration, sample.Quality);
        Assert.Null(sample.Value);
    }

    [Fact]
    public void Out_of_range_value_is_flagged_but_kept_for_display()
    {
        var tag = Tag(b => { b.Scale = 0.01; b.Min = 0; b.Max = 5; });
        var sample = TagScaler.ToSample(tag, Raw(600));

        Assert.Equal(SampleQuality.BadOutOfRange, sample.Quality);
        Assert.Equal(6.0, sample.Value!.Value, 6);
    }

    [Fact]
    public void Bad_raw_quality_passes_through_without_a_value()
    {
        var sample = TagScaler.ToSample(Tag(), Raw(null, SampleQuality.BadCommunication));

        Assert.Equal(SampleQuality.BadCommunication, sample.Quality);
        Assert.Null(sample.Value);
    }

    [Fact]
    public void Missing_or_non_finite_raw_value_is_bad_communication()
    {
        Assert.Equal(SampleQuality.BadCommunication, TagScaler.ToSample(Tag(), Raw(null)).Quality);
        Assert.Equal(SampleQuality.BadCommunication, TagScaler.ToSample(Tag(), Raw(double.NaN)).Quality);
    }

    [Fact]
    public void ToRaw_round_trips_and_rounds_to_nearest()
    {
        var tag = Tag(b => { b.Scale = 0.01; b.DataType = TagDataType.Int16; });

        Assert.Equal(120, TagScaler.ToRaw(tag, 1.2));
        Assert.Equal(-50, TagScaler.ToRaw(tag, -0.5));
    }

    [Fact]
    public void ToRaw_clamps_to_register_range()
    {
        var tag = Tag(b => { b.Scale = 0.01; b.DataType = TagDataType.Int16; });
        Assert.Equal(short.MaxValue, TagScaler.ToRaw(tag, 1_000_000));

        var unsigned = Tag(b => { b.DataType = TagDataType.UInt16; });
        Assert.Equal(0, TagScaler.ToRaw(unsigned, -5));
    }

    [Fact]
    public void ToRaw_for_bool_is_zero_or_one()
    {
        var tag = Tag(b => b.DataType = TagDataType.Bool);
        Assert.Equal(1, TagScaler.ToRaw(tag, 1));
        Assert.Equal(0, TagScaler.ToRaw(tag, 0));
    }

    [Fact]
    public void Counter_modulus_matches_register_size()
    {
        Assert.Equal(65_536L, TagScaler.CounterModulus(TagDataType.UInt16));
        Assert.Equal(4_294_967_296L, TagScaler.CounterModulus(TagDataType.UInt32));
        Assert.Throws<ArgumentException>(() => TagScaler.CounterModulus(TagDataType.Int16));
    }

    [Fact]
    public void Validator_accepts_a_clean_mapping()
    {
        var errors = TagDefinitionValidator.Validate(new[]
        {
            Tag(b => b.Key = "a"),
            Tag(b => b.Key = "b")
        });

        Assert.Empty(errors);
    }

    [Fact]
    public void Validator_reports_duplicate_keys_zero_scale_and_bad_ranges()
    {
        var errors = TagDefinitionValidator.Validate(new[]
        {
            Tag(b => b.Key = "a"),
            Tag(b => b.Key = "a"),
            Tag(b => { b.Key = "z"; b.Scale = 0; }),
            Tag(b => { b.Key = "r"; b.Min = 10; b.Max = 1; })
        });

        Assert.Contains(errors, e => e.Contains("Duplicate tag key 'a'"));
        Assert.Contains(errors, e => e.Contains("'z'") && e.Contains("scale"));
        Assert.Contains(errors, e => e.Contains("'r'") && e.Contains("MinValid"));
    }

    [Fact]
    public void Validator_enforces_role_rules()
    {
        var errors = TagDefinitionValidator.Validate(new[]
        {
            Tag(b => { b.Key = "m1"; b.Role = TagRole.MotorCommand; b.DataType = TagDataType.Bool; }),
            Tag(b => { b.Key = "run"; b.Role = TagRole.MachineRunning; b.DataType = TagDataType.Int16; }),
            Tag(b => { b.Key = "cnt"; b.Role = TagRole.CycleCounter; b.DataType = TagDataType.Int16; })
        });

        Assert.Contains(errors, e => e.Contains("'m1'") && e.Contains("MotorId"));
        Assert.Contains(errors, e => e.Contains("'run'") && e.Contains("Bool"));
        Assert.Contains(errors, e => e.Contains("'cnt'") && e.Contains("UInt16"));
    }
}
