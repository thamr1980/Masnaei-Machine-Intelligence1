using Masnaei.Acquisition.Contracts;
using Masnaei.Acquisition.Simulation;

namespace Masnaei.Acquisition.Tests;

public class SimulatedPlcAdapterTests
{
    [Fact]
    public async Task Reads_are_scaled_marked_simulated_and_match_the_model()
    {
        var profile = SimulatedPlcProfiles.MachineA();
        var (adapter, clock) = await TestSupport.ConnectedAsync(profile);

        // Machine A: first cycle starts at 5 s and lasts 120 s, so t = 35 s is u = 0.25 (steam peak).
        var samples = await TestSupport.ReadScaledAsync(adapter, clock, profile, 35);

        Assert.All(samples.Values, s => Assert.Equal(DataOrigin.Simulated, s.Origin));
        Assert.All(samples.Values, s => Assert.Equal(SampleQuality.Good, s.Quality));
        Assert.Equal(1.2, samples["steam.fixed.pressure"].Value!.Value, 1);
        Assert.Equal(1.0, samples["machine.running"].Value!.Value);
        Assert.Equal(1.0, samples["motor.hyd.cmd"].Value!.Value);
        Assert.Equal(0.0, samples["cycle.counter"].Value!.Value);
    }

    [Fact]
    public async Task Same_scenario_and_times_give_identical_raw_values()
    {
        var profile = SimulatedPlcProfiles.MachineA();
        var (a1, c1) = await TestSupport.ConnectedAsync(profile);
        var (a2, c2) = await TestSupport.ConnectedAsync(profile);

        for (var t = 0.0; t <= 300.0; t += 0.5)
        {
            c1.Set(TestSupport.At(t));
            c2.Set(TestSupport.At(t));
            var r1 = (await a1.ReadAsync(profile.Tags, CancellationToken.None)).Samples.Select(s => s.RawValue).ToList();
            var r2 = (await a2.ReadAsync(profile.Tags, CancellationToken.None)).Samples.Select(s => s.RawValue).ToList();
            Assert.Equal(r1, r2);
        }
    }

    [Fact]
    public async Task Order_and_frequency_of_polling_do_not_change_values()
    {
        var profile = SimulatedPlcProfiles.MachineA();
        var (adapter, clock) = await TestSupport.ConnectedAsync(profile);

        var direct = await TestSupport.ReadScaledAsync(adapter, clock, profile, 80);
        await TestSupport.ReadScaledAsync(adapter, clock, profile, 10);
        await TestSupport.ReadScaledAsync(adapter, clock, profile, 200);
        var again = await TestSupport.ReadScaledAsync(adapter, clock, profile, 80);

        Assert.Equal(direct.Select(kv => kv.Value.Value), again.Select(kv => kv.Value.Value));
    }

    [Fact]
    public async Task Different_seed_changes_the_noise()
    {
        var profile = SimulatedPlcProfiles.MachineA();
        var other = profile with { Scenario = profile.Scenario with { Seed = 999 } };
        var (a1, c1) = await TestSupport.ConnectedAsync(profile);
        var (a2, c2) = await TestSupport.ConnectedAsync(other);

        var differs = false;
        for (var t = 20.0; t <= 100.0 && !differs; t += 1.0)
        {
            c1.Set(TestSupport.At(t));
            c2.Set(TestSupport.At(t));
            var r1 = (await a1.ReadAsync(profile.Tags, CancellationToken.None)).Samples.Select(s => s.RawValue).ToList();
            var r2 = (await a2.ReadAsync(other.Tags, CancellationToken.None)).Samples.Select(s => s.RawValue).ToList();
            differs = !r1.SequenceEqual(r2);
        }

        Assert.True(differs);
    }

    [Fact]
    public async Task Counter_wraps_at_sixteen_bits()
    {
        var baseProfile = SimulatedPlcProfiles.MachineA();
        var profile = baseProfile with { Scenario = baseProfile.Scenario with { InitialCounter = 65_535 } };
        var (adapter, clock) = await TestSupport.ConnectedAsync(profile);
        var counter = profile.Tags.Single(t => t.Key == "cycle.counter");

        clock.Set(TestSupport.At(124));   // cycle 0 ends at 125 s
        var before = (await adapter.ReadAsync(new[] { counter }, CancellationToken.None)).Samples[0].RawValue;
        clock.Set(TestSupport.At(125));
        var after = (await adapter.ReadAsync(new[] { counter }, CancellationToken.None)).Samples[0].RawValue;

        Assert.Equal(65_535, before);
        Assert.Equal(0, after);
    }

    [Fact]
    public async Task Abnormal_cycle_in_machine_A_is_longer_and_ground_truth_is_exposed()
    {
        var profile = SimulatedPlcProfiles.MachineA();
        var (adapter, _) = await TestSupport.ConnectedAsync(profile);
        var cycles = adapter.Model.Cycles;

        // Cycle attempt 3 has factor 1.5 -> 180 s, starting at 395 s.
        Assert.Equal(395, cycles[3].StartSeconds);
        Assert.Equal(575, cycles[3].EndSeconds);
        Assert.True(cycles[3].Completed);
    }

    [Fact]
    public async Task Communication_failure_window_faults_the_adapter_until_it_reconnects()
    {
        var profile = SimulatedPlcProfiles.MachineA();   // failure window 500..520 s
        var (adapter, clock) = await TestSupport.ConnectedAsync(profile);

        clock.Set(TestSupport.At(499));
        await adapter.ReadAsync(profile.Tags, CancellationToken.None);

        clock.Set(TestSupport.At(500));
        await Assert.ThrowsAsync<PlcCommunicationException>(() => adapter.ReadAsync(profile.Tags, CancellationToken.None));
        Assert.Equal(PlcConnectionState.Faulted, adapter.State);

        clock.Set(TestSupport.At(505));
        await Assert.ThrowsAsync<PlcCommunicationException>(() => adapter.ConnectAsync(CancellationToken.None));

        clock.Set(TestSupport.At(520));
        await adapter.ConnectAsync(CancellationToken.None);
        Assert.Equal(PlcConnectionState.Connected, adapter.State);
        var result = await adapter.ReadAsync(profile.Tags, CancellationToken.None);
        Assert.Equal(profile.Tags.Count, result.Samples.Count);
    }

    [Fact]
    public async Task Reading_before_connecting_fails()
    {
        var profile = SimulatedPlcProfiles.MachineA();
        var adapter = new SimulatedPlcAdapter(profile.ToOptions(TestSupport.Start), new ManualTimeProvider(TestSupport.Start));

        await Assert.ThrowsAsync<PlcCommunicationException>(() => adapter.ReadAsync(profile.Tags, CancellationToken.None));
    }

    [Fact]
    public async Task Tag_without_a_signal_binding_is_reported_as_bad_configuration()
    {
        var profile = SimulatedPlcProfiles.MachineA();
        var (adapter, clock) = await TestSupport.ConnectedAsync(profile);
        var unknown = new TagDefinition { Key = "not.mapped", DataType = TagDataType.Int16, IsConfirmed = true };

        clock.Set(TestSupport.At(35));
        var result = await adapter.ReadAsync(new[] { unknown }, CancellationToken.None);

        Assert.Equal(SampleQuality.BadConfiguration, result.Samples[0].Quality);
    }
}

public class ProfileTests
{
    public static IEnumerable<object[]> Profiles() => new[]
    {
        new object[] { SimulatedPlcProfiles.MachineA() },
        new object[] { SimulatedPlcProfiles.MachineB() }
    };

    [Theory]
    [MemberData(nameof(Profiles))]
    public void Profile_tag_mapping_is_valid_and_fully_bound(SimulatedPlcProfile profile)
    {
        Assert.Empty(TagDefinitionValidator.Validate(profile.Tags));
        Assert.All(profile.Tags, t => Assert.True(profile.SignalMap.ContainsKey(t.Key), $"No binding for {t.Key}"));
    }

    [Fact]
    public void The_two_simulated_PLCs_have_genuinely_different_tag_mappings()
    {
        var a = SimulatedPlcProfiles.MachineA();
        var b = SimulatedPlcProfiles.MachineB();

        Assert.Empty(a.Tags.Select(t => t.Key).Intersect(b.Tags.Select(t => t.Key)));
        Assert.NotEqual(a.Tags.Count, b.Tags.Count);
        Assert.Equal(TagDataType.UInt16, a.Tags.Single(t => t.Role == TagRole.CycleCounter).DataType);
        Assert.Equal(TagDataType.UInt32, b.Tags.Single(t => t.Role == TagRole.CycleCounter).DataType);
        Assert.Contains(a.Tags, t => t.Role == TagRole.CycleStart);
        Assert.DoesNotContain(b.Tags, t => t.Role == TagRole.CycleStart);
        Assert.NotEqual(a.Scenario.Motors.Count, b.Scenario.Motors.Count);
    }

    [Fact]
    public async Task Both_PLCs_can_be_read_side_by_side_with_their_own_mappings()
    {
        var a = SimulatedPlcProfiles.MachineA();
        var b = SimulatedPlcProfiles.MachineB();
        var (adapterA, clockA) = await TestSupport.ConnectedAsync(a);
        var (adapterB, clockB) = await TestSupport.ConnectedAsync(b);

        var samplesA = await TestSupport.ReadScaledAsync(adapterA, clockA, a, 35);
        // Machine B: first cycle starts at 12 s and lasts 90 s, so t = 12 + 0.25 * 90 = 34.5 s is the steam peak.
        var samplesB = await TestSupport.ReadScaledAsync(adapterB, clockB, b, 34.5);

        Assert.Equal(a.Tags.Select(t => t.Key).OrderBy(k => k), samplesA.Keys.OrderBy(k => k));
        Assert.Equal(b.Tags.Select(t => t.Key).OrderBy(k => k), samplesB.Keys.OrderBy(k => k));
        Assert.Equal(1.2, samplesA["steam.fixed.pressure"].Value!.Value, 1);
        Assert.Equal(1.2, samplesB["SteamP_Fix"].Value!.Value, 1);
        Assert.Equal(1000.0, samplesB["CycCnt"].Value!.Value);   // initial counter, no completed cycle yet
        Assert.Equal(0.0, samplesA["cycle.counter"].Value!.Value);
    }

    [Fact]
    public async Task A_failure_in_one_PLC_does_not_affect_the_other()
    {
        var a = SimulatedPlcProfiles.MachineA();   // fails at 500..520
        var b = SimulatedPlcProfiles.MachineB();   // fails at 200..230
        var (adapterA, clockA) = await TestSupport.ConnectedAsync(a);
        var (adapterB, clockB) = await TestSupport.ConnectedAsync(b);

        clockA.Set(TestSupport.At(210));
        clockB.Set(TestSupport.At(210));

        await adapterA.ReadAsync(a.Tags, CancellationToken.None);   // A is healthy at 210 s
        await Assert.ThrowsAsync<Masnaei.Acquisition.Contracts.PlcCommunicationException>(
            () => adapterB.ReadAsync(b.Tags, CancellationToken.None));
        Assert.Equal(PlcConnectionState.Connected, adapterA.State);
    }
}
