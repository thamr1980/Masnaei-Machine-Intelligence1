using Masnaei.Acquisition.Simulation;

namespace Masnaei.Acquisition.Tests;

public class ScenarioTests
{
    private static SimulatedMachineModel Model() => new(TestSupport.CleanScenario());

    [Fact]
    public void Cycle_schedule_matches_hand_computed_timeline()
    {
        var cycles = Model().Cycles;

        Assert.Equal(7, cycles.Count);
        Assert.Equal((10.0, 110.0, true), (cycles[0].StartSeconds, cycles[0].EndSeconds, cycles[0].Completed));
        // Abnormal cycle (x2 = 200 s) is cut off by the stop window starting at 300.
        Assert.Equal((130.0, 300.0, false), (cycles[1].StartSeconds, cycles[1].EndSeconds, cycles[1].Completed));
        // Next cycle starts exactly when the stop window ends.
        Assert.Equal((400.0, 500.0, true), (cycles[2].StartSeconds, cycles[2].EndSeconds, cycles[2].Completed));
        Assert.Equal((520.0, 620.0, true), (cycles[3].StartSeconds, cycles[3].EndSeconds, cycles[3].Completed));
        Assert.Equal(6, cycles.Count(c => c.Completed));
    }

    [Fact]
    public void Counter_counts_only_completed_cycles()
    {
        var m = Model();

        Assert.Equal(0, m.CounterTotal(109.9));
        Assert.Equal(1, m.CounterTotal(110.0));
        Assert.Equal(1, m.CounterTotal(299.0));
        Assert.Equal(1, m.CounterTotal(350.0));   // aborted cycle did not count
        Assert.Equal(2, m.CounterTotal(500.0));
        Assert.Equal(6, m.CounterTotal(1000.0));
    }

    [Fact]
    public void Running_bit_follows_first_start_and_stop_windows()
    {
        var m = Model();

        Assert.False(m.IsRunning(5));
        Assert.True(m.IsRunning(10));
        Assert.False(m.IsRunning(350));
        Assert.True(m.IsRunning(400));
    }

    [Fact]
    public void Last_cycle_duration_updates_on_completion()
    {
        var m = Model();

        Assert.Equal(0, m.LastCompletedCycleDuration(50));
        Assert.Equal(100, m.LastCompletedCycleDuration(200));
        Assert.Equal(100, m.LastCompletedCycleDuration(600));
    }

    [Fact]
    public void Start_and_end_pulses_exist_only_for_the_right_cycles()
    {
        var m = Model();

        Assert.True(m.StartPulse(10.5));
        Assert.False(m.StartPulse(12.0));
        Assert.True(m.EndPulse(110.5));
        Assert.False(m.EndPulse(300.5));   // aborted cycle has no end pulse
    }

    [Fact]
    public void Analog_curves_are_exact_when_noise_is_zero()
    {
        var m = Model();

        Assert.Equal(0.0, m.Analog(SimulatedSignalKind.FixedSteamPressure, 10), 9);
        Assert.Equal(1.2, m.Analog(SimulatedSignalKind.FixedSteamPressure, 45), 9);     // u = 0.35
        Assert.Equal(0.65, m.Analog(SimulatedSignalKind.FixedSteamPressure, 60), 9);    // u = 0.50
        Assert.Equal(102.0, m.Analog(SimulatedSignalKind.FixedMoldTemperature, 45), 9);
        Assert.Equal(30.0, m.Analog(SimulatedSignalKind.FixedMoldTemperature, 25), 9);  // u = 0.15
        Assert.Equal(190.0, m.Analog(SimulatedSignalKind.HydraulicPressure, 12), 9);    // u = 0.02
        Assert.Equal(150.0, m.Analog(SimulatedSignalKind.HydraulicPressure, 115), 9);   // idle but running
        Assert.Equal(0.0, m.Analog(SimulatedSignalKind.HydraulicPressure, 350), 9);     // stopped
        Assert.Equal(24.0, m.Analog(SimulatedSignalKind.WaterInletTemperature, 0), 9);
        Assert.Equal(26.0, m.Analog(SimulatedSignalKind.WaterInletTemperature, 900), 9);
    }

    [Fact]
    public void Residual_heat_decays_after_a_cycle_ends()
    {
        var m = Model();
        var expected = 30.0 + 14.4 * Math.Exp(-5.0 / 180.0);

        Assert.Equal(expected, m.Analog(SimulatedSignalKind.FixedMoldTemperature, 115), 9);
    }

    [Fact]
    public void Motor_feedback_lags_command_and_respects_fault_windows()
    {
        var m = Model();

        Assert.True(m.MotorCommand(0, 10.0));
        Assert.False(m.MotorFeedback(0, 10.5));   // delay 1.5 s not elapsed
        Assert.True(m.MotorFeedback(0, 11.6));

        Assert.True(m.MotorCommand(1, 55));
        Assert.False(m.MotorFeedback(1, 55));     // inside feedback fault window
        Assert.True(m.MotorFeedback(1, 61));

        Assert.False(m.MotorCommand(0, 350));     // machine stopped
        Assert.False(m.MotorFeedback(0, 350.2));
    }

    [Fact]
    public void Invalid_scenarios_are_rejected()
    {
        var clean = TestSupport.CleanScenario();

        Assert.Throws<ArgumentException>(() => new SimulatedMachineModel(clean with { NominalCycleSeconds = 0 }));
        Assert.Throws<ArgumentException>(() => new SimulatedMachineModel(clean with
        {
            StopWindows = new[] { new TimeWindow(100, 200), new TimeWindow(150, 250) }
        }));
        Assert.Throws<ArgumentException>(() => new SimulatedMachineModel(clean with
        {
            AbnormalCycleFactors = new Dictionary<int, double> { [0] = -1 }
        }));
    }
}
