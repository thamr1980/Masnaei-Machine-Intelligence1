# Masnaei Machine Intelligence V1 - Milestone 1

Status: Step 1 of Milestone 1 (foundation and simulator). See STATUS.md for exactly what has and has not been verified.

## Layout
- `src/Masnaei.Acquisition.Contracts` - tag model, samples, scaling, validation, `IPlcAdapter` (read-only: no write members).
- `src/Masnaei.Acquisition.Simulation` - deterministic simulated PLC behind `IPlcAdapter`; two sample profiles (Machine A, Machine B) with different tag mappings.
- `tests/Masnaei.Acquisition.Tests` - xUnit tests.

## Run
Install the .NET 8 SDK, then `./build-and-test.sh` (or `build-and-test.ps1` on Windows).

## Rules kept
- Read-only: the adapter interface has no write, set or command methods (enforced by a test).
- No real PLC IPs or addresses anywhere. Tags are unconfirmed by default and never reported as data until confirmed.
- All simulated samples carry `DataOrigin.Simulated`.
