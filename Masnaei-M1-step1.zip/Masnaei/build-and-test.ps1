# Creates the solution file (once), restores, builds and runs all tests.
# Requires the .NET 8 SDK and NuGet access.
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not (Test-Path "Masnaei.sln")) {
    dotnet new sln -n Masnaei
    Get-ChildItem -Recurse -Filter *.csproj | ForEach-Object { dotnet sln Masnaei.sln add $_.FullName }
}
dotnet restore
dotnet build --no-restore -c Debug
dotnet test --no-build -c Debug --logger "trx;LogFileName=test-results.trx" --logger "console;verbosity=normal"
